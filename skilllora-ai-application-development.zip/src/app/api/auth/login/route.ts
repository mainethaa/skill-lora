import { eq } from "drizzle-orm";
import { cookies } from "next/headers";
import { db } from "@/db";
import { users } from "@/db/schema";
import { createSession, SESSION_COOKIE, sessionCookieOptions, verifyPassword } from "@/lib/auth";
import { cleanString, fail, isValidEmail, ok, readJson, safely } from "@/lib/http";

export const dynamic = "force-dynamic";

export async function POST(req: Request) {
  return safely("auth/login", async () => {
    const body = await readJson(req);
    if (!body) return fail("Request body must be a JSON object.", 400);

    const email = cleanString(body.email, 254).toLowerCase();
    const password = typeof body.password === "string" ? body.password : "";
    if (!isValidEmail(email) || password.length === 0 || password.length > 128) {
      return fail("Enter a valid email and password.", 422);
    }

    const [user] = await db
      .select({ id: users.id, fullName: users.fullName, email: users.email, passwordHash: users.passwordHash })
      .from(users)
      .where(eq(users.email, email))
      .limit(1);

    // Same generic message for unknown email and wrong password (prevents account enumeration).
    const valid = user ? await verifyPassword(password, user.passwordHash) : false;
    if (!user || !valid) return fail("Incorrect email or password.", 401);

    const { token, expiresAt } = await createSession(user.id);
    const store = await cookies();
    store.set(SESSION_COOKIE, token, sessionCookieOptions(expiresAt));

    return ok({ user: { id: user.id, fullName: user.fullName, email: user.email } });
  });
}
