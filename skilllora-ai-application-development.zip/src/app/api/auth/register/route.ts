import { NextResponse } from "next/server";
import { eq } from "drizzle-orm";
import { cookies } from "next/headers";
import { db } from "@/db";
import { learnerProfiles, users } from "@/db/schema";
import { createSession, hashPassword, SESSION_COOKIE, sessionCookieOptions } from "@/lib/auth";
import { cleanString, fail, isValidEmail, ok, readJson, safely } from "@/lib/http";
import { ensureSeeded } from "@/lib/seed";

export const dynamic = "force-dynamic";

export async function POST(req: Request) {
  return safely("auth/register", async () => {
    const body = await readJson(req);
    if (!body) return fail("Request body must be a JSON object.", 400);

    const fullName = cleanString(body.fullName, 120);
    const email = cleanString(body.email, 254).toLowerCase();
    const password = typeof body.password === "string" ? body.password : "";

    const details: Record<string, string> = {};
    if (fullName.length < 2) details.fullName = "Enter your full name (at least 2 characters).";
    if (!isValidEmail(email)) details.email = "Enter a valid email address.";
    if (password.length < 8 || password.length > 128) details.password = "Password must be 8–128 characters.";
    else if (!/[A-Za-z]/.test(password) || !/[0-9]/.test(password)) details.password = "Password must contain at least one letter and one number.";
    if (Object.keys(details).length) return fail("Please correct the highlighted fields.", 422, details);

    const existing = await db.select({ id: users.id }).from(users).where(eq(users.email, email)).limit(1);
    if (existing[0]) return fail("An account with this email already exists. Try logging in.", 409);

    const passwordHash = await hashPassword(password);
    const [user] = await db
      .insert(users)
      .values({ fullName, email, passwordHash })
      .returning({ id: users.id, fullName: users.fullName, email: users.email });

    await db.insert(learnerProfiles).values({ userId: user.id });
    await ensureSeeded();

    const { token, expiresAt } = await createSession(user.id);
    const store = await cookies();
    store.set(SESSION_COOKIE, token, sessionCookieOptions(expiresAt));

    return ok({ user: { id: user.id, fullName: user.fullName, email: user.email } }, 201);
  });
}
