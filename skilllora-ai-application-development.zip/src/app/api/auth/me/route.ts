import { getCurrentUser } from "@/lib/auth";
import { fail, ok, safely } from "@/lib/http";

export const dynamic = "force-dynamic";

export async function GET() {
  return safely("auth/me", async () => {
    const user = await getCurrentUser();
    if (!user) return fail("Please log in to continue.", 401);
    return ok({ user });
  });
}
