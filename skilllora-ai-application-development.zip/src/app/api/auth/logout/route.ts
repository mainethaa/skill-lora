import { cookies } from "next/headers";
import { destroySession, SESSION_COOKIE } from "@/lib/auth";
import { ok, safely } from "@/lib/http";

export const dynamic = "force-dynamic";

export async function POST() {
  return safely("auth/logout", async () => {
    const store = await cookies();
    const token = store.get(SESSION_COOKIE)?.value;
    if (token) await destroySession(token);
    // Expire the cookie in the browser as well.
    store.set(SESSION_COOKIE, "", { path: "/", maxAge: 0, httpOnly: true, sameSite: "lax" });
    return ok({ message: "You have been logged out." });
  });
}
