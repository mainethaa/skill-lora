import { asc, eq } from "drizzle-orm";
import { db } from "@/db";
import { learningResources, learningRoadmaps, roadmapTasks, skills } from "@/db/schema";
import { loadSnapshot, careerMatchingAgent, recommendNextAction } from "@/lib/agents";
import { ok, requireUser, safely } from "@/lib/http";
import { ensureSeeded } from "@/lib/seed";

export const dynamic = "force-dynamic";

export async function GET() {
  return safely("roadmap:get", async () => {
    const auth = await requireUser();
    if (auth.response) return auth.response;
    await ensureSeeded();

    const snap = await loadSnapshot(auth.user.id);
    const matching = careerMatchingAgent(snap);

    const rows = snap.roadmap
      ? await db
          .select({
            id: roadmapTasks.id,
            title: roadmapTasks.title,
            skillId: roadmapTasks.skillId,
            skillName: skills.name,
            category: skills.category,
            priority: roadmapTasks.priority,
            weekNumber: roadmapTasks.weekNumber,
            estimatedHours: roadmapTasks.estimatedHours,
            practicalExercise: roadmapTasks.practicalExercise,
            miniProject: roadmapTasks.miniProject,
            status: roadmapTasks.status,
            completedAt: roadmapTasks.completedAt,
            resourceTitle: learningResources.title,
            resourceProvider: learningResources.provider,
            resourceUrl: learningResources.url,
            resourceType: learningResources.resourceType,
          })
          .from(roadmapTasks)
          .innerJoin(skills, eq(roadmapTasks.skillId, skills.id))
          .leftJoin(learningResources, eq(roadmapTasks.resourceId, learningResources.id))
          .where(eq(roadmapTasks.roadmapId, snap.roadmap.id))
          .orderBy(asc(roadmapTasks.position))
      : [];

    const completed = rows.filter((r) => r.status === "completed").length;
    const weeksMap = new Map<number, typeof rows>();
    for (const r of rows.filter((x) => x.status === "pending")) {
      weeksMap.set(r.weekNumber, [...(weeksMap.get(r.weekNumber) ?? []), r]);
    }
    const weeklySchedule = [...weeksMap.entries()]
      .sort((a, b) => a[0] - b[0])
      .map(([week, items]) => ({
        week,
        hours: items.reduce((sum, i) => sum + i.estimatedHours, 0),
        taskIds: items.map((i) => i.id),
      }));

    return ok({
      roadmap: snap.roadmap
        ? {
            id: snap.roadmap.id,
            generatedBy: snap.roadmap.generatedBy,
            weeklyHours: snap.roadmap.weeklyHours,
            createdAt: snap.roadmap.createdAt,
            careerTitle: matching.careerTitle,
          }
        : null,
      targetCareer: snap.career ? { id: snap.career.id, title: snap.career.title } : null,
      matchPercentage: matching.matchPercentage,
      summary: {
        total: rows.length,
        completed,
        pending: rows.length - completed,
        completionPercentage: rows.length ? Math.round((completed / rows.length) * 100) : 0,
      },
      tasks: rows,
      weeklySchedule,
      nextAction: recommendNextAction(snap, matching),
    });
  });
}

// Keep the static import list tidy: ensure the table is referenced for type inference.
void learningRoadmaps;
