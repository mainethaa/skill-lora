import { and, eq } from "drizzle-orm";
import { db } from "@/db";
import { learnerSkills, roadmapTasks, skills } from "@/db/schema";
import {
  LEARNING_BOOST,
  LEARNING_CAP,
  recordProgress,
  runAgentWorkflow,
  setProficiency,
} from "@/lib/agents";
import { fail, ok, readJson, requireUser, safely } from "@/lib/http";

export const dynamic = "force-dynamic";

/**
 * Marks a roadmap task completed (or reopens it). Completing a learning task raises the
 * related skill's proficiency by LEARNING_BOOST points, capped at LEARNING_CAP. Mastery above
 * the cap requires passing an assessment. The roadmap and career match are then recalculated.
 */
export async function PATCH(req: Request, { params }: { params: Promise<{ id: string }> }) {
  return safely("roadmap:task", async () => {
    const auth = await requireUser();
    if (auth.response) return auth.response;
    const userId = auth.user.id;

    const { id } = await params;
    const taskId = Number(id);
    if (!Number.isInteger(taskId) || taskId < 1) return fail("Invalid task id.", 400);

    const body = await readJson(req);
    const status = body?.status;
    if (status !== "completed" && status !== "pending") {
      return fail("Status must be 'completed' or 'pending'.", 422, { status: "Use 'completed' or 'pending'." });
    }

    const [task] = await db
      .select()
      .from(roadmapTasks)
      .where(and(eq(roadmapTasks.id, taskId), eq(roadmapTasks.userId, userId)))
      .limit(1);
    if (!task) return fail("Roadmap task not found.", 404);

    const [skill] = await db.select({ name: skills.name }).from(skills).where(eq(skills.id, task.skillId)).limit(1);
    let proficiencyChange: { skillName: string; from: number; to: number } | null = null;

    if (status === "completed" && task.status !== "completed") {
      await db
        .update(roadmapTasks)
        .set({ status: "completed", completedAt: task.completedAt ?? new Date() })
        .where(eq(roadmapTasks.id, taskId));

      // Learning boost only applies the first time a task is completed.
      if (!task.completedAt) {
        const [existing] = await db
          .select({ proficiency: learnerSkills.proficiency, source: learnerSkills.source })
          .from(learnerSkills)
          .where(and(eq(learnerSkills.userId, userId), eq(learnerSkills.skillId, task.skillId)))
          .limit(1);
        const from = existing?.proficiency ?? 0;
        if (from < LEARNING_CAP) {
          const to = Math.min(from + LEARNING_BOOST, LEARNING_CAP);
          await setProficiency(userId, task.skillId, to, existing?.source ?? "learning");
          proficiencyChange = { skillName: skill?.name ?? "Skill", from, to };
        }
      }
    } else if (status === "pending" && task.status !== "pending") {
      await db.update(roadmapTasks).set({ status: "pending" }).where(eq(roadmapTasks.id, taskId));
    }

    const workflow = await runAgentWorkflow(userId, { syncRoadmap: true });
    const matchPercentage = workflow.matching.matchPercentage;

    if (status === "completed" && task.status !== "completed") {
      const extra = proficiencyChange ? ` ${proficiencyChange.skillName} rose from ${proficiencyChange.from}% to ${proficiencyChange.to}%.` : "";
      await recordProgress(userId, "task_completed", `Completed: ${task.title}.${extra}`, matchPercentage, {
        taskId,
        skillId: task.skillId,
      });
    }

    return ok({
      task: { id: taskId, status: status === "completed" ? "completed" : "pending" },
      proficiencyChange,
      matchPercentage,
      nextAction: workflow.nextAction,
      roadmapChanges: workflow.roadmapChanges,
      message: status === "completed" ? "Task completed. Your roadmap has been updated." : "Task reopened.",
    });
  });
}
