import { desc, eq } from "drizzle-orm";
import { db } from "@/db";
import { progressRecords } from "@/db/schema";
import { ok, requireUser, safely } from "@/lib/http";

export const dynamic = "force-dynamic";

/** Returns the learner's activity feed (most recent first). */
export async function GET() {
  return safely("progress:list", async () => {
    const auth = await requireUser();
    if (auth.response) return auth.response;

    const records = await db
      .select({
        id: progressRecords.id,
        activityType: progressRecords.activityType,
        description: progressRecords.description,
        matchPercentage: progressRecords.matchPercentage,
        createdAt: progressRecords.createdAt,
      })
      .from(progressRecords)
      .where(eq(progressRecords.userId, auth.user.id))
      .orderBy(desc(progressRecords.createdAt))
      .limit(20);

    return ok({ records });
  });
}
