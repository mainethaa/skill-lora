import { ok, requireUser, safely } from "@/lib/http";
import { buildAnalytics } from "@/lib/agents";
import { ensureSeeded } from "@/lib/seed";

export const dynamic = "force-dynamic";

/** Full learner analytics: match %, roadmap completion, skill comparison, weekly activity, achievements. */
export async function GET() {
  return safely("progress:analytics", async () => {
    const auth = await requireUser();
    if (auth.response) return auth.response;
    await ensureSeeded();
    const analytics = await buildAnalytics(auth.user.id);
    return ok({ analytics });
  });
}
