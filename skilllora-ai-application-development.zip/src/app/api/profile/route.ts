import { eq } from "drizzle-orm";
import { db } from "@/db";
import { careerRoles, learnerProfiles, users } from "@/db/schema";
import { recordProgress, runAgentWorkflow } from "@/lib/agents";
import { cleanString, fail, isInt, ok, readJson, requireUser, safely, stringArray } from "@/lib/http";
import { ensureSeeded } from "@/lib/seed";

export const dynamic = "force-dynamic";

const EDUCATION_LEVELS = [
  "High school",
  "Diploma",
  "Undergraduate (1st–2nd year)",
  "Undergraduate (3rd–4th year)",
  "Postgraduate",
  "Recent graduate",
  "Working professional",
  "Other",
];

async function loadProfile(userId: number) {
  await ensureSeeded();
  const [user] = await db.select({ fullName: users.fullName, email: users.email }).from(users).where(eq(users.id, userId)).limit(1);
  let [profile] = await db.select().from(learnerProfiles).where(eq(learnerProfiles.userId, userId)).limit(1);
  if (!profile) {
    [profile] = await db.insert(learnerProfiles).values({ userId }).returning();
  }
  let targetCareer: { id: number; title: string; slug: string } | null = null;
  if (profile.targetCareerId) {
    const [c] = await db
      .select({ id: careerRoles.id, title: careerRoles.title, slug: careerRoles.slug })
      .from(careerRoles)
      .where(eq(careerRoles.id, profile.targetCareerId))
      .limit(1);
    targetCareer = c ?? null;
  }
  return {
    fullName: user?.fullName ?? "",
    email: user?.email ?? "",
    educationLevel: profile.educationLevel,
    institution: profile.institution,
    certifications: profile.certifications,
    completedProjects: profile.completedProjects,
    targetCareer,
    weeklyHours: profile.weeklyHours,
    onboardingCompleted: profile.onboardingCompleted,
    lastMatchPercentage: profile.lastMatchPercentage,
    updatedAt: profile.updatedAt,
  };
}

export async function GET() {
  return safely("profile:get", async () => {
    const auth = await requireUser();
    if (auth.response) return auth.response;
    return ok({ profile: await loadProfile(auth.user.id) });
  });
}

export async function PUT(req: Request) {
  return safely("profile:put", async () => {
    const auth = await requireUser();
    if (auth.response) return auth.response;
    const userId = auth.user.id;

    const body = await readJson(req);
    if (!body) return fail("Request body must be a JSON object.", 400);

    const details: Record<string, string> = {};
    const updates: Record<string, unknown> = {};

    if (body.fullName !== undefined) {
      const fullName = cleanString(body.fullName, 120);
      if (fullName.length < 2) details.fullName = "Name must be at least 2 characters.";
      else updates.fullName = fullName;
    }
    if (body.educationLevel !== undefined) {
      const level = cleanString(body.educationLevel, 60);
      if (level && !EDUCATION_LEVELS.includes(level)) details.educationLevel = "Choose a listed education level.";
      else updates.educationLevel = level || null;
    }
    if (body.institution !== undefined) {
      updates.institution = cleanString(body.institution, 160) || null;
    }
    if (body.certifications !== undefined) {
      updates.certifications = stringArray(body.certifications, 20, 120);
    }
    if (body.completedProjects !== undefined) {
      updates.completedProjects = stringArray(body.completedProjects, 20, 160);
    }
    if (body.weeklyHours !== undefined) {
      if (!isInt(body.weeklyHours, 1, 40)) details.weeklyHours = "Weekly hours must be a whole number from 1 to 40.";
      else updates.weeklyHours = body.weeklyHours;
    }
    if (body.targetCareerId !== undefined) {
      if (body.targetCareerId === null) {
        updates.targetCareerId = null;
      } else if (!isInt(body.targetCareerId, 1, 100000)) {
        details.targetCareerId = "Choose a valid career.";
      } else {
        await ensureSeeded();
        const [exists] = await db.select({ id: careerRoles.id }).from(careerRoles).where(eq(careerRoles.id, body.targetCareerId)).limit(1);
        if (!exists) details.targetCareerId = "This career does not exist.";
        else updates.targetCareerId = body.targetCareerId;
      }
    }
    if (body.onboardingCompleted !== undefined) {
      if (typeof body.onboardingCompleted !== "boolean") details.onboardingCompleted = "Must be true or false.";
      else updates.onboardingCompleted = body.onboardingCompleted;
    }

    if (Object.keys(details).length) return fail("Please correct the highlighted fields.", 422, details);
    if (Object.keys(updates).length === 0) return fail("No profile fields were provided.", 400);

    const { fullName, ...profileUpdates } = updates as { fullName?: string } & Record<string, unknown>;
    if (fullName) {
      await db.update(users).set({ fullName, updatedAt: new Date() }).where(eq(users.id, userId));
    }

    await ensureSeeded();
    const existing = await loadProfile(userId);
    const careerChanged =
      "targetCareerId" in profileUpdates && profileUpdates.targetCareerId !== (existing.targetCareer?.id ?? null);

    if (Object.keys(profileUpdates).length) {
      await db
        .update(learnerProfiles)
        .set({ ...(profileUpdates as Partial<typeof learnerProfiles.$inferInsert>), updatedAt: new Date() })
        .where(eq(learnerProfiles.userId, userId));
    }

    // Adapt the roadmap immediately when the target career or availability changes.
    if (careerChanged || "weeklyHours" in profileUpdates) {
      const workflow = await runAgentWorkflow(userId, { syncRoadmap: true });
      if (workflow.snap.roadmap) {
        await recordProgress(userId, "roadmap_updated", `Roadmap adapted to your ${careerChanged ? "new target career" : "updated weekly availability"}.`, workflow.matching.matchPercentage);
      }
    }

    await recordProgress(userId, "profile_updated", "Profile information was updated.", null, { fields: Object.keys(updates) });

    return ok({ profile: await loadProfile(userId), message: "Profile saved." });
  });
}
