import { and, eq } from "drizzle-orm";
import { db } from "@/db";
import { learnerSkills, skills } from "@/db/schema";
import { recordProgress, runAgentWorkflow, setProficiency } from "@/lib/agents";
import { fail, isInt, ok, readJson, requireUser, safely } from "@/lib/http";

export const dynamic = "force-dynamic";

/** Updates the proficiency of one of the learner's skills. `id` is the skill id. */
export async function PUT(req: Request, { params }: { params: Promise<{ id: string }> }) {
  return safely("skills:update", async () => {
    const auth = await requireUser();
    if (auth.response) return auth.response;
    const userId = auth.user.id;

    const { id } = await params;
    const skillId = Number(id);
    if (!Number.isInteger(skillId) || skillId < 1) return fail("Invalid skill id.", 400);

    const body = await readJson(req);
    if (!body) return fail("Request body must be a JSON object.", 400);
    if (!isInt(body.proficiency, 0, 100)) {
      return fail("Please correct the highlighted fields.", 422, {
        proficiency: "Proficiency must be a whole number from 0 to 100.",
      });
    }

    const [owned] = await db
      .select({ name: skills.name })
      .from(learnerSkills)
      .innerJoin(skills, eq(learnerSkills.skillId, skills.id))
      .where(and(eq(learnerSkills.userId, userId), eq(learnerSkills.skillId, skillId)))
      .limit(1);
    if (!owned) return fail("This skill is not in your profile.", 404);

    const value = await setProficiency(userId, skillId, body.proficiency as number, "self");
    await recordProgress(userId, "skill_updated", `Updated ${owned.name} to ${value}% proficiency.`, null, { skillId });
    const workflow = await runAgentWorkflow(userId, { syncRoadmap: true });

    return ok({
      skill: { skillId, name: owned.name, proficiency: value, source: "self" },
      matchPercentage: workflow.matching.matchPercentage,
      message: `${owned.name} updated.`,
    });
  });
}
