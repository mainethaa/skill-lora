import { ok, requireUser, safely } from "@/lib/http";
import { runAgentWorkflow } from "@/lib/agents";

export const dynamic = "force-dynamic";

/**
 * Runs the Skill Assessment Agent and the Career Matching Agent for the logged-in learner
 * and returns structured gap analysis. Also returns the Learning Path Agent's current priorities.
 */
export async function GET() {
  return safely("skills:gaps", async () => {
    const auth = await requireUser();
    if (auth.response) return auth.response;

    const { snap, assessment, matching, nextAction } = await runAgentWorkflow(auth.user.id);

    return ok({
      targetCareer: snap.career ? { id: snap.career.id, title: snap.career.title, description: snap.career.description } : null,
      skillAssessment: assessment,
      careerMatch: matching,
      priorities: matching.gaps.slice(0, 6),
      nextAction,
    });
  });
}
