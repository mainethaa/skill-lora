import { asc, eq } from "drizzle-orm";
import { db } from "@/db";
import { learnerSkills, skills } from "@/db/schema";
import { recordProgress, runAgentWorkflow, setProficiency } from "@/lib/agents";
import { cleanString, fail, isInt, ok, readJson, requireUser, safely } from "@/lib/http";
import { findOrCreateSkill, ensureSeeded } from "@/lib/seed";

export const dynamic = "force-dynamic";

/** Returns the learner's skills plus the full skill catalogue for the picker. */
export async function GET() {
  return safely("skills:list", async () => {
    const auth = await requireUser();
    if (auth.response) return auth.response;
    await ensureSeeded();

    const mine = await db
      .select({
        skillId: learnerSkills.skillId,
        name: skills.name,
        category: skills.category,
        proficiency: learnerSkills.proficiency,
        source: learnerSkills.source,
        updatedAt: learnerSkills.updatedAt,
      })
      .from(learnerSkills)
      .innerJoin(skills, eq(learnerSkills.skillId, skills.id))
      .where(eq(learnerSkills.userId, auth.user.id))
      .orderBy(asc(skills.name));

    const catalog = await db
      .select({ id: skills.id, name: skills.name, category: skills.category })
      .from(skills)
      .orderBy(asc(skills.category), asc(skills.name));

    return ok({ skills: mine, catalog });
  });
}

/** Adds (or re-rates) one of the learner's skills. Accepts a catalogue name or a custom skill name. */
export async function POST(req: Request) {
  return safely("skills:create", async () => {
    const auth = await requireUser();
    if (auth.response) return auth.response;
    const userId = auth.user.id;

    const body = await readJson(req);
    if (!body) return fail("Request body must be a JSON object.", 400);

    const name = cleanString(body.name, 100);
    const details: Record<string, string> = {};
    if (name.length < 2) details.name = "Skill name must be at least 2 characters.";
    if (!isInt(body.proficiency, 0, 100)) details.proficiency = "Proficiency must be a whole number from 0 to 100.";
    if (Object.keys(details).length) return fail("Please correct the highlighted fields.", 422, details);

    await ensureSeeded();
    const skill = await findOrCreateSkill(name);
    const value = await setProficiency(userId, skill.id, body.proficiency as number, "self");

    await recordProgress(userId, "skill_added", `Added ${skill.name} at ${value}% proficiency.`, null, { skillId: skill.id });
    const workflow = await runAgentWorkflow(userId, { syncRoadmap: true });

    return ok(
      {
        skill: { skillId: skill.id, name: skill.name, category: skill.category, proficiency: value, source: "self" },
        matchPercentage: workflow.matching.matchPercentage,
        message: `${skill.name} saved.`,
      },
      201,
    );
  });
}
