import { asc, desc, eq } from "drizzle-orm";
import { db } from "@/db";
import { mentorConversations } from "@/db/schema";
import { careerMatchingAgent, loadSnapshot, recommendNextAction, skillAssessmentAgent } from "@/lib/agents";
import { cleanString, fail, ok, readJson, requireUser, safely } from "@/lib/http";
import { generateMentorReply, llmConfigured } from "@/lib/mentor";
import { ensureSeeded } from "@/lib/seed";

export const dynamic = "force-dynamic";

/** Returns the saved conversation history (oldest first, last 50 messages). */
export async function GET() {
  return safely("mentor:history", async () => {
    const auth = await requireUser();
    if (auth.response) return auth.response;
    const rows = await db
      .select({
        id: mentorConversations.id,
        role: mentorConversations.role,
        content: mentorConversations.content,
        source: mentorConversations.source,
        createdAt: mentorConversations.createdAt,
      })
      .from(mentorConversations)
      .where(eq(mentorConversations.userId, auth.user.id))
      .orderBy(desc(mentorConversations.createdAt))
      .limit(50);
    return ok({ messages: rows.reverse(), llmConfigured: llmConfigured() });
  });
}

/** Sends a question to the AI Mentor using the learner's real profile, skills and gaps as context. */
export async function POST(req: Request) {
  return safely("mentor:chat", async () => {
    const auth = await requireUser();
    if (auth.response) return auth.response;
    const userId = auth.user.id;
    await ensureSeeded();

    const body = await readJson(req);
    const message = cleanString(body?.message, 1000);
    if (message.length < 2) return fail("Type a question for the mentor.", 422, { message: "Message must be at least 2 characters." });

    const snap = await loadSnapshot(userId);
    const match = careerMatchingAgent(snap);
    const assessment = skillAssessmentAgent(snap);
    const nextAction = recommendNextAction(snap, match);

    const history = await db
      .select({ role: mentorConversations.role, content: mentorConversations.content })
      .from(mentorConversations)
      .where(eq(mentorConversations.userId, userId))
      .orderBy(asc(mentorConversations.createdAt))
      .limit(12);

    const reply = await generateMentorReply({
      snap,
      match,
      assessment,
      nextAction,
      history: history.map((h) => ({ role: h.role as "user" | "assistant", content: h.content })),
      message,
    });

    await db.insert(mentorConversations).values([
      { userId, role: "user", content: message, source: null },
      { userId, role: "assistant", content: reply.reply, source: reply.source },
    ]);

    return ok({
      reply: { content: reply.reply, source: reply.source, label: reply.label, note: reply.note ?? null },
      nextAction,
    }, 201);
  });
}
