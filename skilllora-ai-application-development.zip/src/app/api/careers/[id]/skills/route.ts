import { asc, eq } from "drizzle-orm";
import { db } from "@/db";
import { careerRequiredSkills, careerRoles, learnerSkills, learningResources, skills } from "@/db/schema";
import { fail, ok, requireUser, safely } from "@/lib/http";
import { ensureSeeded } from "@/lib/seed";

export const dynamic = "force-dynamic";

export async function GET(_req: Request, { params }: { params: Promise<{ id: string }> }) {
  return safely("careers:skills", async () => {
    const auth = await requireUser();
    if (auth.response) return auth.response;

    const { id } = await params;
    const careerId = Number(id);
    if (!Number.isInteger(careerId) || careerId < 1) return fail("Invalid career id.", 400);

    await ensureSeeded();
    const [career] = await db
      .select({ id: careerRoles.id, title: careerRoles.title, description: careerRoles.description })
      .from(careerRoles)
      .where(eq(careerRoles.id, careerId))
      .limit(1);
    if (!career) return fail("Career not found.", 404);

    const required = await db
      .select({
        skillId: careerRequiredSkills.skillId,
        name: skills.name,
        category: skills.category,
        requiredLevel: careerRequiredSkills.requiredLevel,
      })
      .from(careerRequiredSkills)
      .innerJoin(skills, eq(careerRequiredSkills.skillId, skills.id))
      .where(eq(careerRequiredSkills.careerId, careerId))
      .orderBy(asc(skills.name));

    const mine = await db
      .select({ skillId: learnerSkills.skillId, proficiency: learnerSkills.proficiency })
      .from(learnerSkills)
      .where(eq(learnerSkills.userId, auth.user.id));
    const current = new Map(mine.map((m) => [m.skillId, m.proficiency]));

    const resources = await db
      .select({
        skillId: learningResources.skillId,
        title: learningResources.title,
        provider: learningResources.provider,
        url: learningResources.url,
        estimatedHours: learningResources.estimatedHours,
      })
      .from(learningResources);

    return ok({
      career,
      skills: required.map((r) => {
        const cur = current.get(r.skillId) ?? 0;
        const threshold = r.requiredLevel * 20;
        return {
          ...r,
          threshold,
          current: cur,
          status: cur >= threshold ? "mastered" : cur > 0 ? "partial" : "missing",
          resources: resources.filter((res) => res.skillId === r.skillId).slice(0, 2),
        };
      }),
    });
  });
}
