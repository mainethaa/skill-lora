import { asc, eq } from "drizzle-orm";
import { db } from "@/db";
import { careerRequiredSkills, careerRoles, learnerProfiles, learnerSkills, skills } from "@/db/schema";
import { getCurrentUser } from "@/lib/auth";
import { ok, safely } from "@/lib/http";
import { ensureSeeded } from "@/lib/seed";

export const dynamic = "force-dynamic";

/**
 * Lists all career roles. When logged in, each career also includes the learner's
 * indicative match percentage (same formula as the Career Matching Agent).
 */
export async function GET() {
  return safely("careers:list", async () => {
    await ensureSeeded();
    const roles = await db
      .select({ id: careerRoles.id, slug: careerRoles.slug, title: careerRoles.title, description: careerRoles.description })
      .from(careerRoles)
      .orderBy(asc(careerRoles.title));

    const requirements = await db
      .select({
        careerId: careerRequiredSkills.careerId,
        skillId: careerRequiredSkills.skillId,
        name: skills.name,
        requiredLevel: careerRequiredSkills.requiredLevel,
      })
      .from(careerRequiredSkills)
      .innerJoin(skills, eq(careerRequiredSkills.skillId, skills.id));

    const user = await getCurrentUser();
    let current = new Map<number, number>();
    let targetCareerId: number | null = null;
    if (user) {
      const rows = await db
        .select({ skillId: learnerSkills.skillId, proficiency: learnerSkills.proficiency })
        .from(learnerSkills)
        .where(eq(learnerSkills.userId, user.id));
      current = new Map(rows.map((r) => [r.skillId, r.proficiency]));
      const [profile] = await db
        .select({ targetCareerId: learnerProfiles.targetCareerId })
        .from(learnerProfiles)
        .where(eq(learnerProfiles.userId, user.id))
        .limit(1);
      targetCareerId = profile?.targetCareerId ?? null;
    }

    const careers = roles.map((role) => {
      const reqs = requirements.filter((r) => r.careerId === role.id);
      const meeting = reqs.filter((r) => (current.get(r.skillId) ?? 0) >= r.requiredLevel * 20).length;
      return {
        ...role,
        requiredSkills: reqs.map((r) => r.name),
        requiredSkillCount: reqs.length,
        matchPercentage: user && reqs.length ? Math.round((meeting / reqs.length) * 100) : null,
        isTarget: role.id === targetCareerId,
      };
    });

    return ok({ careers, authenticated: !!user });
  });
}
