import { and, eq } from "drizzle-orm";
import { db } from "@/db";
import { assessmentResults, assessments, learnerSkills, skills } from "@/db/schema";
import { careerMatchingAgent, loadSnapshot, recordProgress, runAgentWorkflow, setProficiency } from "@/lib/agents";
import { fail, ok, readJson, requireUser, safely } from "@/lib/http";
import { ensureSeeded } from "@/lib/seed";

export const dynamic = "force-dynamic";

/** Weight given to the new assessment score when updating an existing proficiency. */
const ASSESSMENT_WEIGHT = 0.6;

/**
 * Grades an assessment on the server, stores the result, updates skill proficiency,
 * recalculates career match and adapts the roadmap.
 * Proficiency rule: no prior rating -> score. Prior rating -> 60% new score + 40% previous.
 */
export async function POST(req: Request) {
  return safely("assessments:submit", async () => {
    const auth = await requireUser();
    if (auth.response) return auth.response;
    const userId = auth.user.id;
    await ensureSeeded();

    const body = await readJson(req);
    if (!body) return fail("Request body must be a JSON object.", 400);
    const assessmentId = Number(body.assessmentId);
    const answers = body.answers;
    if (!Number.isInteger(assessmentId) || assessmentId < 1) {
      return fail("Invalid assessment.", 422, { assessmentId: "Choose an assessment." });
    }
    if (!Array.isArray(answers)) return fail("Answers must be a list.", 422, { answers: "Provide one answer per question." });

    const [assessment] = await db
      .select({
        id: assessments.id,
        skillId: assessments.skillId,
        title: assessments.title,
        questions: assessments.questions,
        skillName: skills.name,
      })
      .from(assessments)
      .innerJoin(skills, eq(assessments.skillId, skills.id))
      .where(eq(assessments.id, assessmentId))
      .limit(1);
    if (!assessment) return fail("Assessment not found.", 404);

    const total = assessment.questions.length;
    if (answers.length !== total) {
      return fail(`Please answer all ${total} questions.`, 422, { answers: `Expected ${total} answers.` });
    }
    const valid = answers.every((a, i) => Number.isInteger(a) && a >= 0 && a < assessment.questions[i].options.length);
    if (!valid) return fail("One or more answers are invalid.", 422, { answers: "Each answer must match an option." });

    const answerList = answers as number[];
    const explanations = assessment.questions.map((q, i) => ({
      id: q.id,
      prompt: q.prompt,
      options: q.options,
      selectedIndex: answerList[i],
      correctIndex: q.answerIndex,
      correct: answerList[i] === q.answerIndex,
      explanation: q.explanation,
    }));
    const correctCount = explanations.filter((e) => e.correct).length;
    const score = Math.round((correctCount / total) * 100);

    const matchBefore = careerMatchingAgent(await loadSnapshot(userId)).matchPercentage;

    const [existing] = await db
      .select({ proficiency: learnerSkills.proficiency, source: learnerSkills.source })
      .from(learnerSkills)
      .where(and(eq(learnerSkills.userId, userId), eq(learnerSkills.skillId, assessment.skillId)))
      .limit(1);
    const previous = existing?.proficiency ?? 0;
    const updated = existing ? Math.round(ASSESSMENT_WEIGHT * score + (1 - ASSESSMENT_WEIGHT) * previous) : score;
    const newProficiency = await setProficiency(userId, assessment.skillId, updated, "assessment");

    await db.insert(assessmentResults).values({
      userId,
      assessmentId: assessment.id,
      score,
      correctCount,
      totalQuestions: total,
      answers: answerList,
      previousProficiency: previous,
      newProficiency,
    });

    await recordProgress(userId, "assessment_submitted", `Scored ${score}% on ${assessment.title} (proficiency ${previous}% → ${newProficiency}%).`, matchBefore, {
      assessmentId: assessment.id,
      score,
    });

    const workflow = await runAgentWorkflow(userId, { syncRoadmap: true });
    const matchAfter = workflow.matching.matchPercentage;
    const passed = score >= 70;

    const adaptive = passed
      ? `Well done. ${assessment.skillName} is now at ${newProficiency}%. ${workflow.nextAction.title}.`
      : `Your ${assessment.skillName} score is ${score}%. Review the explanations, complete the practice tasks on your roadmap, then retake this check.`;

    return ok({
      result: {
        assessmentId: assessment.id,
        skillName: assessment.skillName,
        score,
        correctCount,
        totalQuestions: total,
        passed,
        previousProficiency: previous,
        newProficiency,
      },
      explanations,
      matchBefore,
      matchAfter,
      matchChange: matchAfter - matchBefore,
      roadmapChanges: workflow.roadmapChanges,
      nextAction: workflow.nextAction,
      adaptiveRecommendation: adaptive,
    }, 201);
  });
}
