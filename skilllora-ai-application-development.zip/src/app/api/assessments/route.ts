import { asc, eq } from "drizzle-orm";
import { db } from "@/db";
import { assessments, skills } from "@/db/schema";
import { loadSnapshot, skillAssessmentAgent } from "@/lib/agents";
import { ok, requireUser, safely } from "@/lib/http";
import { ensureSeeded } from "@/lib/seed";

export const dynamic = "force-dynamic";

/**
 * Lists skill-based assessments (questions WITHOUT answers), the learner's latest scores,
 * assessment history and the Skill Assessment Agent's strengths and weaknesses.
 */
export async function GET() {
  return safely("assessments:list", async () => {
    const auth = await requireUser();
    if (auth.response) return auth.response;
    await ensureSeeded();

    const rows = await db
      .select({
        id: assessments.id,
        skillId: assessments.skillId,
        skillName: skills.name,
        category: skills.category,
        title: assessments.title,
        questions: assessments.questions,
      })
      .from(assessments)
      .innerJoin(skills, eq(assessments.skillId, skills.id))
      .orderBy(asc(skills.name));

    const snap = await loadSnapshot(auth.user.id);
    const analysis = skillAssessmentAgent(snap);
    const latestBySkill = new Map<number, number>();
    for (const h of snap.assessments) {
      if (!latestBySkill.has(h.skillId)) latestBySkill.set(h.skillId, h.score);
    }
    const profBySkill = new Map(snap.learnerSkills.map((s) => [s.skillId, s.proficiency]));

    return ok({
      assessments: rows.map((a) => ({
        id: a.id,
        skillId: a.skillId,
        skillName: a.skillName,
        category: a.category,
        title: a.title,
        questionCount: a.questions.length,
        // Correct answers are never sent to the browser.
        questions: a.questions.map((q) => ({ id: q.id, prompt: q.prompt, options: q.options })),
        latestScore: latestBySkill.get(a.skillId) ?? null,
        currentProficiency: profBySkill.get(a.skillId) ?? null,
      })),
      mySkills: snap.learnerSkills.map((s) => ({ skillId: s.skillId, name: s.name, proficiency: s.proficiency })),
      history: snap.assessments,
      analysis,
    });
  });
}
