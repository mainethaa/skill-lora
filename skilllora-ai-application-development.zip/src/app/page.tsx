import Link from "next/link";
import {
  Bot,
  BrainCircuit,
  ClipboardCheck,
  Compass,
  Gauge,
  Network,
  Route,
  Sparkles,
  Target,
} from "lucide-react";
import { BrandMark, ButtonLink, Card } from "@/components/ui";

const FEATURES = [
  { icon: ClipboardCheck, title: "Skill Assessment", text: "Record what you know, then prove it with short, graded skill checks and clear explanations." },
  { icon: Network, title: "Skill Gap Analysis", text: "See mastered, partially developed and missing skills for any target career, with a transparent formula." },
  { icon: Compass, title: "Career Galaxy", text: "Explore eight career paths, compare required skills and see how closely your profile aligns." },
  { icon: Route, title: "Learning Orbit", text: "A weekly roadmap with resources, practical exercises and mini-projects that adapts as you progress." },
  { icon: Bot, title: "AI Mentor", text: "Ask beginner-friendly questions about your skills, gaps and next steps. Replies are labelled AI or rule-based." },
  { icon: Gauge, title: "Progress Intelligence", text: "Charts, achievements and recent activity built only from your own saved records." },
];

const STEPS = [
  { n: "01", title: "Create your learner profile", text: "Tell us your education, institution, weekly learning time and the skills you already have." },
  { n: "02", title: "Choose a target career", text: "Pick from eight career roles. Each one lists the skills and levels it requires." },
  { n: "03", title: "Let the agents analyse you", text: "Four specialised agents assess your skills, match careers, plan your path and guide you." },
  { n: "04", title: "Learn, assess and adapt", text: "Complete tasks and assessments. Your match and roadmap update automatically." },
];

const AGENTS = [
  { icon: ClipboardCheck, name: "Skill Assessment Agent", text: "Evaluates proficiency and assessment scores, then lists your strengths and weaknesses." },
  { icon: Target, name: "Career Matching Agent", text: "Compares your skills with the career's requirements and calculates your skill-alignment percentage." },
  { icon: Route, name: "Learning Path Agent", text: "Prioritises gaps, recommends resources and schedules tasks into your weekly hours." },
  { icon: Bot, name: "AI Mentor Agent", text: "Explains results in simple language and recommends the next learning action." },
];

const PROBLEM = [
  "Skill gaps are hard to see, for learners and for the institutions that train them.",
  "Most learning platforms show the same course to everyone, regardless of background or goals.",
  "Learners rarely know which skill to learn first, or how much time it will take.",
];

export default function LandingPage() {
  return (
    <div className="overflow-hidden">
      <header className="sticky top-0 z-50 border-b border-white/[0.06] bg-aurora-bg/75 backdrop-blur-xl">
        <div className="mx-auto flex h-16 max-w-7xl items-center justify-between px-4 sm:px-6">
          <Link href="/" aria-label="SkillLora AI home"><BrandMark /></Link>
          <nav aria-label="Primary" className="flex items-center gap-2 sm:gap-3">
            <a href="#features" className="hidden rounded-lg px-3 py-2 text-sm text-aurora-muted hover:text-aurora-text md:inline-block">Features</a>
            <a href="#how" className="hidden rounded-lg px-3 py-2 text-sm text-aurora-muted hover:text-aurora-text md:inline-block">How it works</a>
            <a href="#agents" className="hidden rounded-lg px-3 py-2 text-sm text-aurora-muted hover:text-aurora-text lg:inline-block">AI agents</a>
            <ButtonLink href="/login" variant="ghost" size="sm">Log in</ButtonLink>
            <ButtonLink href="/register" size="sm">Get started</ButtonLink>
          </nav>
        </div>
      </header>

      {/* Hero */}
      <section className="relative mx-auto grid max-w-7xl items-center gap-12 px-4 pb-20 pt-16 sm:px-6 lg:grid-cols-2 lg:pt-24">
        <div className="animate-fade-in">
          <p className="inline-flex items-center gap-2 rounded-full border border-aurora-cyan/25 bg-aurora-cyan/10 px-3 py-1 text-xs font-medium text-aurora-cyan">
            <Sparkles className="h-3.5 w-3.5" aria-hidden /> NEURAL AURORA · Career Intelligence OS
          </p>
          <h1 className="mt-6 text-4xl font-semibold leading-[1.08] tracking-tight sm:text-5xl lg:text-6xl">
            Discover Your Skills.{" "}
            <span className="bg-gradient-to-r from-aurora-cyan via-aurora-mint to-aurora-violet bg-clip-text text-transparent">
              Design Your Future.
            </span>
          </h1>
          <p className="mt-6 max-w-xl text-base leading-relaxed text-aurora-muted sm:text-lg">
            SkillLora AI is an adaptive learning and career guidance platform. It understands what you already know, finds the skills your target career needs, and builds a personalised learning path that updates as you grow.
          </p>
          <div className="mt-8 flex flex-col gap-3 sm:flex-row">
            <ButtonLink href="/register" size="lg">Get started free</ButtonLink>
            <ButtonLink href="/login" variant="secondary" size="lg">I already have an account</ButtonLink>
          </div>
          <p className="mt-4 text-xs text-aurora-muted/80">Your data is stored in your own account and protected by a hashed password and secure session.</p>
        </div>

        {/* Decorative skill-constellation illustration (no data, purely visual) */}
        <div className="relative mx-auto aspect-square w-full max-w-lg" aria-hidden>
          <div className="absolute inset-0 rounded-full bg-[radial-gradient(circle,rgba(155,140,255,0.18),transparent_65%)]" />
          <svg viewBox="0 0 400 400" className="relative h-full w-full">
            <defs>
              <linearGradient id="line" x1="0" x2="1">
                <stop offset="0%" stopColor="#36D9F5" stopOpacity="0.7" />
                <stop offset="100%" stopColor="#61E6B5" stopOpacity="0.2" />
              </linearGradient>
            </defs>
            <circle cx="200" cy="200" r="150" fill="none" stroke="rgba(255,255,255,0.07)" strokeDasharray="4 8" />
            <circle cx="200" cy="200" r="95" fill="none" stroke="rgba(255,255,255,0.08)" strokeDasharray="2 6" />
            {[[200, 50], [330, 120], [340, 270], [220, 352], [70, 300], [60, 130]].map(([x, y], i) => (
              <line key={i} x1="200" y1="200" x2={x} y2={y} stroke="url(#line)" strokeWidth="1.5" />
            ))}
            <line x1="200" y1="50" x2="330" y2="120" stroke="rgba(97,230,181,0.35)" strokeWidth="1" />
            <line x1="330" y1="120" x2="340" y2="270" stroke="rgba(155,140,255,0.35)" strokeWidth="1" />
            <circle cx="200" cy="200" r="34" fill="#101A2E" stroke="#36D9F5" strokeWidth="2" />
            <text x="200" y="205" textAnchor="middle" fill="#F4F7FF" fontSize="13" fontWeight="600">YOU</text>
            {[[200, 50, "#61E6B5"], [330, 120, "#36D9F5"], [340, 270, "#9B8CFF"], [220, 352, "#36D9F5"], [70, 300, "#9B8CFF"], [60, 130, "#61E6B5"]].map(([x, y, c], i) => (
              <g key={i}>
                <circle cx={x as number} cy={y as number} r="13" fill="#101A2E" stroke={c as string} strokeWidth="2" />
                <circle cx={x as number} cy={y as number} r="4" fill={c as string} />
              </g>
            ))}
          </svg>
        </div>
      </section>

      {/* Problem & solution */}
      <section className="mx-auto max-w-7xl px-4 py-16 sm:px-6">
        <div className="grid gap-6 lg:grid-cols-2">
          <Card>
            <p className="text-xs font-semibold uppercase tracking-[0.18em] text-rose-300">The problem</p>
            <h2 className="mt-2 text-2xl font-semibold">Learning is generic. Careers are specific.</h2>
            <ul className="mt-5 space-y-3 text-sm leading-relaxed text-aurora-muted">
              {PROBLEM.map((p) => (<li key={p} className="flex gap-3"><span className="mt-2 h-1.5 w-1.5 shrink-0 rounded-full bg-rose-300" aria-hidden />{p}</li>))}
            </ul>
          </Card>
          <Card className="border-aurora-cyan/20">
            <p className="text-xs font-semibold uppercase tracking-[0.18em] text-aurora-mint">Our solution</p>
            <h2 className="mt-2 text-2xl font-semibold">A personal skill map and a path to your target role.</h2>
            <p className="mt-5 text-sm leading-relaxed text-aurora-muted">
              SkillLora AI measures your current skills, calculates an indicative career match using a transparent formula, and creates a weekly plan that fits the hours you actually have. Every result is saved, so your progress is always there when you return.
            </p>
          </Card>
        </div>
      </section>

      {/* Features */}
      <section id="features" className="mx-auto max-w-7xl scroll-mt-24 px-4 py-16 sm:px-6">
        <div className="mb-10 max-w-2xl">
          <p className="text-xs font-semibold uppercase tracking-[0.18em] text-aurora-cyan">Key features</p>
          <h2 className="mt-2 text-3xl font-semibold tracking-tight">Everything you need to plan a skill journey</h2>
        </div>
        <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
          {FEATURES.map((f) => {
            const Icon = f.icon;
            return (
              <Card key={f.title} className="group transition duration-300 hover:-translate-y-0.5 hover:border-aurora-cyan/30">
                <div className="mb-4 grid h-11 w-11 place-items-center rounded-xl bg-aurora-cyan/10 text-aurora-cyan transition group-hover:bg-aurora-cyan/15">
                  <Icon className="h-5 w-5" aria-hidden />
                </div>
                <h3 className="text-lg font-semibold">{f.title}</h3>
                <p className="mt-2 text-sm leading-relaxed text-aurora-muted">{f.text}</p>
              </Card>
            );
          })}
        </div>
      </section>

      {/* How it works */}
      <section id="how" className="mx-auto max-w-7xl scroll-mt-24 px-4 py-16 sm:px-6">
        <div className="mb-10 max-w-2xl">
          <p className="text-xs font-semibold uppercase tracking-[0.18em] text-aurora-mint">How SkillLora works</p>
          <h2 className="mt-2 text-3xl font-semibold tracking-tight">From first login to a living roadmap</h2>
        </div>
        <ol className="grid gap-5 md:grid-cols-2 lg:grid-cols-4">
          {STEPS.map((s) => (
            <li key={s.n}>
              <Card className="h-full">
                <span className="text-sm font-semibold text-aurora-violet">{s.n}</span>
                <h3 className="mt-3 text-base font-semibold">{s.title}</h3>
                <p className="mt-2 text-sm leading-relaxed text-aurora-muted">{s.text}</p>
              </Card>
            </li>
          ))}
        </ol>
      </section>

      {/* Agents */}
      <section id="agents" className="mx-auto max-w-7xl scroll-mt-24 px-4 py-16 sm:px-6">
        <div className="mb-10 max-w-2xl">
          <p className="text-xs font-semibold uppercase tracking-[0.18em] text-aurora-violet">Adaptive Skill Intelligence Engine</p>
          <h2 className="mt-2 text-3xl font-semibold tracking-tight">Four agents, one shared picture of you</h2>
          <p className="mt-3 text-sm leading-relaxed text-aurora-muted">
            Each agent is a separate function with its own job. They pass structured results to each other in this order: assess, match, plan, then explain. The agents use transparent rules; the AI Mentor can also use an external language model when one is configured.
          </p>
        </div>
        <div className="grid gap-5 sm:grid-cols-2 xl:grid-cols-4">
          {AGENTS.map((a, i) => {
            const Icon = a.icon;
            return (
              <Card key={a.name} className="relative">
                <span className="absolute right-5 top-5 text-xs text-aurora-muted/60">0{i + 1}</span>
                <Icon className="h-6 w-6 text-aurora-violet" aria-hidden />
                <h3 className="mt-4 text-base font-semibold">{a.name}</h3>
                <p className="mt-2 text-sm leading-relaxed text-aurora-muted">{a.text}</p>
              </Card>
            );
          })}
        </div>
      </section>

      {/* Benefits */}
      <section className="mx-auto max-w-7xl px-4 py-16 sm:px-6">
        <div className="grid items-center gap-10 lg:grid-cols-2">
          <div>
            <p className="text-xs font-semibold uppercase tracking-[0.18em] text-aurora-cyan">Benefits</p>
            <h2 className="mt-2 text-3xl font-semibold tracking-tight">Built for students, graduates and the institutions that support them</h2>
            <ul className="mt-6 space-y-4 text-sm leading-relaxed text-aurora-muted">
              <li className="flex gap-3"><BrainCircuit className="mt-0.5 h-5 w-5 shrink-0 text-aurora-cyan" aria-hidden /> Clear, beginner-friendly explanations of every score and recommendation.</li>
              <li className="flex gap-3"><Route className="mt-0.5 h-5 w-5 shrink-0 text-aurora-cyan" aria-hidden /> A roadmap that fits your real weekly learning hours.</li>
              <li className="flex gap-3"><Target className="mt-0.5 h-5 w-5 shrink-0 text-aurora-cyan" aria-hidden /> Honest match scores that are described as indicative, not guarantees.</li>
            </ul>
          </div>
          <Card className="text-center">
            <p className="text-sm text-aurora-muted">Ready to see where you stand?</p>
            <h3 className="mt-2 text-2xl font-semibold">Create your profile in about five minutes.</h3>
            <div className="mt-6 flex flex-col justify-center gap-3 sm:flex-row">
              <ButtonLink href="/register" size="lg">Get started</ButtonLink>
              <ButtonLink href="/login" variant="secondary" size="lg">Log in</ButtonLink>
            </div>
          </Card>
        </div>
      </section>

      <footer className="border-t border-white/[0.06] py-8">
        <div className="mx-auto flex max-w-7xl flex-col items-center justify-between gap-4 px-4 text-xs text-aurora-muted sm:flex-row sm:px-6">
          <BrandMark />
          <p>Discover Your Skills. Design Your Future. · SkillLora AI is an indicative career guidance tool, not a job guarantee.</p>
        </div>
      </footer>
    </div>
  );
}
