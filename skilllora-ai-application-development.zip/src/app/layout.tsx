import type { Metadata } from "next";
import type { ReactNode } from "react";
import { ToastProvider } from "@/components/ui";
import "./globals.css";

export const metadata: Metadata = {
  title: "SkillLora AI – Discover Your Skills. Design Your Future.",
  description:
    "SkillLora AI is an adaptive career intelligence platform that finds your skill gaps and builds a personalised learning roadmap.",
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="en">
      <body>
        <ToastProvider>{children}</ToastProvider>
      </body>
    </html>
  );
}
