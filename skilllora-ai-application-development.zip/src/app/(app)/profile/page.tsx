"use client";

import { useEffect, useState, type FormEvent } from "react";
import { Mail, Save, ShieldCheck, UserRound } from "lucide-react";
import { Badge, Button, Card, ErrorBanner, Field, Input, PageHeader, Select, Skeleton, Textarea, useToast } from "@/components/ui";
import { api, errorMessage } from "@/lib/client-api";
import { EDUCATION_LEVELS } from "@/lib/constants";
import { useApi } from "@/lib/use-api";

type Profile = {
  fullName: string;
  email: string;
  educationLevel: string | null;
  institution: string | null;
  certifications: string[];
  completedProjects: string[];
  targetCareer: { id: number; title: string } | null;
  weeklyHours: number;
  onboardingCompleted: boolean;
  lastMatchPercentage: number | null;
  updatedAt: string;
};

const lines = (text: string) => text.split("\n").map((s) => s.trim()).filter(Boolean);

export default function ProfilePage() {
  const toast = useToast();
  const profileQ = useApi<{ profile: Profile }>("/api/profile");
  const careersQ = useApi<{ careers: { id: number; title: string }[] }>("/api/careers");
  const [form, setForm] = useState({
    fullName: "",
    educationLevel: "",
    institution: "",
    certifications: "",
    completedProjects: "",
    weeklyHours: 5,
    targetCareerId: "",
  });
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    const p = profileQ.data?.profile;
    if (!p) return;
    setForm({
      fullName: p.fullName,
      educationLevel: p.educationLevel ?? "",
      institution: p.institution ?? "",
      certifications: p.certifications.join("\n"),
      completedProjects: p.completedProjects.join("\n"),
      weeklyHours: p.weeklyHours,
      targetCareerId: p.targetCareer ? String(p.targetCareer.id) : "",
    });
  }, [profileQ.data]);

  async function save(e: FormEvent) {
    e.preventDefault();
    const local: Record<string, string> = {};
    if (form.fullName.trim().length < 2) local.fullName = "Name must be at least 2 characters.";
    if (form.weeklyHours < 1 || form.weeklyHours > 40) local.weeklyHours = "Enter 1 to 40 hours.";
    setErrors(local);
    if (Object.keys(local).length) return;

    setSaving(true);
    try {
      await api("/api/profile", {
        method: "PUT",
        body: {
          fullName: form.fullName.trim(),
          educationLevel: form.educationLevel,
          institution: form.institution,
          certifications: lines(form.certifications),
          completedProjects: lines(form.completedProjects),
          weeklyHours: Number(form.weeklyHours),
          targetCareerId: form.targetCareerId ? Number(form.targetCareerId) : null,
        },
      });
      toast.show("success", "Profile saved. Your roadmap was updated if needed.");
      profileQ.reload();
    } catch (err) {
      const message = errorMessage(err);
      setErrors((err as { details?: Record<string, string> }).details ?? {});
      toast.show("error", message);
    } finally {
      setSaving(false);
    }
  }

  if (profileQ.loading && !profileQ.data) return <Skeleton className="h-[560px]" />;
  if (profileQ.error || !profileQ.data) return <ErrorBanner message={profileQ.error ?? "Could not load your profile."} onRetry={profileQ.reload} />;
  const p = profileQ.data.profile;

  return (
    <div className="space-y-6">
      <PageHeader eyebrow="Learner profile" title="Your profile" description="Keep your details up to date. Changes are saved to your account and used by the agents." />

      <div className="grid gap-6 xl:grid-cols-3">
        <Card className="space-y-5 xl:col-span-1">
          <div className="flex items-center gap-4">
            <div className="grid h-16 w-16 place-items-center rounded-2xl bg-gradient-to-br from-aurora-violet to-aurora-cyan text-xl font-bold text-aurora-bg">
              {p.fullName.split(" ").map((x) => x[0]).slice(0, 2).join("").toUpperCase() || "SL"}
            </div>
            <div className="min-w-0">
              <p className="truncate text-lg font-semibold">{p.fullName}</p>
              <p className="flex items-center gap-1.5 truncate text-xs text-aurora-muted"><Mail className="h-3.5 w-3.5" aria-hidden /> {p.email}</p>
            </div>
          </div>
          <div className="grid gap-3 text-sm">
            <div className="flex items-center justify-between rounded-xl bg-aurora-bg/50 p-3"><span className="text-aurora-muted">Target career</span><span className="font-medium">{p.targetCareer?.title ?? "Not selected"}</span></div>
            <div className="flex items-center justify-between rounded-xl bg-aurora-bg/50 p-3"><span className="text-aurora-muted">Last career match</span><span className="font-medium">{p.lastMatchPercentage === null ? "—" : `${p.lastMatchPercentage}%`}</span></div>
            <div className="flex items-center justify-between rounded-xl bg-aurora-bg/50 p-3"><span className="text-aurora-muted">Onboarding</span><Badge tone={p.onboardingCompleted ? "mint" : "amber"}>{p.onboardingCompleted ? "Complete" : "Pending"}</Badge></div>
          </div>
          <p className="flex items-start gap-2 text-xs leading-relaxed text-aurora-muted"><ShieldCheck className="mt-0.5 h-4 w-4 shrink-0 text-aurora-mint" aria-hidden /> Your password is stored only as a salted scrypt hash and is never shown here.</p>
        </Card>

        <Card className="xl:col-span-2">
          <form onSubmit={save} noValidate className="grid gap-5 md:grid-cols-2">
            <div className="md:col-span-2 flex items-center gap-2 text-base font-semibold"><UserRound className="h-4 w-4 text-aurora-cyan" aria-hidden /> Personal & academic details</div>
            <Field label="Full name" htmlFor="pf-name" error={errors.fullName}>
              <Input id="pf-name" value={form.fullName} onChange={(e) => setForm({ ...form, fullName: e.target.value })} maxLength={120} />
            </Field>
            <Field label="Education level" htmlFor="pf-edu" error={errors.educationLevel}>
              <Select id="pf-edu" value={form.educationLevel} onChange={(e) => setForm({ ...form, educationLevel: e.target.value })}>
                <option value="">Select…</option>
                {EDUCATION_LEVELS.map((l) => <option key={l} value={l}>{l}</option>)}
              </Select>
            </Field>
            <Field label="Institution / company" htmlFor="pf-inst">
              <Input id="pf-inst" value={form.institution} onChange={(e) => setForm({ ...form, institution: e.target.value })} maxLength={160} />
            </Field>
            <Field label="Weekly learning hours" htmlFor="pf-hours" error={errors.weeklyHours}>
              <Input id="pf-hours" type="number" min={1} max={40} value={form.weeklyHours} onChange={(e) => setForm({ ...form, weeklyHours: Number(e.target.value) })} />
            </Field>
            <Field label="Target career" htmlFor="pf-career" hint="Changing this re-plans your roadmap automatically.">
              <Select id="pf-career" value={form.targetCareerId} onChange={(e) => setForm({ ...form, targetCareerId: e.target.value })}>
                <option value="">No target career</option>
                {(careersQ.data?.careers ?? []).map((c) => <option key={c.id} value={c.id}>{c.title}</option>)}
              </Select>
            </Field>
            <div />
            <Field label="Certifications" htmlFor="pf-cert" hint="One per line">
              <Textarea id="pf-cert" rows={4} value={form.certifications} onChange={(e) => setForm({ ...form, certifications: e.target.value })} />
            </Field>
            <Field label="Completed projects" htmlFor="pf-proj" hint="One per line">
              <Textarea id="pf-proj" rows={4} value={form.completedProjects} onChange={(e) => setForm({ ...form, completedProjects: e.target.value })} />
            </Field>
            <div className="md:col-span-2 flex justify-end">
              <Button type="submit" loading={saving}><Save className="h-4 w-4" aria-hidden /> Save changes</Button>
            </div>
          </form>
        </Card>
      </div>
    </div>
  );
}
