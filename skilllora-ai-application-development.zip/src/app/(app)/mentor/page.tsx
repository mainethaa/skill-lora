"use client";

import { useEffect, useMemo, useRef, useState, type FormEvent } from "react";
import { Bot, Cpu, Lightbulb, RotateCcw, Send, Sparkles, User } from "lucide-react";
import { Badge, Button, Card, ErrorBanner, PageHeader, Skeleton, Textarea, cn, useToast } from "@/components/ui";
import { api, errorMessage } from "@/lib/client-api";
import { useApi } from "@/lib/use-api";

type Message = { id?: number; role: "user" | "assistant"; content: string; source?: string | null; label?: string; note?: string | null; createdAt?: string };
type HistoryData = { messages: Message[]; llmConfigured: boolean };
type GapsData = {
  targetCareer: { title: string } | null;
  careerMatch: { matchPercentage: number };
  priorities: { name: string }[];
  nextAction: { title: string; description: string; href: string };
};

const BASE_QUESTIONS = [
  "What is my career match and how is it calculated?",
  "What should I learn first?",
  "Explain Git in simple terms.",
  "Suggest a beginner mini-project for my next skill.",
];

export default function MentorPage() {
  const toast = useToast();
  const history = useApi<HistoryData>("/api/mentor/chat");
  const gaps = useApi<GapsData>("/api/skills/gaps");
  const [messages, setMessages] = useState<Message[] | null>(null);
  const [input, setInput] = useState("");
  const [thinking, setThinking] = useState(false);
  const [error, setError] = useState("");
  const endRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (history.data && messages === null) setMessages(history.data.messages);
  }, [history.data, messages]);

  useEffect(() => {
    endRef.current?.scrollIntoView({ behavior: "smooth", block: "end" });
  }, [messages, thinking]);

  const suggestions = useMemo(() => {
    const list: string[] = [];
    const top = gaps.data?.priorities[0]?.name;
    if (top) list.push(`Why is ${top} important for my career?`, `How do I start learning ${top}?`);
    if (gaps.data?.targetCareer) list.push(`What skills do I need to become a ${gaps.data.targetCareer.title}?`);
    return [...list, ...BASE_QUESTIONS].slice(0, 6);
  }, [gaps.data]);

  async function send(text: string) {
    const message = text.trim();
    if (message.length < 2 || thinking) return;
    setError("");
    setInput("");
    setMessages((prev) => [...(prev ?? []), { role: "user", content: message }]);
    setThinking(true);
    try {
      const res = await api<{ reply: { content: string; source: "llm" | "rule-based"; label: string; note: string | null } }>("/api/mentor/chat", {
        method: "POST",
        body: { message },
      });
      setMessages((prev) => [
        ...(prev ?? []),
        { role: "assistant", content: res.reply.content, source: res.reply.source, label: res.reply.label, note: res.reply.note },
      ]);
    } catch (err) {
      setError(errorMessage(err));
      toast.show("error", errorMessage(err));
    } finally {
      setThinking(false);
    }
  }

  async function clearView() {
    setMessages([]);
    toast.show("info", "Chat view cleared. Saved history stays available after refresh.");
  }

  function onSubmit(e: FormEvent) {
    e.preventDefault();
    send(input);
  }

  if (history.loading && !history.data) return <Skeleton className="h-[600px]" />;
  if (history.error || !history.data) return <ErrorBanner message={history.error ?? "Could not load the mentor."} onRetry={history.reload} />;

  const llm = history.data.llmConfigured;

  return (
    <div className="space-y-6">
      <PageHeader
        eyebrow="AI Mentor"
        title="Ask your career mentor"
        description="The mentor reads your saved profile, skills, match score and roadmap before answering. Every reply is labelled with how it was produced."
        actions={<Button variant="ghost" size="sm" onClick={clearView}><RotateCcw className="h-4 w-4" aria-hidden /> Clear view</Button>}
      />

      <div className="grid gap-6 xl:grid-cols-[1fr_300px]">
        <Card className="flex min-h-[620px] flex-col p-0">
          <div className="flex items-center justify-between gap-3 border-b border-white/[0.06] px-5 py-4">
            <div className="flex items-center gap-3">
              <div className="grid h-10 w-10 place-items-center rounded-xl bg-gradient-to-br from-aurora-violet to-aurora-cyan text-aurora-bg"><Bot className="h-5 w-5" aria-hidden /></div>
              <div>
                <p className="font-semibold">SkillLora Mentor</p>
                <p className="text-xs text-aurora-muted">{thinking ? "Thinking…" : "Online"}</p>
              </div>
            </div>
            <Badge tone={llm ? "violet" : "neutral"}>
              <Cpu className="h-3 w-3" aria-hidden /> {llm ? "AI model configured" : "Rule-based mode"}
            </Badge>
          </div>

          <div className="flex-1 space-y-5 overflow-y-auto px-5 py-6" role="log" aria-live="polite" aria-label="Mentor conversation">
            {(messages ?? []).length === 0 && !thinking && (
              <div className="animate-fade-in mx-auto max-w-md py-10 text-center">
                <div className="mx-auto mb-4 grid h-14 w-14 place-items-center rounded-2xl bg-aurora-cyan/10 text-aurora-cyan"><Sparkles className="h-6 w-6" aria-hidden /></div>
                <h2 className="text-lg font-semibold">Hi{gaps.data ? "" : ""}, what would you like to explore?</h2>
                <p className="mt-2 text-sm text-aurora-muted">Choose a suggestion below or type your own question.</p>
              </div>
            )}

            {(messages ?? []).map((m, i) => (
              <div key={m.id ?? `local-${i}`} className={cn("animate-fade-in flex gap-3", m.role === "user" && "flex-row-reverse")}>
                <div className={cn("grid h-8 w-8 shrink-0 place-items-center rounded-lg", m.role === "user" ? "bg-aurora-cyan/15 text-aurora-cyan" : "bg-aurora-violet/15 text-aurora-violet")}>
                  {m.role === "user" ? <User className="h-4 w-4" aria-hidden /> : <Bot className="h-4 w-4" aria-hidden />}
                </div>
                <div className={cn("max-w-[85%] rounded-2xl px-4 py-3 text-sm leading-relaxed", m.role === "user" ? "rounded-tr-sm bg-aurora-cyan/10 text-aurora-text" : "rounded-tl-sm border border-white/[0.07] bg-aurora-bg/60 text-aurora-text")}>
                  <MessageBody content={m.content} />
                  {m.role === "assistant" && (
                    <div className="mt-3 flex flex-wrap items-center gap-2 border-t border-white/[0.06] pt-2 text-[11px]">
                      {m.source === "llm" ? (
                        <Badge tone="violet"><Cpu className="h-3 w-3" aria-hidden /> {m.label ?? "AI-generated"}</Badge>
                      ) : (
                        <Badge tone="neutral"><Lightbulb className="h-3 w-3" aria-hidden /> {m.label ?? "Rule-based"}</Badge>
                      )}
                      {m.note && <span className="text-aurora-muted">{m.note}</span>}
                    </div>
                  )}
                </div>
              </div>
            ))}

            {thinking && (
              <div className="flex gap-3" aria-label="Mentor is typing">
                <div className="grid h-8 w-8 place-items-center rounded-lg bg-aurora-violet/15 text-aurora-violet"><Bot className="h-4 w-4" aria-hidden /></div>
                <div className="flex items-center gap-1.5 rounded-2xl rounded-tl-sm border border-white/[0.07] bg-aurora-bg/60 px-4 py-3">
                  <span className="h-2 w-2 animate-pulse rounded-full bg-aurora-cyan" />
                  <span className="h-2 w-2 animate-pulse rounded-full bg-aurora-mint [animation-delay:150ms]" />
                  <span className="h-2 w-2 animate-pulse rounded-full bg-aurora-violet [animation-delay:300ms]" />
                </div>
              </div>
            )}
            <div ref={endRef} />
          </div>

          <div className="border-t border-white/[0.06] p-4">
            {error && <p role="alert" className="mb-3 text-xs text-rose-300">{error}</p>}
            <div className="mb-3 flex flex-wrap gap-2">
              {suggestions.map((q) => (
                <button key={q} type="button" disabled={thinking} onClick={() => send(q)} className="rounded-full border border-white/10 bg-aurora-bg/50 px-3 py-1.5 text-xs text-aurora-muted transition hover:border-aurora-cyan/40 hover:text-aurora-text disabled:opacity-50">
                  {q}
                </button>
              ))}
            </div>
            <form onSubmit={onSubmit} className="flex items-end gap-2">
              <label htmlFor="mentor-input" className="sr-only">Message the mentor</label>
              <Textarea id="mentor-input" rows={2} value={input} maxLength={1000} onChange={(e) => setInput(e.target.value)} onKeyDown={(e) => { if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); send(input); } }} placeholder="Ask about your skills, gaps, resources or next steps…" className="resize-none" />
              <Button type="submit" disabled={thinking || input.trim().length < 2} aria-label="Send message"><Send className="h-4 w-4" aria-hidden /></Button>
            </form>
          </div>
        </Card>

        <div className="space-y-6">
          <Card>
            <p className="text-xs font-semibold uppercase tracking-wider text-aurora-cyan">Personalised suggestions</p>
            {gaps.loading && !gaps.data ? <Skeleton className="mt-3 h-24" /> : gaps.data?.targetCareer ? (
              <>
                <p className="mt-3 text-sm text-aurora-muted">Target: <span className="text-aurora-text">{gaps.data.targetCareer.title}</span> · {gaps.data.careerMatch.matchPercentage}% match</p>
                <p className="mt-3 text-sm font-medium">Next action</p>
                <p className="text-sm text-aurora-muted">{gaps.data.nextAction.title}</p>
              </>
            ) : (
              <p className="mt-3 text-sm text-aurora-muted">Choose a target career to receive tailored suggestions.</p>
            )}
          </Card>
          <Card>
            <p className="text-xs font-semibold uppercase tracking-wider text-aurora-violet">How replies are produced</p>
            <ul className="mt-3 space-y-3 text-sm text-aurora-muted">
              <li className="flex gap-2"><Cpu className="mt-0.5 h-4 w-4 shrink-0 text-aurora-violet" aria-hidden /> <span><span className="text-aurora-text">AI-generated</span> replies come from an external language model when the server has an API key configured.</span></li>
              <li className="flex gap-2"><Lightbulb className="mt-0.5 h-4 w-4 shrink-0 text-aurora-cyan" aria-hidden /> <span><span className="text-aurora-text">Rule-based</span> replies use fixed logic on your saved data when no key is set or the AI service is unavailable.</span></li>
            </ul>
            <p className="mt-4 text-xs text-aurora-muted/80">{llm ? "An AI model is configured on the server." : "No AI key is configured, so the rule-based mentor is answering."}</p>
          </Card>
        </div>
      </div>
    </div>
  );
}

function MessageBody({ content }: { content: string }) {
  // Safe rendering: split on **bold** markers only; everything else is plain text (no HTML injection).
  const parts = content.split(/(\*\*[^*]+\*\*)/g);
  return (
    <div className="whitespace-pre-line">
      {parts.map((part, i) =>
        part.startsWith("**") && part.endsWith("**") ? <strong key={i} className="font-semibold text-aurora-text">{part.slice(2, -2)}</strong> : <span key={i}>{part}</span>,
      )}
    </div>
  );
}
