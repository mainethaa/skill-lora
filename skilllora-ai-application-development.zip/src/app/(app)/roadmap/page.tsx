"use client";

import { useState } from "react";
import Link from "next/link";
import { BookOpen, Check, ChevronDown, Clock, ExternalLink, FlaskConical, Hammer, RefreshCw, Route, Sparkles } from "lucide-react";
import { Badge, Button, ButtonLink, Card, EmptyState, ErrorBanner, PageHeader, ProgressBar, ProgressRing, Skeleton, cn, useToast } from "@/components/ui";
import { api, errorMessage } from "@/lib/client-api";
import { useApi } from "@/lib/use-api";

type Task = {
  id: number;
  title: string;
  skillName: string;
  category: string;
  priority: number;
  weekNumber: number;
  estimatedHours: number;
  practicalExercise: string;
  miniProject: string;
  status: "pending" | "completed" | "skipped";
  completedAt: string | null;
  resourceTitle: string | null;
  resourceProvider: string | null;
  resourceUrl: string | null;
  resourceType: string | null;
};

type RoadmapData = {
  roadmap: { id: number; generatedBy: string; weeklyHours: number; createdAt: string; careerTitle: string | null } | null;
  targetCareer: { id: number; title: string } | null;
  matchPercentage: number;
  summary: { total: number; completed: number; pending: number; completionPercentage: number };
  tasks: Task[];
  weeklySchedule: { week: number; hours: number; taskIds: number[] }[];
  nextAction: { title: string; description: string; href: string };
};

export default function RoadmapPage() {
  const toast = useToast();
  const { data, error, loading, reload } = useApi<RoadmapData>("/api/roadmap");
  const [busyTask, setBusyTask] = useState<number | null>(null);
  const [generating, setGenerating] = useState(false);

  async function generate() {
    setGenerating(true);
    try {
      const res = await api<{ message: string }>("/api/roadmap/generate", { method: "POST" });
      toast.show("success", res.message);
      reload();
    } catch (err) {
      toast.show("error", errorMessage(err));
    } finally {
      setGenerating(false);
    }
  }

  async function toggle(task: Task) {
    const next = task.status === "completed" ? "pending" : "completed";
    setBusyTask(task.id);
    try {
      const res = await api<{ message: string; proficiencyChange: { skillName: string; from: number; to: number } | null; matchPercentage: number }>(
        `/api/roadmap/tasks/${task.id}`,
        { method: "PATCH", body: { status: next } },
      );
      toast.show("success", res.proficiencyChange ? `${res.proficiencyChange.skillName}: ${res.proficiencyChange.from}% → ${res.proficiencyChange.to}%. Career match ${res.matchPercentage}%.` : res.message);
      reload();
    } catch (err) {
      toast.show("error", errorMessage(err));
    } finally {
      setBusyTask(null);
    }
  }

  if (loading && !data) return <div className="space-y-6"><Skeleton className="h-28" /><Skeleton className="h-96" /></div>;
  if (error || !data) return <ErrorBanner message={error ?? "Could not load your roadmap."} onRetry={reload} />;

  const header = (
    <PageHeader
      eyebrow="Learning orbit"
      title="Your personalised learning roadmap"
      description="Milestones are ordered by priority and scheduled into weeks that fit your weekly learning hours. Completing a task raises that skill's proficiency; passing an assessment confirms it."
      actions={
        data.targetCareer && (
          <Button variant={data.roadmap ? "secondary" : "primary"} onClick={generate} loading={generating}>
            {data.roadmap ? <RefreshCw className="h-4 w-4" aria-hidden /> : <Sparkles className="h-4 w-4" aria-hidden />}
            {data.roadmap ? "Regenerate plan" : "Generate roadmap"}
          </Button>
        )
      }
    />
  );

  if (!data.targetCareer) {
    return (
      <div className="space-y-6">
        {header}
        <EmptyState icon={<Route className="h-6 w-6" />} title="No target career yet" description="A roadmap needs a target career so the agents know which skills to plan for." action={<ButtonLink href="/careers">Choose a career</ButtonLink>} />
      </div>
    );
  }

  if (!data.roadmap) {
    return (
      <div className="space-y-6">
        {header}
        <EmptyState
          icon={<Sparkles className="h-6 w-6" />}
          title={`Ready to plan your path to ${data.targetCareer.title}`}
          description="The Learning Path Agent will rank your skill gaps, pick resources and schedule weekly tasks."
          action={<Button onClick={generate} loading={generating}>Generate my roadmap</Button>}
        />
      </div>
    );
  }

  const pendingTasks = data.tasks.filter((t) => t.status !== "completed");
  const doneTasks = data.tasks.filter((t) => t.status === "completed");
  const weeks = [...new Set(pendingTasks.map((t) => t.weekNumber))].sort((a, b) => a - b);

  return (
    <div className="space-y-6">
      {header}

      <div className="grid gap-6 lg:grid-cols-3">
        <Card className="flex items-center gap-6 lg:col-span-1">
          <ProgressRing value={data.summary.completionPercentage} size={110} stroke={9} />
          <div className="space-y-2 text-sm">
            <p><span className="text-2xl font-semibold text-aurora-mint">{data.summary.completed}</span> <span className="text-aurora-muted">completed</span></p>
            <p><span className="text-2xl font-semibold">{data.summary.pending}</span> <span className="text-aurora-muted">remaining</span></p>
            <p className="text-xs text-aurora-muted">{data.roadmap.weeklyHours} h/week · generated by {data.roadmap.generatedBy}</p>
          </div>
        </Card>
        <Card className="lg:col-span-2">
          <div className="flex items-center justify-between gap-3">
            <div>
              <p className="text-xs font-semibold uppercase tracking-wider text-aurora-cyan">Weekly schedule</p>
              <h2 className="text-base font-semibold">{weeks.length ? `${weeks.length} week${weeks.length > 1 ? "s" : ""} of learning ahead` : "All milestones complete"}</h2>
            </div>
            <Link href={data.nextAction.href} className="text-sm text-aurora-cyan hover:underline">{data.nextAction.title} →</Link>
          </div>
          <div className="mt-4 grid gap-3 sm:grid-cols-2 xl:grid-cols-4">
            {data.weeklySchedule.map((w) => (
              <div key={w.week} className="rounded-xl border border-white/[0.07] bg-aurora-bg/40 p-3">
                <p className="text-xs text-aurora-muted">Week {w.week}</p>
                <p className="text-sm font-semibold">{w.taskIds.length} task(s)</p>
                <p className="text-xs text-aurora-muted">{w.hours} h planned</p>
                <div className="mt-2"><ProgressBar value={Math.min(100, (w.hours / data.roadmap!.weeklyHours) * 100)} /></div>
              </div>
            ))}
          </div>
        </Card>
      </div>

      {data.tasks.length === 0 ? (
        <EmptyState icon={<Check className="h-6 w-6" />} title="No gaps left to close" description="Your skills already meet the target for this career. Try a different career to keep growing." />
      ) : (
        <ol className="relative space-y-6 border-l border-dashed border-aurora-cyan/25 pl-6 sm:pl-8" aria-label="Learning milestones">
          {(weeks.length ? weeks : []).map((week) => (
            <li key={week} className="space-y-4">
              <span className="absolute -left-[7px] mt-1.5 h-3.5 w-3.5 rounded-full border-2 border-aurora-cyan bg-aurora-bg" aria-hidden />
              <p className="text-xs font-semibold uppercase tracking-[0.16em] text-aurora-cyan">Week {week}</p>
              {pendingTasks.filter((t) => t.weekNumber === week).map((t) => (
                <TaskCard key={t.id} task={t} busy={busyTask === t.id} onToggle={() => toggle(t)} />
              ))}
            </li>
          ))}
          {doneTasks.length > 0 && (
            <li className="space-y-4">
              <span className="absolute -left-[7px] mt-1.5 h-3.5 w-3.5 rounded-full bg-aurora-mint" aria-hidden />
              <p className="text-xs font-semibold uppercase tracking-[0.16em] text-aurora-mint">Completed milestones</p>
              {doneTasks.map((t) => (
                <TaskCard key={t.id} task={t} busy={busyTask === t.id} onToggle={() => toggle(t)} />
              ))}
            </li>
          )}
        </ol>
      )}
    </div>
  );
}

function TaskCard({ task, busy, onToggle }: { task: Task; busy: boolean; onToggle: () => void }) {
  const [open, setOpen] = useState(false);
  const done = task.status === "completed";
  return (
    <Card className={cn("transition duration-300", done && "border-aurora-mint/20 bg-aurora-mint/[0.03]")}>
      <div className="flex items-start gap-4">
        <button
          type="button"
          onClick={onToggle}
          disabled={busy}
          aria-pressed={done}
          aria-label={done ? `Reopen ${task.title}` : `Mark ${task.title} as completed`}
          className={cn("mt-0.5 grid h-7 w-7 shrink-0 place-items-center rounded-lg border transition hover:scale-105 disabled:opacity-50", done ? "border-aurora-mint bg-aurora-mint text-aurora-bg" : "border-white/20 hover:border-aurora-cyan")}
        >
          {done && <Check className="h-4 w-4" aria-hidden />}
        </button>
        <div className="min-w-0 flex-1">
          <div className="flex flex-wrap items-center gap-2">
            <h3 className={cn("font-semibold", done && "text-aurora-muted line-through")}>{task.title}</h3>
            <Badge tone={task.priority <= 2 ? "rose" : task.priority <= 4 ? "amber" : "neutral"}>Priority {task.priority}</Badge>
            <Badge tone="cyan">{task.category}</Badge>
          </div>
          <p className="mt-1 flex items-center gap-1.5 text-xs text-aurora-muted"><Clock className="h-3.5 w-3.5" aria-hidden /> About {task.estimatedHours} hours{done && task.completedAt ? ` · completed ${new Date(task.completedAt).toLocaleDateString()}` : ""}</p>

          {task.resourceUrl && (
            <a href={task.resourceUrl} target="_blank" rel="noopener noreferrer" className="mt-3 inline-flex items-center gap-2 rounded-lg border border-white/10 bg-aurora-bg/50 px-3 py-2 text-xs text-aurora-text hover:border-aurora-cyan/40">
              <BookOpen className="h-3.5 w-3.5 text-aurora-cyan" aria-hidden /> {task.resourceTitle} · {task.resourceProvider} <ExternalLink className="h-3 w-3 text-aurora-muted" aria-hidden />
            </a>
          )}

          <button type="button" onClick={() => setOpen((v) => !v)} aria-expanded={open} className="mt-3 flex items-center gap-1 text-xs font-medium text-aurora-cyan hover:underline">
            <ChevronDown className={cn("h-3.5 w-3.5 transition-transform", open && "rotate-180")} aria-hidden /> {open ? "Hide" : "Show"} exercise & mini-project
          </button>
          {open && (
            <div className="animate-fade-in mt-3 grid gap-3 md:grid-cols-2">
              <div className="rounded-xl bg-aurora-bg/50 p-3 text-sm">
                <p className="mb-1 flex items-center gap-2 font-semibold"><FlaskConical className="h-4 w-4 text-aurora-mint" aria-hidden /> Practical exercise</p>
                <p className="leading-relaxed text-aurora-muted">{task.practicalExercise}</p>
              </div>
              <div className="rounded-xl bg-aurora-bg/50 p-3 text-sm">
                <p className="mb-1 flex items-center gap-2 font-semibold"><Hammer className="h-4 w-4 text-aurora-violet" aria-hidden /> Mini-project</p>
                <p className="leading-relaxed text-aurora-muted">{task.miniProject}</p>
              </div>
            </div>
          )}
        </div>
      </div>
    </Card>
  );
}
