"use client";

import Link from "next/link";
import { AlertTriangle, ArrowRight, CheckCircle2, CircleDashed, Compass, Info, Route } from "lucide-react";
import { Badge, ButtonLink, Card, EmptyState, ErrorBanner, PageHeader, ProgressBar, ProgressRing, Skeleton } from "@/components/ui";
import { SkillComparisonChart, SkillRadarChart } from "@/components/charts";
import { SkillConstellation, type ConstellationNode } from "@/components/skill-constellation";
import { useApi } from "@/lib/use-api";

type Gap = { skillId: number; name: string; category: string; requiredLevel: number; threshold: number; current: number; gap: number; priorityScore: number; status: "mastered" | "partial" | "missing" };
type GapData = {
  targetCareer: { id: number; title: string; description: string } | null;
  skillAssessment: { summary: string; strengths: { name: string; proficiency: number }[]; weaknesses: { name: string; proficiency: number; reason: string }[] };
  careerMatch: {
    matchPercentage: number;
    formula: string;
    totalRequired: number;
    meetingThreshold: number;
    mastered: Gap[];
    partial: Gap[];
    missing: Gap[];
    comparison: { skillName: string; required: number; current: number; status: string }[];
    disclaimer: string;
  };
  priorities: Gap[];
  nextAction: { title: string; description: string; href: string };
};

export default function GapAnalysisPage() {
  const { data, error, loading, reload } = useApi<GapData>("/api/skills/gaps");

  if (loading && !data) return <div className="space-y-6"><Skeleton className="h-24" /><Skeleton className="h-96" /><Skeleton className="h-72" /></div>;
  if (error || !data) return <ErrorBanner message={error ?? "Could not run the gap analysis."} onRetry={reload} />;

  if (!data.targetCareer) {
    return (
      <div className="space-y-6">
        <PageHeader eyebrow="Skill gap analysis" title="Skill gap analysis" />
        <EmptyState
          icon={<Compass className="h-6 w-6" />}
          title="Choose a target career first"
          description="The Career Matching Agent compares your skills with one career at a time. Pick a career to see your gaps."
          action={<ButtonLink href="/careers">Explore careers</ButtonLink>}
        />
      </div>
    );
  }

  const m = data.careerMatch;
  const constellation: ConstellationNode[] = [
    ...m.mastered.map((s) => ({ key: `m-${s.skillId}`, name: s.name, current: s.current, threshold: s.threshold, category: "mastered" as const })),
    ...m.partial.map((s) => ({ key: `l-${s.skillId}`, name: s.name, current: s.current, threshold: s.threshold, category: "learning" as const })),
    ...m.missing.map((s) => ({ key: `x-${s.skillId}`, name: s.name, current: s.current, threshold: s.threshold, category: "missing" as const })),
    ...data.priorities.slice(0, 4).map((s) => ({ key: `r-${s.skillId}`, name: s.name, current: s.current, threshold: s.threshold, category: "recommended" as const })),
  ];
  const chartData = m.comparison.map((c) => ({ skillName: c.skillName, required: c.required, current: c.current }));

  return (
    <div className="space-y-6">
      <PageHeader
        eyebrow="Skill gap analysis"
        title={`Gap analysis · ${data.targetCareer.title}`}
        description="A side-by-side view of what the role requires and what you can already do, produced by the Skill Assessment and Career Matching agents."
        actions={<ButtonLink href="/roadmap" variant="secondary"><Route className="h-4 w-4" aria-hidden /> Open roadmap</ButtonLink>}
      />

      <div className="grid gap-6 xl:grid-cols-3">
        <Card className="flex flex-col items-center text-center xl:col-span-1">
          <ProgressRing value={m.matchPercentage} size={170} sublabel="career match" />
          <p className="mt-4 text-sm text-aurora-muted">{m.meetingThreshold} of {m.totalRequired} required skills meet the target</p>
          <div className="mt-5 w-full rounded-xl bg-aurora-bg/50 p-4 text-left text-xs leading-relaxed text-aurora-muted">
            <p className="flex items-center gap-2 font-semibold text-aurora-text"><Info className="h-3.5 w-3.5 text-aurora-cyan" aria-hidden /> Formula</p>
            <p className="mt-2">{m.formula}</p>
          </div>
          <p className="mt-4 text-xs leading-relaxed text-aurora-muted/90">{m.disclaimer}</p>
        </Card>

        <Card className="xl:col-span-2">
          <div className="mb-4 flex flex-wrap items-center justify-between gap-3">
            <div>
              <h2 className="text-base font-semibold">Skill constellation</h2>
              <p className="text-xs text-aurora-muted">Select a node to inspect a skill</p>
            </div>
          </div>
          <SkillConstellation nodes={constellation} />
        </Card>
      </div>

      <div className="grid gap-4 md:grid-cols-4">
        <StatTile icon={<CheckCircle2 className="h-5 w-5 text-aurora-mint" />} label="Mastered" value={m.mastered.length} tone="mint" />
        <StatTile icon={<CircleDashed className="h-5 w-5 text-aurora-cyan" />} label="Partially developed" value={m.partial.length} tone="cyan" />
        <StatTile icon={<AlertTriangle className="h-5 w-5 text-rose-300" />} label="Missing" value={m.missing.length} tone="rose" />
        <StatTile icon={<Compass className="h-5 w-5 text-aurora-violet" />} label="Required skills" value={m.totalRequired} tone="violet" />
      </div>

      <div className="grid gap-6 xl:grid-cols-2">
        <Card>
          <h2 className="text-base font-semibold">Current vs. target</h2>
          <p className="mb-4 text-xs text-aurora-muted">Target = required level × 20</p>
          <SkillComparisonChart data={chartData} />
        </Card>
        <Card>
          <h2 className="text-base font-semibold">Skill profile radar</h2>
          <p className="mb-2 text-xs text-aurora-muted">Shape shows where you are below the target line</p>
          <SkillRadarChart data={chartData} />
        </Card>
      </div>

      <div className="grid gap-6 xl:grid-cols-3">
        <Card className="xl:col-span-2">
          <h2 className="mb-4 text-base font-semibold">Priority gaps</h2>
          {data.priorities.length === 0 ? (
            <EmptyState icon={<CheckCircle2 className="h-6 w-6" />} title="No gaps detected" description="You meet every threshold for this career. Consider a deeper assessment or a new target." />
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full min-w-[520px] text-left text-sm">
                <thead className="text-xs uppercase tracking-wider text-aurora-muted">
                  <tr className="border-b border-white/[0.06]">
                    <th className="py-2 pr-3 font-medium">#</th>
                    <th className="py-2 pr-3 font-medium">Skill</th>
                    <th className="py-2 pr-3 font-medium">Status</th>
                    <th className="py-2 pr-3 font-medium">Current → Target</th>
                    <th className="py-2 font-medium">Gap</th>
                  </tr>
                </thead>
                <tbody>
                  {data.priorities.map((g, i) => (
                    <tr key={g.skillId} className="border-b border-white/[0.04] align-middle">
                      <td className="py-3 pr-3 text-aurora-muted">{i + 1}</td>
                      <td className="py-3 pr-3"><span className="font-medium">{g.name}</span> <span className="block text-xs text-aurora-muted">{g.category}</span></td>
                      <td className="py-3 pr-3"><Badge tone={g.status === "missing" ? "rose" : "amber"}>{g.status === "missing" ? "Missing" : "Partial"}</Badge></td>
                      <td className="py-3 pr-3 text-aurora-muted">{g.current}% → {g.threshold}%</td>
                      <td className="py-3"><div className="w-28"><ProgressBar value={100 - g.gap} tone="amber" /></div></td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </Card>

        <div className="space-y-6">
          <Card>
            <h2 className="text-base font-semibold">Strengths & weaknesses</h2>
            <p className="mt-2 text-sm leading-relaxed text-aurora-muted">{data.skillAssessment.summary}</p>
            <p className="mt-4 text-xs font-semibold uppercase tracking-wider text-aurora-mint">Strengths</p>
            <ul className="mt-2 space-y-1 text-sm">
              {data.skillAssessment.strengths.length ? data.skillAssessment.strengths.map((s) => <li key={s.name} className="flex justify-between"><span>{s.name}</span><span className="text-aurora-mint">{s.proficiency}%</span></li>) : <li className="text-aurora-muted">None yet</li>}
            </ul>
            <p className="mt-4 text-xs font-semibold uppercase tracking-wider text-rose-300">Weaknesses</p>
            <ul className="mt-2 space-y-2 text-sm">
              {data.skillAssessment.weaknesses.length ? data.skillAssessment.weaknesses.map((w) => <li key={w.name}><span>{w.name}</span> <span className="text-xs text-aurora-muted">— {w.reason}</span></li>) : <li className="text-aurora-muted">No weak areas</li>}
            </ul>
          </Card>

          <Card className="border-aurora-mint/20">
            <p className="text-xs font-semibold uppercase tracking-wider text-aurora-mint">Recommended next action</p>
            <h3 className="mt-2 font-semibold">{data.nextAction.title}</h3>
            <p className="mt-1 text-sm text-aurora-muted">{data.nextAction.description}</p>
            <Link href={data.nextAction.href} className="mt-4 inline-flex items-center gap-2 text-sm font-medium text-aurora-cyan hover:underline">
              Go there <ArrowRight className="h-4 w-4" aria-hidden />
            </Link>
          </Card>
        </div>
      </div>
    </div>
  );
}

function StatTile({ icon, label, value, tone }: { icon: React.ReactNode; label: string; value: number; tone: "mint" | "cyan" | "rose" | "violet" }) {
  const ring = { mint: "border-aurora-mint/20", cyan: "border-aurora-cyan/20", rose: "border-rose-400/20", violet: "border-aurora-violet/20" }[tone];
  return (
    <div className={`rounded-2xl border ${ring} bg-aurora-surface/70 p-4`}>
      <div className="flex items-center justify-between">
        <span className="text-xs text-aurora-muted">{label}</span>
        {icon}
      </div>
      <p className="mt-2 text-2xl font-semibold">{value}</p>
    </div>
  );
}
