"use client";

import { Award, Lock, Activity, CheckCircle2, ListChecks, TrendingUp } from "lucide-react";
import { Badge, ButtonLink, Card, EmptyState, ErrorBanner, PageHeader, ProgressBar, ProgressRing, Skeleton, cn } from "@/components/ui";
import { WeeklyActivityChart } from "@/components/charts";
import { levelLabel } from "@/lib/constants";
import { useApi } from "@/lib/use-api";

type Analytics = {
  career: { id: number; title: string } | null;
  matchPercentage: number;
  matchFormula: string;
  disclaimer: string;
  roadmap: { exists: boolean; total: number; completed: number; pending: number; completionPercentage: number };
  skills: { total: number; mastered: number; partial: number; missing: number; averageProficiency: number; needsImprovement: number };
  skillComparison: { skillName: string; required: number; current: number; status: string }[];
  weeklyActivity: { day: string; count: number }[];
  recentActivities: { id: number; activityType: string; description: string; matchPercentage: number | null; createdAt: string }[];
  totalActivities: number;
  assessmentHistory: { id: number; skillName: string; title: string; score: number; previousProficiency: number; newProficiency: number; createdAt: string }[];
  achievements: { id: string; title: string; description: string; unlocked: boolean }[];
  nextAction: { title: string; description: string; href: string };
  strengths: { name: string; proficiency: number }[];
  weaknesses: { name: string; proficiency: number; reason: string }[];
};

export default function ProgressPage() {
  const { data, error, loading, reload } = useApi<{ analytics: Analytics }>("/api/progress/analytics");

  if (loading && !data) return <div className="space-y-6"><Skeleton className="h-40" /><div className="grid gap-6 xl:grid-cols-2"><Skeleton className="h-80" /><Skeleton className="h-80" /></div></div>;
  if (error || !data) return <ErrorBanner message={error ?? "Could not load analytics."} onRetry={reload} />;

  const a = data.analytics;
  const unlocked = a.achievements.filter((x) => x.unlocked).length;
  const nothingYet = a.totalActivities === 0 && a.skills.total === 0;

  return (
    <div className="space-y-6">
      <PageHeader
        eyebrow="Progress intelligence"
        title="Your learning progress"
        description="Every number on this page is calculated from your saved profile, skills, assessments and roadmap activity."
      />

      {nothingYet && (
        <EmptyState icon={<TrendingUp className="h-6 w-6" />} title="Nothing to measure yet" description="Add skills, pick a career and complete a roadmap task to start your progress timeline." action={<ButtonLink href="/assessments">Add your skills</ButtonLink>} />
      )}

      <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-4">
        <KpiCard icon={<Activity className="h-4 w-4" />} label="Career match" value={`${a.matchPercentage}%`} hint={a.career?.title ?? "No career selected"} />
        <KpiCard icon={<ListChecks className="h-4 w-4" />} label="Roadmap tasks done" value={`${a.roadmap.completed}/${a.roadmap.total}`} hint={`${a.roadmap.pending} remaining`} />
        <KpiCard icon={<CheckCircle2 className="h-4 w-4" />} label="Skills mastered" value={`${a.skills.mastered}`} hint={`of ${a.skills.total} tracked skills`} />
        <KpiCard icon={<Award className="h-4 w-4" />} label="Achievements" value={`${unlocked}/${a.achievements.length}`} hint="unlocked" />
      </div>

      <div className="grid gap-6 xl:grid-cols-3">
        <Card className="flex flex-col items-center gap-4 text-center">
          <p className="text-sm font-semibold">Overall roadmap completion</p>
          <ProgressRing value={a.roadmap.completionPercentage} size={160} sublabel={a.roadmap.exists ? "complete" : "no roadmap yet"} />
          <p className="text-xs leading-relaxed text-aurora-muted">{a.matchFormula}</p>
          <p className="text-[11px] leading-relaxed text-aurora-muted/80">{a.disclaimer}</p>
        </Card>

        <Card className="xl:col-span-2">
          <div className="mb-4 flex items-center justify-between">
            <div>
              <h2 className="text-base font-semibold">Weekly learning activity</h2>
              <p className="text-xs text-aurora-muted">Saved actions per day, last 7 days</p>
            </div>
            <Badge tone="mint">{a.weeklyActivity.reduce((s, d) => s + d.count, 0)} this week</Badge>
          </div>
          <WeeklyActivityChart data={a.weeklyActivity} />
        </Card>
      </div>

      <div className="grid gap-6 xl:grid-cols-2">
        <Card>
          <h2 className="text-base font-semibold">Skill progress</h2>
          <p className="mb-5 text-xs text-aurora-muted">Required skills for {a.career?.title ?? "your target career"}</p>
          {a.skillComparison.length === 0 ? (
            <p className="text-sm text-aurora-muted">Select a target career to see required-skill progress.</p>
          ) : (
            <ul className="space-y-4">
              {a.skillComparison.map((s) => (
                <li key={s.skillName}>
                  <div className="mb-1.5 flex items-center justify-between gap-3 text-sm">
                    <span className="font-medium">{s.skillName}</span>
                    <span className="text-xs text-aurora-muted">{levelLabel(s.current)} · {s.current}% / {s.required}%</span>
                  </div>
                  <ProgressBar value={s.current} tone={s.status === "mastered" ? "mint" : s.status === "partial" ? "amber" : "violet"} />
                </li>
              ))}
            </ul>
          )}
        </Card>

        <Card>
          <h2 className="text-base font-semibold">Assessment history</h2>
          <p className="mb-4 text-xs text-aurora-muted">Scores and how each proficiency changed</p>
          {a.assessmentHistory.length === 0 ? (
            <EmptyState icon={<CheckCircle2 className="h-6 w-6" />} title="No assessments yet" description="Take a skill check to see your scores and proficiency updates here." action={<ButtonLink href="/assessments" size="sm">Take a check</ButtonLink>} />
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full min-w-[460px] text-left text-sm">
                <thead className="text-xs uppercase tracking-wider text-aurora-muted">
                  <tr className="border-b border-white/[0.06]"><th className="py-2 pr-3 font-medium">Skill</th><th className="py-2 pr-3 font-medium">Score</th><th className="py-2 pr-3 font-medium">Proficiency</th><th className="py-2 font-medium">Date</th></tr>
                </thead>
                <tbody>
                  {a.assessmentHistory.map((h) => (
                    <tr key={h.id} className="border-b border-white/[0.04]">
                      <td className="py-2.5 pr-3">{h.skillName}</td>
                      <td className={cn("py-2.5 pr-3 font-semibold", h.score >= 70 ? "text-aurora-mint" : "text-amber-200")}>{h.score}%</td>
                      <td className="py-2.5 pr-3 text-aurora-muted">{h.previousProficiency}% → {h.newProficiency}%</td>
                      <td className="py-2.5 text-aurora-muted">{new Date(h.createdAt).toLocaleDateString()}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </Card>
      </div>

      <div className="grid gap-6 xl:grid-cols-3">
        <Card>
          <h2 className="mb-4 text-base font-semibold">Achievements</h2>
          <ul className="grid gap-3 sm:grid-cols-2 xl:grid-cols-1">
            {a.achievements.map((ach) => (
              <li key={ach.id} className={cn("flex items-start gap-3 rounded-xl border p-3", ach.unlocked ? "border-aurora-mint/25 bg-aurora-mint/5" : "border-white/[0.06] opacity-60")}>
                {ach.unlocked ? <Award className="mt-0.5 h-4 w-4 shrink-0 text-aurora-mint" aria-hidden /> : <Lock className="mt-0.5 h-4 w-4 shrink-0 text-aurora-muted" aria-hidden />}
                <div><p className="text-sm font-semibold">{ach.title}</p><p className="text-xs text-aurora-muted">{ach.description}</p></div>
              </li>
            ))}
          </ul>
        </Card>

        <Card>
          <h2 className="mb-4 text-base font-semibold">Recent activity</h2>
          {a.recentActivities.length === 0 ? (
            <p className="text-sm text-aurora-muted">No activity recorded yet.</p>
          ) : (
            <ul className="space-y-3">
              {a.recentActivities.map((r) => (
                <li key={r.id} className="border-l-2 border-aurora-cyan/30 pl-3 text-sm">
                  <p className="leading-relaxed">{r.description}</p>
                  <p className="text-xs text-aurora-muted">{new Date(r.createdAt).toLocaleString()}{r.matchPercentage !== null ? ` · match ${r.matchPercentage}%` : ""}</p>
                </li>
              ))}
            </ul>
          )}
        </Card>

        <Card>
          <h2 className="mb-4 text-base font-semibold">Recommended next action</h2>
          <p className="font-semibold">{a.nextAction.title}</p>
          <p className="mt-1 text-sm leading-relaxed text-aurora-muted">{a.nextAction.description}</p>
          <ButtonLink href={a.nextAction.href} className="mt-5">Continue</ButtonLink>
          <div className="mt-6 space-y-2 text-sm">
            <p className="text-xs font-semibold uppercase tracking-wider text-aurora-mint">Strengths</p>
            {a.strengths.length ? a.strengths.map((s) => <p key={s.name} className="flex justify-between"><span>{s.name}</span><span className="text-aurora-mint">{s.proficiency}%</span></p>) : <p className="text-aurora-muted">None yet</p>}
            <p className="pt-2 text-xs font-semibold uppercase tracking-wider text-rose-300">Needs improvement</p>
            {a.weaknesses.length ? a.weaknesses.slice(0, 4).map((w) => <p key={w.name} className="flex justify-between"><span>{w.name}</span><span className="text-aurora-muted">{w.proficiency}%</span></p>) : <p className="text-aurora-muted">No weak areas</p>}
          </div>
        </Card>
      </div>
    </div>
  );
}

function KpiCard({ icon, label, value, hint }: { icon: React.ReactNode; label: string; value: string; hint: string }) {
  return (
    <div className="rounded-2xl border border-white/[0.07] bg-aurora-surface/70 p-5">
      <div className="flex items-center justify-between text-xs text-aurora-muted"><span>{label}</span><span className="text-aurora-cyan">{icon}</span></div>
      <p className="mt-3 text-3xl font-semibold tracking-tight">{value}</p>
      <p className="mt-1 truncate text-xs text-aurora-muted">{hint}</p>
    </div>
  );
}
