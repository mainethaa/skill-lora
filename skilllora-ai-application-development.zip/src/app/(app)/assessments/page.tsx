"use client";

import { useState, type FormEvent } from "react";
import { CheckCircle2, ClipboardCheck, Lightbulb, Plus, Save, Target, XCircle } from "lucide-react";
import { Badge, Button, ButtonLink, Card, EmptyState, ErrorBanner, Field, Input, PageHeader, ProgressBar, Select, Skeleton, cn, useToast } from "@/components/ui";
import { api, errorMessage } from "@/lib/client-api";
import { PROFICIENCY_LEVELS, levelLabel } from "@/lib/constants";
import { useApi } from "@/lib/use-api";

type Question = { id: string; prompt: string; options: string[] };
type AssessmentItem = {
  id: number;
  skillId: number;
  skillName: string;
  category: string;
  title: string;
  questionCount: number;
  questions: Question[];
  latestScore: number | null;
  currentProficiency: number | null;
};
type HistoryItem = { id: number; skillName: string; title: string; score: number; previousProficiency: number; newProficiency: number; createdAt: string };
type Explanation = { id: string; prompt: string; options: string[]; selectedIndex: number; correctIndex: number; correct: boolean; explanation: string };
type SubmitResult = {
  result: { skillName: string; score: number; correctCount: number; totalQuestions: number; passed: boolean; previousProficiency: number; newProficiency: number };
  explanations: Explanation[];
  matchBefore: number;
  matchAfter: number;
  matchChange: number;
  nextAction: { title: string; description: string; href: string };
  adaptiveRecommendation: string;
};
type AssessmentsData = {
  assessments: AssessmentItem[];
  mySkills: { skillId: number; name: string; proficiency: number }[];
  history: HistoryItem[];
  analysis: {
    averageProficiency: number;
    assessedSkillCount: number;
    summary: string;
    strengths: { skillId: number; name: string; proficiency: number }[];
    weaknesses: { skillId: number; name: string; proficiency: number; reason: string }[];
  };
};

export default function AssessmentsPage() {
  const { data, error, loading, reload } = useApi<AssessmentsData>("/api/assessments");
  const [activeId, setActiveId] = useState<number | null>(null);
  const [result, setResult] = useState<SubmitResult | null>(null);

  if (loading && !data) return <Skeleton className="h-[480px]" />;
  if (error || !data) return <ErrorBanner message={error ?? "Could not load assessments."} onRetry={reload} />;

  const active = data.assessments.find((a) => a.id === activeId) ?? null;

  return (
    <div className="space-y-6">
      <PageHeader
        eyebrow="Skill assessment"
        title="Prove what you know"
        description="Add your skills, take short graded checks and watch your proficiency update. Results are saved to your account."
      />

      <div className="grid gap-6 xl:grid-cols-3">
        <div className="space-y-6 xl:col-span-2">
          <SkillManager skills={data.mySkills} onChanged={reload} />

          <Card>
            <div className="mb-4 flex items-center justify-between gap-3">
              <div>
                <h2 className="text-base font-semibold">Skill checks</h2>
                <p className="text-xs text-aurora-muted">Three multiple-choice questions per skill. Scores of 70% or more count as a pass.</p>
              </div>
            </div>
            {data.assessments.length === 0 ? (
              <EmptyState icon={<ClipboardCheck className="h-6 w-6" />} title="No assessments available" description="The sample assessment bank could not be loaded. Refresh the page." />
            ) : (
              <div className="grid gap-3 md:grid-cols-2">
                {data.assessments.map((a) => (
                  <div key={a.id} className={cn("flex flex-col justify-between gap-3 rounded-2xl border p-4 transition", activeId === a.id ? "border-aurora-cyan/50 bg-aurora-cyan/5" : "border-white/[0.07] bg-aurora-bg/40")}>
                    <div>
                      <div className="flex items-center justify-between gap-2">
                        <p className="font-semibold">{a.skillName}</p>
                        <Badge tone="neutral">{a.category}</Badge>
                      </div>
                      <p className="mt-2 text-xs text-aurora-muted">
                        {a.questionCount} questions · Latest score: {a.latestScore === null ? "not taken" : `${a.latestScore}%`}
                      </p>
                    </div>
                    <Button variant={activeId === a.id ? "secondary" : "primary"} size="sm" onClick={() => { setActiveId(a.id); setResult(null); }}>
                      {activeId === a.id ? "Selected" : a.latestScore === null ? "Start check" : "Retake check"}
                    </Button>
                  </div>
                ))}
              </div>
            )}
          </Card>

          {active && !result && <QuizPanel key={active.id} assessment={active} onSubmitted={(r) => { setResult(r); reload(); }} />}
          {active && result && (
            <ResultPanel
              result={result}
              onRetake={() => setResult(null)}
            />
          )}
        </div>

        <div className="space-y-6">
          <Card>
            <h2 className="text-base font-semibold">Skill Assessment Agent</h2>
            <p className="mt-1 text-xs text-aurora-muted">Rule-based evaluation of your skills</p>
            <p className="mt-4 text-sm leading-relaxed text-aurora-muted">{data.analysis.summary}</p>
            <div className="mt-5 grid grid-cols-2 gap-3">
              <div className="rounded-xl bg-aurora-bg/50 p-3"><p className="text-xs text-aurora-muted">Average</p><p className="text-xl font-semibold">{data.analysis.averageProficiency}%</p></div>
              <div className="rounded-xl bg-aurora-bg/50 p-3"><p className="text-xs text-aurora-muted">Skills</p><p className="text-xl font-semibold">{data.analysis.assessedSkillCount}</p></div>
            </div>
            <div className="mt-5">
              <p className="mb-2 text-xs font-semibold uppercase tracking-wider text-aurora-mint">Strengths</p>
              {data.analysis.strengths.length ? (
                <ul className="space-y-1.5 text-sm">{data.analysis.strengths.map((s) => <li key={s.skillId} className="flex items-center justify-between"><span>{s.name}</span><span className="text-aurora-mint">{s.proficiency}%</span></li>)}</ul>
              ) : <p className="text-sm text-aurora-muted">None yet (70%+ needed).</p>}
            </div>
            <div className="mt-5">
              <p className="mb-2 text-xs font-semibold uppercase tracking-wider text-rose-300">Needs attention</p>
              {data.analysis.weaknesses.length ? (
                <ul className="space-y-2 text-sm">{data.analysis.weaknesses.map((w) => <li key={w.skillId}><span>{w.name}</span> <span className="text-xs text-aurora-muted">— {w.reason}</span></li>)}</ul>
              ) : <p className="text-sm text-aurora-muted">No weak areas identified.</p>}
            </div>
          </Card>

          <Card>
            <h2 className="text-base font-semibold">Assessment history</h2>
            {data.history.length === 0 ? (
              <p className="mt-3 text-sm text-aurora-muted">No assessments taken yet.</p>
            ) : (
              <ul className="mt-4 space-y-3">
                {data.history.slice(0, 8).map((h) => (
                  <li key={h.id} className="rounded-xl bg-aurora-bg/40 p-3 text-sm">
                    <div className="flex items-center justify-between"><span className="font-medium">{h.skillName}</span><span className={h.score >= 70 ? "text-aurora-mint" : "text-amber-200"}>{h.score}%</span></div>
                    <p className="mt-1 text-xs text-aurora-muted">Proficiency {h.previousProficiency}% → {h.newProficiency}% · {new Date(h.createdAt).toLocaleDateString()}</p>
                  </li>
                ))}
              </ul>
            )}
          </Card>
        </div>
      </div>
    </div>
  );
}

function SkillManager({ skills, onChanged }: { skills: { skillId: number; name: string; proficiency: number }[]; onChanged: () => void }) {
  const toast = useToast();
  const [name, setName] = useState("");
  const [level, setLevel] = useState(50);
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);
  const [edits, setEdits] = useState<Record<number, number>>({});

  async function addSkill(e: FormEvent) {
    e.preventDefault();
    setError("");
    if (name.trim().length < 2) return setError("Enter a skill name (at least 2 characters).");
    setBusy(true);
    try {
      const res = await api<{ message: string; matchPercentage: number }>("/api/skills", { method: "POST", body: { name: name.trim(), proficiency: level } });
      toast.show("success", `${res.message} Career match is now ${res.matchPercentage}%.`);
      setName("");
      onChanged();
    } catch (err) {
      setError(errorMessage(err));
    } finally {
      setBusy(false);
    }
  }

  async function saveLevel(skillId: number, name: string) {
    const value = edits[skillId];
    if (value === undefined) return;
    try {
      const res = await api<{ message: string }>(`/api/skills/${skillId}`, { method: "PUT", body: { proficiency: value } });
      toast.show("success", res.message);
      setEdits((prev) => { const copy = { ...prev }; delete copy[skillId]; return copy; });
      onChanged();
    } catch (err) {
      toast.show("error", `${name}: ${errorMessage(err)}`);
    }
  }

  return (
    <Card>
      <h2 className="text-base font-semibold">Your skills</h2>
      <p className="mt-1 text-xs text-aurora-muted">Set your self-rated level. Assessments will confirm or adjust it.</p>

      <form onSubmit={addSkill} noValidate className="mt-4 grid gap-3 md:grid-cols-[1fr_180px_auto] md:items-end">
        <Field label="Add a skill" htmlFor="new-skill" error={error || undefined}>
          <Input id="new-skill" value={name} onChange={(e) => setName(e.target.value)} placeholder="e.g. SQL or a custom skill" maxLength={100} />
        </Field>
        <Field label="Level" htmlFor="new-skill-level">
          <Select id="new-skill-level" value={level} onChange={(e) => setLevel(Number(e.target.value))}>
            {PROFICIENCY_LEVELS.map((p) => <option key={p.value} value={p.value}>{p.label}</option>)}
          </Select>
        </Field>
        <Button type="submit" loading={busy}><Plus className="h-4 w-4" aria-hidden /> Add</Button>
      </form>

      {skills.length === 0 ? (
        <p className="mt-6 rounded-xl border border-dashed border-white/10 p-6 text-center text-sm text-aurora-muted">No skills yet. Add your first skill above.</p>
      ) : (
        <ul className="mt-6 divide-y divide-white/[0.06]">
          {skills.map((s) => (
            <li key={s.skillId} className="flex flex-col gap-3 py-3 md:flex-row md:items-center">
              <div className="min-w-0 flex-1">
                <div className="flex items-center justify-between gap-3">
                  <span className="font-medium">{s.name}</span>
                  <span className="text-xs text-aurora-muted">{levelLabel(s.proficiency)} · {s.proficiency}%</span>
                </div>
                <div className="mt-2"><ProgressBar value={s.proficiency} /></div>
              </div>
              <div className="flex items-center gap-2">
                <Select aria-label={`Level for ${s.name}`} className="w-44 py-2" value={edits[s.skillId] ?? s.proficiency} onChange={(e) => setEdits({ ...edits, [s.skillId]: Number(e.target.value) })}>
                  {PROFICIENCY_LEVELS.map((p) => <option key={p.value} value={p.value}>{p.label}</option>)}
                  {!PROFICIENCY_LEVELS.some((p) => p.value === s.proficiency) && <option value={s.proficiency}>Custom · {s.proficiency}%</option>}
                </Select>
                <Button size="sm" variant="secondary" disabled={edits[s.skillId] === undefined} onClick={() => saveLevel(s.skillId, s.name)} aria-label={`Save level for ${s.name}`}>
                  <Save className="h-4 w-4" aria-hidden />
                </Button>
              </div>
            </li>
          ))}
        </ul>
      )}
    </Card>
  );
}

function QuizPanel({ assessment, onSubmitted }: { assessment: AssessmentItem; onSubmitted: (r: SubmitResult) => void }) {
  const toast = useToast();
  const [answers, setAnswers] = useState<(number | undefined)[]>(() => assessment.questions.map(() => undefined));
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState("");
  const answered = answers.filter((a) => a !== undefined).length;

  async function submit() {
    if (answered < assessment.questions.length) {
      setError("Please answer every question before submitting.");
      return;
    }
    setError("");
    setSubmitting(true);
    try {
      const res = await api<SubmitResult>("/api/assessments/submit", {
        method: "POST",
        body: { assessmentId: assessment.id, answers },
      });
      toast.show(res.result.passed ? "success" : "info", `${res.result.skillName}: ${res.result.score}% scored.`);
      onSubmitted(res as SubmitResult);
    } catch (err) {
      setError(errorMessage(err));
    } finally {
      setSubmitting(false);
    }
  }

  return (
    <Card className="animate-fade-in">
      <div className="mb-5 flex items-center justify-between gap-3">
        <div>
          <p className="text-xs font-semibold uppercase tracking-wider text-aurora-cyan">{assessment.skillName} check</p>
          <h2 className="text-lg font-semibold">{assessment.title}</h2>
        </div>
        <Badge tone="violet">{answered}/{assessment.questions.length} answered</Badge>
      </div>
      <ol className="space-y-6">
        {assessment.questions.map((q, qi) => (
          <li key={q.id}>
            <fieldset>
              <legend className="mb-3 text-sm font-medium">{qi + 1}. {q.prompt}</legend>
              <div className="grid gap-2">
                {q.options.map((opt, oi) => {
                  const selected = answers[qi] === oi;
                  return (
                    <label key={oi} className={cn("flex cursor-pointer items-center gap-3 rounded-xl border px-4 py-3 text-sm transition", selected ? "border-aurora-cyan/60 bg-aurora-cyan/10" : "border-white/[0.07] bg-aurora-bg/40 hover:border-white/20")}>
                      <input
                        type="radio"
                        name={`q-${q.id}`}
                        className="accent-[#36D9F5]"
                        checked={selected}
                        onChange={() => setAnswers((prev) => prev.map((a, i) => (i === qi ? oi : a)))}
                      />
                      {opt}
                    </label>
                  );
                })}
              </div>
            </fieldset>
          </li>
        ))}
      </ol>
      {error && <p role="alert" className="mt-4 text-sm text-rose-300">{error}</p>}
      <div className="mt-6 flex justify-end">
        <Button onClick={submit} loading={submitting}>Submit answers</Button>
      </div>
    </Card>
  );
}

function ResultPanel({ result, onRetake }: { result: SubmitResult; onRetake: () => void }) {
  const r = result.result;
  return (
    <Card className="animate-fade-in space-y-6">
      <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <p className="text-xs font-semibold uppercase tracking-wider text-aurora-cyan">Results · {r.skillName}</p>
          <h2 className="mt-1 text-2xl font-semibold">{r.score}% <span className="text-base font-normal text-aurora-muted">({r.correctCount}/{r.totalQuestions} correct)</span></h2>
          <p className="mt-2 text-sm text-aurora-muted">
            Proficiency {r.previousProficiency}% → <span className="text-aurora-mint">{r.newProficiency}%</span>
          </p>
        </div>
        <Badge tone={r.passed ? "mint" : "amber"}>{r.passed ? "Passed" : "Keep practising"}</Badge>
      </div>

      <div className="rounded-2xl border border-aurora-violet/25 bg-aurora-violet/5 p-4">
        <p className="flex items-center gap-2 text-sm font-semibold"><Lightbulb className="h-4 w-4 text-aurora-violet" aria-hidden /> Adaptive recommendation</p>
        <p className="mt-2 text-sm leading-relaxed text-aurora-muted">{result.adaptiveRecommendation}</p>
        <p className="mt-3 text-xs text-aurora-muted">
          Career match {result.matchBefore}% → {result.matchAfter}% ({result.matchChange >= 0 ? "+" : ""}{result.matchChange} pts). Next: <span className="text-aurora-text">{result.nextAction.title}</span>
        </p>
      </div>

      <ol className="space-y-4">
        {result.explanations.map((e, i) => (
          <li key={e.id} className="rounded-xl border border-white/[0.07] bg-aurora-bg/40 p-4">
            <div className="flex items-start gap-3">
              {e.correct ? <CheckCircle2 className="mt-0.5 h-5 w-5 shrink-0 text-aurora-mint" aria-hidden /> : <XCircle className="mt-0.5 h-5 w-5 shrink-0 text-rose-300" aria-hidden />}
              <div className="min-w-0">
                <p className="text-sm font-medium">{i + 1}. {e.prompt}</p>
                <p className="mt-1 text-xs text-aurora-muted">Your answer: {e.options[e.selectedIndex]}{!e.correct && <> · Correct: <span className="text-aurora-mint">{e.options[e.correctIndex]}</span></>}</p>
                <p className="mt-2 text-sm leading-relaxed text-aurora-muted">{e.explanation}</p>
              </div>
            </div>
          </li>
        ))}
      </ol>

      <div className="flex flex-wrap gap-3">
        <Button variant="secondary" onClick={onRetake}>Choose another check</Button>
        <ButtonLink href={result.nextAction.href} variant="ghost"><Target className="h-4 w-4" aria-hidden /> {result.nextAction.title}</ButtonLink>
      </div>
    </Card>
  );
}
