"use client";

import { useEffect, useMemo, useState, type FormEvent } from "react";
import { useRouter } from "next/navigation";
import { ArrowLeft, ArrowRight, Check, Compass, GraduationCap, Plus, Sparkles } from "lucide-react";
import { Badge, Button, Card, Field, Input, PageHeader, Select, Skeleton, Textarea, cn, useToast } from "@/components/ui";
import { api, errorMessage } from "@/lib/client-api";
import { EDUCATION_LEVELS, PROFICIENCY_LEVELS } from "@/lib/constants";
import { useApi } from "@/lib/use-api";

type Profile = {
  fullName: string;
  educationLevel: string | null;
  institution: string | null;
  certifications: string[];
  completedProjects: string[];
  targetCareer: { id: number; title: string } | null;
  weeklyHours: number;
};
type Career = { id: number; title: string; description: string; requiredSkills: string[] };
type SkillRow = { skillId: number; name: string; proficiency: number };

const STEPS = ["Profile", "Skills", "Career"] as const;
const lines = (text: string) => text.split("\n").map((s) => s.trim()).filter(Boolean);

export default function OnboardingPage() {
  const router = useRouter();
  const toast = useToast();
  const [step, setStep] = useState(0);
  const profileQ = useApi<{ profile: Profile }>("/api/profile");
  const careersQ = useApi<{ careers: Career[] }>("/api/careers");
  const skillsQ = useApi<{ skills: SkillRow[]; catalog: { id: number; name: string; category: string }[] }>("/api/skills");

  const [form, setForm] = useState({
    fullName: "",
    educationLevel: "",
    institution: "",
    certifications: "",
    completedProjects: "",
    weeklyHours: 5,
    targetCareerId: null as number | null,
  });
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [saving, setSaving] = useState(false);

  // Prefill from saved profile once it loads.
  useEffect(() => {
    const p = profileQ.data?.profile;
    if (!p) return;
    setForm((f) => ({
      ...f,
      fullName: p.fullName,
      educationLevel: p.educationLevel ?? "",
      institution: p.institution ?? "",
      certifications: p.certifications.join("\n"),
      completedProjects: p.completedProjects.join("\n"),
      weeklyHours: p.weeklyHours,
      targetCareerId: p.targetCareer?.id ?? null,
    }));
  }, [profileQ.data]);

  async function saveProfileStep(e?: FormEvent) {
    e?.preventDefault();
    const local: Record<string, string> = {};
    if (form.fullName.trim().length < 2) local.fullName = "Enter your full name.";
    if (!form.educationLevel) local.educationLevel = "Choose your education level.";
    if (!Number.isInteger(Number(form.weeklyHours)) || Number(form.weeklyHours) < 1 || Number(form.weeklyHours) > 40) {
      local.weeklyHours = "Enter 1 to 40 hours per week.";
    }
    setErrors(local);
    if (Object.keys(local).length) return false;
    setSaving(true);
    try {
      await api("/api/profile", {
        method: "PUT",
        body: {
          fullName: form.fullName,
          educationLevel: form.educationLevel,
          institution: form.institution,
          certifications: lines(form.certifications),
          completedProjects: lines(form.completedProjects),
          weeklyHours: Number(form.weeklyHours),
        },
      });
      toast.show("success", "Profile saved.");
      return true;
    } catch (error) {
      toast.show("error", errorMessage(error));
      return false;
    } finally {
      setSaving(false);
    }
  }

  async function next() {
    if (step === 0) {
      if (await saveProfileStep()) setStep(1);
    } else if (step === 1) {
      setStep(2);
    }
  }

  async function finish() {
    if (!form.targetCareerId) {
      setErrors({ career: "Select a target career to continue." });
      return;
    }
    setSaving(true);
    try {
      await api("/api/profile", {
        method: "PUT",
        body: { targetCareerId: form.targetCareerId, weeklyHours: Number(form.weeklyHours), onboardingCompleted: true },
      });
      toast.show("success", "Onboarding complete. Your dashboard is ready.");
      router.replace("/dashboard");
      router.refresh();
    } catch (error) {
      toast.show("error", errorMessage(error));
      setSaving(false);
    }
  }

  const loading = profileQ.loading && !profileQ.data;

  return (
    <div className="mx-auto max-w-4xl">
      <PageHeader eyebrow="Onboarding" title="Set up your learner profile" description="Three quick steps. Everything you enter is saved to your account and used by the agents." />

      <ol className="mb-8 flex items-center gap-2" aria-label="Onboarding progress">
        {STEPS.map((label, i) => (
          <li key={label} className="flex flex-1 items-center gap-2">
            <span className={cn("grid h-8 w-8 shrink-0 place-items-center rounded-full border text-sm font-semibold", i <= step ? "border-aurora-cyan bg-aurora-cyan/15 text-aurora-cyan" : "border-white/10 text-aurora-muted")}>
              {i < step ? <Check className="h-4 w-4" aria-hidden /> : i + 1}
            </span>
            <span className={cn("hidden text-sm sm:inline", i <= step ? "text-aurora-text" : "text-aurora-muted")}>{label}</span>
            {i < STEPS.length - 1 && <span className={cn("h-px flex-1", i < step ? "bg-aurora-cyan/60" : "bg-white/10")} aria-hidden />}
          </li>
        ))}
      </ol>

      {loading ? (
        <Skeleton className="h-96" />
      ) : (
        <Card className="animate-fade-in">
          {step === 0 && (
            <form onSubmit={(e) => { e.preventDefault(); next(); }} noValidate className="space-y-5">
              <div className="flex items-center gap-3"><GraduationCap className="h-5 w-5 text-aurora-cyan" aria-hidden /><h2 className="text-lg font-semibold">About you</h2></div>
              <div className="grid gap-5 md:grid-cols-2">
                <Field label="Full name" htmlFor="ob-name" error={errors.fullName}>
                  <Input id="ob-name" value={form.fullName} onChange={(e) => setForm({ ...form, fullName: e.target.value })} placeholder="Ada Lovelace" />
                </Field>
                <Field label="Education level" htmlFor="ob-edu" error={errors.educationLevel}>
                  <Select id="ob-edu" value={form.educationLevel} onChange={(e) => setForm({ ...form, educationLevel: e.target.value })}>
                    <option value="">Select…</option>
                    {EDUCATION_LEVELS.map((l) => <option key={l} value={l}>{l}</option>)}
                  </Select>
                </Field>
                <Field label="Institution / company" htmlFor="ob-inst" hint="Optional">
                  <Input id="ob-inst" value={form.institution} onChange={(e) => setForm({ ...form, institution: e.target.value })} placeholder="Your college or employer" maxLength={160} />
                </Field>
                <Field label="Weekly learning hours" htmlFor="ob-hours" error={errors.weeklyHours} hint="How many hours can you study each week?">
                  <Input id="ob-hours" type="number" min={1} max={40} value={form.weeklyHours} onChange={(e) => setForm({ ...form, weeklyHours: Number(e.target.value) })} />
                </Field>
                <Field label="Certifications" htmlFor="ob-cert" hint="One per line (optional)">
                  <Textarea id="ob-cert" rows={4} value={form.certifications} onChange={(e) => setForm({ ...form, certifications: e.target.value })} placeholder="Python for Everybody" />
                </Field>
                <Field label="Completed projects" htmlFor="ob-proj" hint="One per line (optional)">
                  <Textarea id="ob-proj" rows={4} value={form.completedProjects} onChange={(e) => setForm({ ...form, completedProjects: e.target.value })} placeholder="Library management system in Java" />
                </Field>
              </div>
              <div className="flex justify-end"><Button type="submit" loading={saving}>Save & continue <ArrowRight className="h-4 w-4" aria-hidden /></Button></div>
            </form>
          )}

          {step === 1 && (
            <div className="space-y-5">
              <div className="flex items-center gap-3"><Sparkles className="h-5 w-5 text-aurora-mint" aria-hidden /><h2 className="text-lg font-semibold">Your existing skills</h2></div>
              <p className="text-sm text-aurora-muted">Add the skills you already use. You can change levels later on the Skill Assessment page; assessments confirm them.</p>
              <SkillAdder catalog={skillsQ.data?.catalog ?? []} onAdded={() => skillsQ.reload()} />
              <SkillList skills={skillsQ.data?.skills ?? []} loading={skillsQ.loading && !skillsQ.data} />
              <div className="flex justify-between gap-3">
                <Button variant="ghost" onClick={() => setStep(0)}><ArrowLeft className="h-4 w-4" aria-hidden /> Back</Button>
                <Button onClick={next}>Continue <ArrowRight className="h-4 w-4" aria-hidden /></Button>
              </div>
            </div>
          )}

          {step === 2 && (
            <div className="space-y-5">
              <div className="flex items-center gap-3"><Compass className="h-5 w-5 text-aurora-violet" aria-hidden /><h2 className="text-lg font-semibold">Choose your target career</h2></div>
              {errors.career && <p role="alert" className="text-sm text-rose-300">{errors.career}</p>}
              {careersQ.loading && !careersQ.data ? (
                <div className="grid gap-3 sm:grid-cols-2"><Skeleton className="h-24" /><Skeleton className="h-24" /></div>
              ) : (
                <div className="grid gap-3 sm:grid-cols-2">
                  {(careersQ.data?.careers ?? []).map((c) => {
                    const selected = form.targetCareerId === c.id;
                    return (
                      <button
                        key={c.id}
                        type="button"
                        aria-pressed={selected}
                        onClick={() => { setErrors({}); setForm({ ...form, targetCareerId: c.id }); }}
                        className={cn("rounded-2xl border p-4 text-left transition hover:border-aurora-cyan/40", selected ? "border-aurora-cyan bg-aurora-cyan/10" : "border-white/[0.08] bg-aurora-bg/40")}
                      >
                        <div className="flex items-center justify-between gap-2">
                          <span className="font-semibold">{c.title}</span>
                          {selected && <Badge tone="cyan"><Check className="h-3 w-3" aria-hidden /> Selected</Badge>}
                        </div>
                        <p className="mt-1.5 text-xs leading-relaxed text-aurora-muted">{c.description}</p>
                      </button>
                    );
                  })}
                </div>
              )}
              <div className="flex justify-between gap-3">
                <Button variant="ghost" onClick={() => setStep(1)}><ArrowLeft className="h-4 w-4" aria-hidden /> Back</Button>
                <Button onClick={finish} loading={saving}>Finish & open dashboard</Button>
              </div>
            </div>
          )}
        </Card>
      )}
    </div>
  );
}

function SkillAdder({ catalog, onAdded }: { catalog: { id: number; name: string }[]; onAdded: () => void }) {
  const toast = useToast();
  const [name, setName] = useState("");
  const [level, setLevel] = useState(50);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");
  const suggestions = useMemo(() => catalog.map((c) => c.name), [catalog]);

  async function add(e: FormEvent) {
    e.preventDefault();
    setError("");
    if (name.trim().length < 2) return setError("Enter a skill name (at least 2 characters).");
    setBusy(true);
    try {
      await api("/api/skills", { method: "POST", body: { name: name.trim(), proficiency: level } });
      toast.show("success", `${name.trim()} added.`);
      setName("");
      onAdded();
    } catch (err) {
      setError(errorMessage(err));
    } finally {
      setBusy(false);
    }
  }

  return (
    <form onSubmit={add} className="grid gap-3 rounded-2xl border border-white/[0.07] bg-aurora-bg/40 p-4 md:grid-cols-[1fr_200px_auto] md:items-end" noValidate>
      <Field label="Skill" htmlFor="skill-name" error={error || undefined}>
        <Input id="skill-name" list="skill-options" value={name} onChange={(e) => setName(e.target.value)} placeholder="e.g. Python" maxLength={100} />
        <datalist id="skill-options">{suggestions.map((s) => <option key={s} value={s} />)}</datalist>
      </Field>
      <Field label="Level" htmlFor="skill-level">
        <Select id="skill-level" value={level} onChange={(e) => setLevel(Number(e.target.value))}>
          {PROFICIENCY_LEVELS.map((p) => <option key={p.value} value={p.value}>{p.label}</option>)}
        </Select>
      </Field>
      <Button type="submit" loading={busy}><Plus className="h-4 w-4" aria-hidden /> Add skill</Button>
    </form>
  );
}

function SkillList({ skills, loading }: { skills: SkillRow[]; loading: boolean }) {
  if (loading) return <Skeleton className="h-24" />;
  if (skills.length === 0) {
    return <p className="rounded-xl border border-dashed border-white/10 p-6 text-center text-sm text-aurora-muted">No skills added yet. Add at least one to continue.</p>;
  }
  return (
    <ul className="flex flex-wrap gap-2" aria-label="Your skills">
      {skills.map((s) => (
        <li key={s.skillId}><Badge tone="mint">{s.name} · {s.proficiency}%</Badge></li>
      ))}
    </ul>
  );
}
