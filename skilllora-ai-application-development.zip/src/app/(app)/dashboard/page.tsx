"use client";

import Link from "next/link";
import { ArrowRight, Award, CalendarCheck, Compass, Flame, Lock, Sparkles, Target } from "lucide-react";
import { Badge, ButtonLink, Card, EmptyState, ErrorBanner, PageHeader, ProgressBar, ProgressRing, Skeleton, cn } from "@/components/ui";
import { SkillComparisonChart, WeeklyActivityChart } from "@/components/charts";
import { useApi } from "@/lib/use-api";

type Analytics = {
  profile: { fullName: string; onboardingCompleted: boolean; weeklyHours: number };
  career: { id: number; title: string } | null;
  matchPercentage: number;
  matchFormula: string;
  disclaimer: string;
  roadmap: { exists: boolean; total: number; completed: number; pending: number; completionPercentage: number };
  skills: { total: number; mastered: number; partial: number; missing: number; averageProficiency: number; needsImprovement: number };
  skillComparison: { skillName: string; required: number; current: number; status: string }[];
  weeklyActivity: { day: string; count: number }[];
  recentActivities: { id: number; description: string; createdAt: string; activityType: string }[];
  achievements: { id: string; title: string; description: string; unlocked: boolean }[];
  nextAction: { title: string; description: string; href: string };
  strengths: { name: string; proficiency: number }[];
};

type CareerCard = { id: number; title: string; description: string; matchPercentage: number | null; requiredSkillCount: number };

export default function DashboardPage() {
  const analytics = useApi<{ analytics: Analytics }>("/api/progress/analytics");
  const careers = useApi<{ careers: CareerCard[] }>("/api/careers");

  if (analytics.loading && !analytics.data) return <DashboardSkeleton />;
  if (analytics.error || !analytics.data) {
    return <ErrorBanner message={analytics.error ?? "Could not load your dashboard."} onRetry={analytics.reload} />;
  }

  const a = analytics.data.analytics;
  const firstName = a.profile.fullName.split(" ")[0] || "there";
  const pending = a.roadmap.pending;
  const topCareers = [...(careers.data?.careers ?? [])]
    .sort((x, y) => (y.matchPercentage ?? 0) - (x.matchPercentage ?? 0))
    .slice(0, 3);
  const totalWeek = a.weeklyActivity.reduce((s, d) => s + d.count, 0);

  return (
    <div className="space-y-6">
      <PageHeader
        eyebrow="Command centre"
        title={`Welcome back, ${firstName}.`}
        description={
          a.career
            ? `You are working toward ${a.career.title}. Here is your career readiness and what to do next.`
            : "Choose a target career to unlock your readiness score and personalised roadmap."
        }
        actions={<ButtonLink href="/gap-analysis" variant="secondary">View gap analysis</ButtonLink>}
      />

      {!a.profile.onboardingCompleted && (
        <Card className="flex flex-col gap-4 border-aurora-violet/30 bg-aurora-violet/5 sm:flex-row sm:items-center sm:justify-between">
          <div>
            <p className="font-semibold">Complete your learner profile</p>
            <p className="text-sm text-aurora-muted">Onboarding takes about two minutes and improves every recommendation.</p>
          </div>
          <ButtonLink href="/onboarding">Start onboarding <ArrowRight className="h-4 w-4" aria-hidden /></ButtonLink>
        </Card>
      )}

      {/* Daily mission + readiness */}
      <div className="grid gap-6 xl:grid-cols-3">
        <Card className="relative overflow-hidden xl:col-span-2">
          <div className="absolute -right-16 -top-16 h-56 w-56 rounded-full bg-aurora-cyan/10 blur-3xl" aria-hidden />
          <div className="relative flex flex-col gap-6 md:flex-row md:items-center">
            <div className="flex flex-col items-center gap-3">
              <ProgressRing value={a.matchPercentage} size={150} sublabel="career match" />
              <Badge tone="cyan"><Target className="h-3 w-3" aria-hidden /> {a.career?.title ?? "No target career"}</Badge>
            </div>
            <div className="flex-1 space-y-4">
              <div>
                <p className="text-xs font-semibold uppercase tracking-[0.16em] text-aurora-mint">Daily learning mission</p>
                <h2 className="mt-1 text-xl font-semibold">{a.nextAction.title}</h2>
                <p className="mt-1 text-sm leading-relaxed text-aurora-muted">{a.nextAction.description}</p>
              </div>
              <ButtonLink href={a.nextAction.href}>Start mission <ArrowRight className="h-4 w-4" aria-hidden /></ButtonLink>
              <p className="text-xs leading-relaxed text-aurora-muted/80">{a.disclaimer}</p>
            </div>
          </div>
        </Card>

        <Card>
          <h2 className="text-base font-semibold">Learning orbit</h2>
          <p className="text-xs text-aurora-muted">Roadmap tasks completed</p>
          <div className="mt-5 flex items-center gap-5">
            <ProgressRing value={a.roadmap.completionPercentage} size={96} stroke={8} />
            <dl className="grid flex-1 gap-3 text-sm">
              <div className="flex justify-between"><dt className="text-aurora-muted">Completed</dt><dd className="font-semibold text-aurora-mint">{a.roadmap.completed}</dd></div>
              <div className="flex justify-between"><dt className="text-aurora-muted">Remaining</dt><dd className="font-semibold">{pending}</dd></div>
              <div className="flex justify-between"><dt className="text-aurora-muted">Weekly hours</dt><dd className="font-semibold">{a.profile.weeklyHours}h</dd></div>
            </dl>
          </div>
          <ButtonLink href="/roadmap" variant="ghost" size="sm" className="mt-5 w-full">Open roadmap</ButtonLink>
        </Card>
      </div>

      {/* Skill overview */}
      <div className="grid gap-6 xl:grid-cols-3">
        <Card className="xl:col-span-2">
          <div className="mb-4 flex items-center justify-between gap-3">
            <div>
              <h2 className="text-base font-semibold">Skill progress</h2>
              <p className="text-xs text-aurora-muted">Current proficiency vs. career target for each required skill</p>
            </div>
            <div className="hidden gap-2 sm:flex">
              <Badge tone="mint">{a.skills.mastered} mastered</Badge>
              <Badge tone="amber">{a.skills.partial} partial</Badge>
              <Badge tone="rose">{a.skills.missing} missing</Badge>
            </div>
          </div>
          {a.skillComparison.length === 0 ? (
            <EmptyState
              icon={<Target className="h-6 w-6" />}
              title="No skill comparison yet"
              description="Select a target career and add your skills to see your progress chart."
              action={<ButtonLink href="/careers" size="sm">Choose a career</ButtonLink>}
            />
          ) : (
            <SkillComparisonChart data={a.skillComparison} />
          )}
        </Card>

        <Card>
          <h2 className="text-base font-semibold">Strengths</h2>
          <p className="text-xs text-aurora-muted">Skills at 70% proficiency or higher</p>
          <div className="mt-4 space-y-4">
            {a.strengths.length === 0 ? (
              <p className="text-sm text-aurora-muted">No strengths yet. Take an assessment to reveal them.</p>
            ) : (
              a.strengths.slice(0, 5).map((s) => (
                <div key={s.name}>
                  <div className="mb-1.5 flex justify-between text-sm"><span>{s.name}</span><span className="text-aurora-mint">{s.proficiency}%</span></div>
                  <ProgressBar value={s.proficiency} tone="mint" />
                </div>
              ))
            )}
          </div>
          <ButtonLink href="/assessments" variant="ghost" size="sm" className="mt-5 w-full">Improve skills</ButtonLink>
        </Card>
      </div>

      {/* Career galaxy preview */}
      <Card>
        <div className="mb-4 flex items-center justify-between">
          <div>
            <h2 className="text-base font-semibold">Recommended career paths</h2>
            <p className="text-xs text-aurora-muted">Ranked by your indicative skill-alignment</p>
          </div>
          <Link href="/careers" className="text-sm text-aurora-cyan hover:underline">All careers</Link>
        </div>
        {careers.loading && !careers.data ? (
          <div className="grid gap-4 md:grid-cols-3"><Skeleton className="h-28" /><Skeleton className="h-28" /><Skeleton className="h-28" /></div>
        ) : (
          <div className="grid gap-4 md:grid-cols-3">
            {topCareers.map((c) => (
              <Link key={c.id} href="/careers" className={cn("group rounded-2xl border border-white/[0.07] bg-aurora-bg/40 p-4 transition hover:-translate-y-0.5 hover:border-aurora-cyan/30", c.id === a.career?.id && "ring-1 ring-aurora-cyan/40")}>
                <div className="flex items-start justify-between gap-2">
                  <p className="font-semibold group-hover:text-aurora-cyan">{c.title}</p>
                  <span className="text-sm font-semibold text-aurora-mint">{c.matchPercentage ?? 0}%</span>
                </div>
                <div className="mt-3"><ProgressBar value={c.matchPercentage ?? 0} /></div>
                <p className="mt-3 line-clamp-2 text-xs text-aurora-muted">{c.description}</p>
              </Link>
            ))}
          </div>
        )}
      </Card>

      {/* Activity, achievements and chart */}
      <div className="grid gap-6 xl:grid-cols-3">
        <Card>
          <div className="mb-4 flex items-center justify-between">
            <h2 className="text-base font-semibold">Weekly activity</h2>
            <span className="text-xs text-aurora-muted">{totalWeek} this week</span>
          </div>
          <WeeklyActivityChart data={a.weeklyActivity} />
        </Card>

        <Card>
          <h2 className="mb-4 text-base font-semibold">Achievements</h2>
          <ul className="grid grid-cols-2 gap-3">
            {a.achievements.map((ach) => (
              <li key={ach.id} className={cn("rounded-xl border p-3 text-xs", ach.unlocked ? "border-aurora-mint/25 bg-aurora-mint/5" : "border-white/[0.06] bg-aurora-bg/30 opacity-60")}>
                <div className="mb-1.5 flex items-center gap-1.5">
                  {ach.unlocked ? <Award className="h-3.5 w-3.5 text-aurora-mint" aria-hidden /> : <Lock className="h-3.5 w-3.5 text-aurora-muted" aria-hidden />}
                  <span className="font-semibold text-aurora-text">{ach.title}</span>
                </div>
                <p className="text-aurora-muted">{ach.description}</p>
              </li>
            ))}
          </ul>
        </Card>

        <Card>
          <h2 className="mb-4 text-base font-semibold">Recent activity</h2>
          {a.recentActivities.length === 0 ? (
            <EmptyState icon={<Flame className="h-6 w-6" />} title="No activity yet" description="Your updates appear here as you learn." />
          ) : (
            <ul className="space-y-3">
              {a.recentActivities.slice(0, 6).map((r) => (
                <li key={r.id} className="flex gap-3 text-sm">
                  <CalendarCheck className="mt-0.5 h-4 w-4 shrink-0 text-aurora-cyan" aria-hidden />
                  <div>
                    <p className="leading-relaxed text-aurora-text">{r.description}</p>
                    <p className="text-xs text-aurora-muted">{new Date(r.createdAt).toLocaleString()}</p>
                  </div>
                </li>
              ))}
            </ul>
          )}
        </Card>
      </div>

      {!a.career && (
        <EmptyState
          icon={<Compass className="h-6 w-6" />}
          title="Your galaxy is waiting"
          description="Pick a career to see the exact skills it needs and how far you are from it."
          action={<ButtonLink href="/careers">Explore careers <Sparkles className="h-4 w-4" aria-hidden /></ButtonLink>}
        />
      )}
    </div>
  );
}

function DashboardSkeleton() {
  return (
    <div className="space-y-6" aria-busy="true" aria-label="Loading dashboard">
      <Skeleton className="h-20 w-2/3" />
      <div className="grid gap-6 xl:grid-cols-3">
        <Skeleton className="h-72 xl:col-span-2" />
        <Skeleton className="h-72" />
      </div>
      <div className="grid gap-6 xl:grid-cols-3">
        <Skeleton className="h-96 xl:col-span-2" />
        <Skeleton className="h-96" />
      </div>
    </div>
  );
}
