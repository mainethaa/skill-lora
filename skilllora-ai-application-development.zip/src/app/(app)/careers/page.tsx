"use client";

import { useState } from "react";
import { Check, Compass, ExternalLink, Sparkles, Target } from "lucide-react";
import { Badge, Button, Card, EmptyState, ErrorBanner, PageHeader, ProgressBar, Skeleton, cn, useToast } from "@/components/ui";
import { api, errorMessage } from "@/lib/client-api";
import { useApi } from "@/lib/use-api";

type Career = {
  id: number;
  slug: string;
  title: string;
  description: string;
  requiredSkills: string[];
  requiredSkillCount: number;
  matchPercentage: number | null;
  isTarget: boolean;
};

type CareerDetail = {
  career: { id: number; title: string; description: string };
  skills: {
    skillId: number;
    name: string;
    category: string;
    requiredLevel: number;
    threshold: number;
    current: number;
    status: "mastered" | "partial" | "missing";
    resources: { title: string; provider: string; url: string; estimatedHours: number }[];
  }[];
};

const STATUS_STYLE = {
  mastered: { label: "Meets target", tone: "mint" as const },
  partial: { label: "In progress", tone: "amber" as const },
  missing: { label: "Missing", tone: "rose" as const },
};

export default function CareersPage() {
  const toast = useToast();
  const { data, error, loading, reload } = useApi<{ careers: Career[]; authenticated: boolean }>("/api/careers");
  const [openId, setOpenId] = useState<number | null>(null);
  const [detail, setDetail] = useState<CareerDetail | null>(null);
  const [detailLoading, setDetailLoading] = useState(false);
  const [detailError, setDetailError] = useState("");
  const [saving, setSaving] = useState(false);

  async function explore(id: number) {
    if (openId === id) {
      setOpenId(null);
      setDetail(null);
      return;
    }
    setOpenId(id);
    setDetail(null);
    setDetailError("");
    setDetailLoading(true);
    try {
      setDetail(await api<CareerDetail>(`/api/careers/${id}/skills`));
    } catch (err) {
      setDetailError(errorMessage(err));
    } finally {
      setDetailLoading(false);
    }
  }

  async function setTarget(id: number, title: string) {
    setSaving(true);
    try {
      await api("/api/profile", { method: "PUT", body: { targetCareerId: id } });
      toast.show("success", `${title} is now your target career. Your roadmap has been updated.`);
      reload();
    } catch (err) {
      toast.show("error", errorMessage(err));
    } finally {
      setSaving(false);
    }
  }

  const target = data?.careers.find((c) => c.isTarget);

  return (
    <div className="space-y-6">
      <PageHeader
        eyebrow="Career galaxy"
        title="Explore career paths"
        description="Each card shows the skills an employer commonly expects for the role. Your match % uses the transparent formula: required skills at or above target ÷ total required skills."
        actions={target ? <Badge tone="cyan"><Target className="h-3 w-3" aria-hidden /> Target: {target.title}</Badge> : undefined}
      />

      {loading && !data ? (
        <div className="grid gap-5 md:grid-cols-2 xl:grid-cols-3"><Skeleton className="h-64" /><Skeleton className="h-64" /><Skeleton className="h-64" /></div>
      ) : error || !data ? (
        <ErrorBanner message={error ?? "Could not load careers."} onRetry={reload} />
      ) : data.careers.length === 0 ? (
        <EmptyState icon={<Compass className="h-6 w-6" />} title="No careers found" description="The career dataset is empty. Refresh the page to load the sample careers." />
      ) : (
        <div className="grid gap-5 md:grid-cols-2 xl:grid-cols-3">
          {data.careers.map((c) => {
            const open = openId === c.id;
            return (
              <Card key={c.id} className={cn("flex flex-col transition duration-300", c.isTarget && "ring-1 ring-aurora-cyan/50", open && "md:col-span-2 xl:col-span-3")}>
                <div className={cn("flex flex-col gap-4", open && "md:flex-row md:items-start md:justify-between")}>
                  <div className={cn(open && "md:max-w-xl")}>
                    <div className="flex items-start justify-between gap-3">
                      <h2 className="text-lg font-semibold">{c.title}</h2>
                      {c.isTarget && <Badge tone="cyan"><Check className="h-3 w-3" aria-hidden /> Target</Badge>}
                    </div>
                    <p className="mt-2 text-sm leading-relaxed text-aurora-muted">{c.description}</p>
                  </div>
                  <div className={cn("min-w-[180px]", open && "md:text-right")}>
                    <p className="text-xs text-aurora-muted">Skill match</p>
                    <p className="text-3xl font-semibold text-aurora-mint">{c.matchPercentage ?? "—"}{c.matchPercentage !== null && <span className="text-base">%</span>}</p>
                    <div className="mt-2"><ProgressBar value={c.matchPercentage ?? 0} tone="mint" /></div>
                  </div>
                </div>

                {!open && (
                  <>
                    <p className="mb-2 mt-5 text-xs font-semibold uppercase tracking-wider text-aurora-muted">Required skills ({c.requiredSkillCount})</p>
                    <div className="flex flex-wrap gap-1.5">
                      {c.requiredSkills.slice(0, 6).map((s) => <Badge key={s}>{s}</Badge>)}
                      {c.requiredSkills.length > 6 && <Badge>+{c.requiredSkills.length - 6} more</Badge>}
                    </div>
                  </>
                )}

                <div className="mt-auto flex flex-wrap gap-2 pt-5">
                  <Button variant="secondary" size="sm" onClick={() => explore(c.id)} aria-expanded={open}>
                    <Sparkles className="h-4 w-4" aria-hidden /> {open ? "Hide details" : "Explore career"}
                  </Button>
                  {!c.isTarget && (
                    <Button size="sm" onClick={() => setTarget(c.id, c.title)} loading={saving}>
                      Set as target
                    </Button>
                  )}
                </div>

                {open && (
                  <div className="mt-6 border-t border-white/[0.06] pt-6">
                    {detailLoading && <Skeleton className="h-40" />}
                    {detailError && <ErrorBanner message={detailError} />}
                    {detail && (
                      <div className="grid gap-6 lg:grid-cols-[1fr_280px]">
                        <div>
                          <p className="mb-3 text-sm font-semibold">Skill requirements</p>
                          <ul className="space-y-3">
                            {detail.skills.map((s) => (
                              <li key={s.skillId} className="rounded-xl border border-white/[0.06] bg-aurora-bg/40 p-3">
                                <div className="flex flex-wrap items-center justify-between gap-2">
                                  <span className="font-medium">{s.name} <span className="text-xs text-aurora-muted">· {s.category}</span></span>
                                  <Badge tone={STATUS_STYLE[s.status].tone}>{STATUS_STYLE[s.status].label}</Badge>
                                </div>
                                <div className="mt-2 flex items-center gap-3 text-xs text-aurora-muted">
                                  <span className="w-28 shrink-0">You: {s.current}% · Target: {s.threshold}%</span>
                                  <div className="flex-1"><ProgressBar value={s.current} tone={s.status === "mastered" ? "mint" : "cyan"} /></div>
                                </div>
                                {s.resources[0] && (
                                  <a href={s.resources[0].url} target="_blank" rel="noopener noreferrer" className="mt-2 inline-flex items-center gap-1 text-xs text-aurora-cyan hover:underline">
                                    {s.resources[0].title} · {s.resources[0].provider} <ExternalLink className="h-3 w-3" aria-hidden />
                                  </a>
                                )}
                              </li>
                            ))}
                          </ul>
                        </div>
                        <aside className="rounded-2xl border border-aurora-violet/20 bg-aurora-violet/5 p-4 text-sm">
                          <p className="font-semibold">Why this matters</p>
                          <p className="mt-2 leading-relaxed text-aurora-muted">
                            Requirement levels are converted to targets (level × 20). A skill counts as meeting the target once your proficiency reaches it. The match % is an indicative alignment measure, not a job-readiness guarantee.
                          </p>
                        </aside>
                      </div>
                    )}
                  </div>
                )}
              </Card>
            );
          })}
        </div>
      )}
    </div>
  );
}
