import { NextResponse } from "next/server";
import { getCurrentUser, type CurrentUser } from "@/lib/auth";

/** Structured JSON success response. */
export function ok<T extends Record<string, unknown>>(data: T, status = 200) {
  return NextResponse.json({ success: true, ...data }, { status });
}

/** Consistent JSON error response. Never leaks stack traces or secrets. */
export function fail(message: string, status = 400, details?: Record<string, string>) {
  return NextResponse.json(
    { success: false, error: message, ...(details ? { details } : {}) },
    { status },
  );
}

/** Parses a JSON request body safely. Returns null if the body is not valid JSON object. */
export async function readJson(req: Request): Promise<Record<string, unknown> | null> {
  try {
    const body = await req.json();
    if (body && typeof body === "object" && !Array.isArray(body)) {
      return body as Record<string, unknown>;
    }
    return null;
  } catch {
    return null;
  }
}

/** Returns the logged-in user or a 401 response. Use in every protected route. */
export async function requireUser(): Promise<
  { user: CurrentUser; response?: undefined } | { user?: undefined; response: NextResponse }
> {
  const user = await getCurrentUser();
  if (!user) {
    return { response: fail("Please log in to continue.", 401) };
  }
  return { user };
}

/** Runs a handler and converts unexpected errors into a safe 500 JSON response. */
export async function safely(label: string, fn: () => Promise<NextResponse>): Promise<NextResponse> {
  try {
    return await fn();
  } catch (error) {
    console.error(`[${label}]`, error);
    return fail("Something went wrong on the server. Please try again.", 500);
  }
}

// ---- Small validation helpers -------------------------------------------

export function cleanString(value: unknown, max: number): string {
  if (typeof value !== "string") return "";
  return value.trim().replace(/\s+/g, " ").slice(0, max);
}

export function isInt(value: unknown, min: number, max: number): value is number {
  return typeof value === "number" && Number.isInteger(value) && value >= min && value <= max;
}

export function isValidEmail(value: string): boolean {
  return value.length <= 254 && /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(value);
}

export function stringArray(value: unknown, maxItems: number, maxLen: number): string[] {
  if (!Array.isArray(value)) return [];
  return value
    .filter((v): v is string => typeof v === "string")
    .map((v) => v.trim().slice(0, maxLen))
    .filter((v) => v.length > 0)
    .slice(0, maxItems);
}
