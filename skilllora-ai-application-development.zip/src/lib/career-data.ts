// SAMPLE DEMONSTRATION DATASET.
// Editable career skill-requirement dataset. Every row here is seeded into PostgreSQL
// (flagged is_sample = true). Required levels run from 1 (awareness) to 5 (expert).
// Threshold proficiency = requiredLevel * 20 on a 0-100 scale.

export type SkillSeed = { name: string; category: string; description: string };

export const SKILL_SEEDS: SkillSeed[] = [
  { name: "Python", category: "Programming", description: "General-purpose language used for AI, data and backend work." },
  { name: "JavaScript", category: "Programming", description: "Language of the web browser and Node.js." },
  { name: "TypeScript", category: "Programming", description: "Typed superset of JavaScript for large applications." },
  { name: "Statistics", category: "Mathematics", description: "Descriptive and inferential statistics, probability and hypothesis testing." },
  { name: "Linear Algebra", category: "Mathematics", description: "Vectors, matrices and transformations used in machine learning." },
  { name: "Machine Learning", category: "AI & Data", description: "Supervised and unsupervised learning, model evaluation and tuning." },
  { name: "Deep Learning", category: "AI & Data", description: "Neural networks trained with frameworks such as PyTorch or TensorFlow." },
  { name: "Pandas & NumPy", category: "AI & Data", description: "Data manipulation and numerical computing in Python." },
  { name: "SQL", category: "Data", description: "Querying and modelling relational data." },
  { name: "Data Visualization", category: "Data", description: "Communicating insights with charts and dashboards." },
  { name: "Spreadsheets & Excel", category: "Data", description: "Formulas, pivot tables and structured analysis in spreadsheets." },
  { name: "Git", category: "Engineering", description: "Version control, branching and collaborative code review." },
  { name: "React", category: "Web", description: "Component-based user interface development." },
  { name: "Node.js", category: "Web", description: "Server-side JavaScript and API development." },
  { name: "PostgreSQL", category: "Data", description: "Advanced relational database design and querying." },
  { name: "REST APIs", category: "Web", description: "Designing and consuming HTTP APIs with proper status codes." },
  { name: "Linux", category: "Systems", description: "Command-line, permissions, processes and shell scripting." },
  { name: "Networking", category: "Systems", description: "TCP/IP, DNS, HTTP and network troubleshooting." },
  { name: "Cybersecurity Fundamentals", category: "Security", description: "Core security principles, OWASP risks and secure coding." },
  { name: "Threat Detection", category: "Security", description: "Monitoring, logs and identifying attack patterns." },
  { name: "Cloud Computing", category: "Cloud", description: "Cloud services, compute, storage and identity on public clouds." },
  { name: "Docker", category: "Cloud", description: "Packaging applications into portable containers." },
  { name: "Kubernetes", category: "Cloud", description: "Orchestrating containers at scale." },
  { name: "Infrastructure as Code", category: "Cloud", description: "Declaring cloud infrastructure with tools such as Terraform." },
];

export type CareerSeed = {
  slug: string;
  title: string;
  description: string;
  required: { skill: string; level: number; weight?: number }[];
};

export const CAREER_SEEDS: CareerSeed[] = [
  {
    slug: "ai-engineer",
    title: "AI Engineer",
    description: "Designs and ships AI-powered features, from model prototypes to production APIs.",
    required: [
      { skill: "Python", level: 4 },
      { skill: "Machine Learning", level: 4 },
      { skill: "Deep Learning", level: 3 },
      { skill: "Linear Algebra", level: 3 },
      { skill: "REST APIs", level: 3 },
      { skill: "Git", level: 2 },
      { skill: "Docker", level: 2 },
    ],
  },
  {
    slug: "machine-learning-engineer",
    title: "Machine Learning Engineer",
    description: "Builds, trains and deploys machine learning models reliably at scale.",
    required: [
      { skill: "Python", level: 4 },
      { skill: "Machine Learning", level: 4 },
      { skill: "Deep Learning", level: 3 },
      { skill: "Docker", level: 3 },
      { skill: "Cloud Computing", level: 3 },
      { skill: "SQL", level: 2 },
      { skill: "Git", level: 3 },
    ],
  },
  {
    slug: "data-scientist",
    title: "Data Scientist",
    description: "Turns messy data into statistical insight and predictive models for decisions.",
    required: [
      { skill: "Python", level: 4 },
      { skill: "Statistics", level: 4 },
      { skill: "Machine Learning", level: 3 },
      { skill: "SQL", level: 3 },
      { skill: "Pandas & NumPy", level: 4 },
      { skill: "Data Visualization", level: 3 },
      { skill: "Linear Algebra", level: 2 },
    ],
  },
  {
    slug: "data-analyst",
    title: "Data Analyst",
    description: "Answers business questions with queries, dashboards and clear reporting.",
    required: [
      { skill: "SQL", level: 4 },
      { skill: "Statistics", level: 3 },
      { skill: "Data Visualization", level: 4 },
      { skill: "Spreadsheets & Excel", level: 4 },
      { skill: "Python", level: 2 },
      { skill: "Pandas & NumPy", level: 2 },
    ],
  },
  {
    slug: "full-stack-developer",
    title: "Full-Stack Developer",
    description: "Builds complete web products across the user interface, server and database.",
    required: [
      { skill: "JavaScript", level: 4 },
      { skill: "TypeScript", level: 3 },
      { skill: "React", level: 4 },
      { skill: "Node.js", level: 4 },
      { skill: "PostgreSQL", level: 3 },
      { skill: "REST APIs", level: 3 },
      { skill: "Git", level: 3 },
    ],
  },
  {
    slug: "python-developer",
    title: "Python Developer",
    description: "Develops backend services, automation and tools using Python.",
    required: [
      { skill: "Python", level: 4 },
      { skill: "REST APIs", level: 3 },
      { skill: "SQL", level: 3 },
      { skill: "Git", level: 3 },
      { skill: "Docker", level: 2 },
      { skill: "Linux", level: 2 },
    ],
  },
  {
    slug: "cybersecurity-analyst",
    title: "Cybersecurity Analyst",
    description: "Protects systems by monitoring threats, investigating incidents and hardening defences.",
    required: [
      { skill: "Networking", level: 4 },
      { skill: "Cybersecurity Fundamentals", level: 4 },
      { skill: "Linux", level: 3 },
      { skill: "Threat Detection", level: 3 },
      { skill: "Python", level: 2 },
      { skill: "Cloud Computing", level: 2 },
    ],
  },
  {
    slug: "cloud-engineer",
    title: "Cloud Engineer",
    description: "Designs, deploys and operates scalable infrastructure on public cloud platforms.",
    required: [
      { skill: "Cloud Computing", level: 4 },
      { skill: "Linux", level: 4 },
      { skill: "Networking", level: 3 },
      { skill: "Docker", level: 3 },
      { skill: "Kubernetes", level: 3 },
      { skill: "Infrastructure as Code", level: 3 },
      { skill: "Python", level: 2 },
    ],
  },
];

export type ResourceSeed = {
  skill: string;
  title: string;
  provider: string;
  url: string;
  resourceType: "course" | "documentation" | "interactive" | "tutorial";
  estimatedHours: number;
};

// Links point to well-known public learning resources.
export const RESOURCE_SEEDS: ResourceSeed[] = [
  { skill: "Python", title: "The Python Tutorial", provider: "Python Software Foundation", url: "https://docs.python.org/3/tutorial/", resourceType: "documentation", estimatedHours: 12 },
  { skill: "JavaScript", title: "JavaScript Guide", provider: "MDN Web Docs", url: "https://developer.mozilla.org/en-US/docs/Web/JavaScript/Guide", resourceType: "documentation", estimatedHours: 14 },
  { skill: "TypeScript", title: "TypeScript Handbook", provider: "Microsoft", url: "https://www.typescriptlang.org/docs/handbook/intro.html", resourceType: "documentation", estimatedHours: 8 },
  { skill: "Statistics", title: "Statistics & Probability", provider: "Khan Academy", url: "https://www.khanacademy.org/math/statistics-probability", resourceType: "course", estimatedHours: 16 },
  { skill: "Linear Algebra", title: "Linear Algebra", provider: "Khan Academy", url: "https://www.khanacademy.org/math/linear-algebra", resourceType: "course", estimatedHours: 14 },
  { skill: "Machine Learning", title: "Intro to Machine Learning", provider: "Kaggle Learn", url: "https://www.kaggle.com/learn/intro-to-machine-learning", resourceType: "interactive", estimatedHours: 6 },
  { skill: "Deep Learning", title: "Deep Learning Tutorials", provider: "TensorFlow", url: "https://www.tensorflow.org/tutorials", resourceType: "tutorial", estimatedHours: 16 },
  { skill: "Pandas & NumPy", title: "Pandas Getting Started", provider: "pandas project", url: "https://pandas.pydata.org/docs/getting_started/index.html", resourceType: "documentation", estimatedHours: 8 },
  { skill: "SQL", title: "Intro to SQL", provider: "Kaggle Learn", url: "https://www.kaggle.com/learn/intro-to-sql", resourceType: "interactive", estimatedHours: 5 },
  { skill: "Data Visualization", title: "Data Visualization", provider: "Kaggle Learn", url: "https://www.kaggle.com/learn/data-visualization", resourceType: "interactive", estimatedHours: 6 },
  { skill: "Spreadsheets & Excel", title: "Excel Tutorials & Formulas", provider: "Exceljet", url: "https://exceljet.net/", resourceType: "tutorial", estimatedHours: 10 },
  { skill: "Git", title: "Pro Git Book", provider: "Git project", url: "https://git-scm.com/book/en/v2", resourceType: "documentation", estimatedHours: 8 },
  { skill: "React", title: "Learn React", provider: "React team", url: "https://react.dev/learn", resourceType: "tutorial", estimatedHours: 14 },
  { skill: "Node.js", title: "Introduction to Node.js", provider: "Node.js project", url: "https://nodejs.org/en/learn/getting-started/introduction-to-nodejs", resourceType: "documentation", estimatedHours: 8 },
  { skill: "PostgreSQL", title: "PostgreSQL Tutorial", provider: "PostgreSQL Global Development Group", url: "https://www.postgresql.org/docs/current/tutorial.html", resourceType: "documentation", estimatedHours: 8 },
  { skill: "REST APIs", title: "REST API Guide", provider: "RESTfulAPI.net", url: "https://restfulapi.net/", resourceType: "tutorial", estimatedHours: 4 },
  { skill: "Linux", title: "Linux Journey", provider: "Linux Journey", url: "https://linuxjourney.com/", resourceType: "interactive", estimatedHours: 10 },
  { skill: "Networking", title: "How the Internet Works", provider: "MDN Web Docs", url: "https://developer.mozilla.org/en-US/docs/Learn_web_development/Howto/Web_mechanics/How_does_the_Internet_work", resourceType: "documentation", estimatedHours: 4 },
  { skill: "Cybersecurity Fundamentals", title: "OWASP Top Ten", provider: "OWASP Foundation", url: "https://owasp.org/www-project-top-ten/", resourceType: "documentation", estimatedHours: 6 },
  { skill: "Threat Detection", title: "MITRE ATT&CK Basics", provider: "MITRE", url: "https://attack.mitre.org/resources/learn-the-basics/", resourceType: "documentation", estimatedHours: 6 },
  { skill: "Cloud Computing", title: "Cloud Skills Training", provider: "Google Cloud", url: "https://cloud.google.com/training", resourceType: "course", estimatedHours: 12 },
  { skill: "Docker", title: "Docker Get Started", provider: "Docker", url: "https://docs.docker.com/get-started/", resourceType: "tutorial", estimatedHours: 6 },
  { skill: "Kubernetes", title: "Kubernetes Basics", provider: "Kubernetes project", url: "https://kubernetes.io/docs/tutorials/kubernetes-basics/", resourceType: "interactive", estimatedHours: 8 },
  { skill: "Infrastructure as Code", title: "Terraform Tutorials", provider: "HashiCorp", url: "https://developer.hashicorp.com/terraform/tutorials", resourceType: "tutorial", estimatedHours: 8 },
];

export type QuestionSeed = { prompt: string; options: string[]; answerIndex: number; explanation: string };

// Three multiple-choice questions per skill. Answers are checked on the server only.
export const ASSESSMENT_SEEDS: Record<string, QuestionSeed[]> = {
  Python: [
    { prompt: "Which keyword defines a function in Python?", options: ["func", "def", "function", "lambda"], answerIndex: 1, explanation: "Python uses the 'def' keyword to define functions." },
    { prompt: "What does len([1, 2, 3]) return?", options: ["2", "3", "4", "Error"], answerIndex: 1, explanation: "The list has three elements, so len returns 3." },
    { prompt: "Which data type is immutable?", options: ["list", "dict", "set", "tuple"], answerIndex: 3, explanation: "Tuples cannot be changed after creation." },
  ],
  JavaScript: [
    { prompt: "Which keyword declares a block-scoped variable?", options: ["var", "let", "global", "static"], answerIndex: 1, explanation: "'let' (and 'const') are block-scoped." },
    { prompt: "What is the result of typeof null?", options: ["'null'", "'object'", "'undefined'", "'number'"], answerIndex: 1, explanation: "It is a long-standing JavaScript quirk: typeof null returns 'object'." },
    { prompt: "Which method transforms each array item into a new array?", options: ["forEach", "map", "push", "join"], answerIndex: 1, explanation: "map returns a new array with each element transformed." },
  ],
  TypeScript: [
    { prompt: "What does TypeScript add to JavaScript?", options: ["Static typing", "A new runtime", "Browser plugins", "Database drivers"], answerIndex: 0, explanation: "TypeScript adds optional static type checking." },
    { prompt: "Which type means 'any value but must be checked before use'?", options: ["any", "unknown", "never", "void"], answerIndex: 1, explanation: "'unknown' forces type checks before use, which is safer than 'any'." },
    { prompt: "What is an interface mainly used for?", options: ["Describing object shapes", "Making HTTP calls", "Styling pages", "Managing files"], answerIndex: 0, explanation: "Interfaces describe the structure of objects." },
  ],
  Statistics: [
    { prompt: "Which measure is the middle value of sorted data?", options: ["Mean", "Median", "Mode", "Variance"], answerIndex: 1, explanation: "The median is the middle value of sorted data." },
    { prompt: "A p-value below 0.05 usually means:", options: ["The null hypothesis is proven true", "The result is unlikely under the null hypothesis", "The sample is large", "The data is normal"], answerIndex: 1, explanation: "A small p-value suggests the observed result is unlikely if the null hypothesis holds." },
    { prompt: "What does standard deviation measure?", options: ["Central value", "Spread of data", "Number of samples", "Correlation"], answerIndex: 1, explanation: "Standard deviation describes how spread out values are around the mean." },
  ],
  "Linear Algebra": [
    { prompt: "What is a matrix multiplied by its identity matrix?", options: ["Zero matrix", "The same matrix", "Transpose", "Inverse always"], answerIndex: 1, explanation: "Multiplying by the identity matrix leaves a matrix unchanged." },
    { prompt: "What is a vector?", options: ["A single number", "An ordered list of numbers with direction and magnitude", "A database table", "A chart type"], answerIndex: 1, explanation: "Vectors are ordered lists of numbers representing magnitude and direction." },
    { prompt: "Which operation is central to a neural network layer?", options: ["Matrix-vector multiplication", "String concatenation", "File compression", "Sorting"], answerIndex: 0, explanation: "Layers compute weighted sums, i.e. matrix-vector products." },
  ],
  "Machine Learning": [
    { prompt: "Which task predicts a continuous number?", options: ["Classification", "Regression", "Clustering", "Dimensionality reduction"], answerIndex: 1, explanation: "Regression predicts continuous values." },
    { prompt: "Why do we split data into training and test sets?", options: ["To make the model faster", "To estimate performance on unseen data", "To delete outliers", "To store the model"], answerIndex: 1, explanation: "A held-out test set estimates how well the model generalises." },
    { prompt: "Which situation indicates overfitting?", options: ["Low training and low test accuracy", "High training accuracy but much lower test accuracy", "Equal accuracies at low values", "Perfect accuracy on everything"], answerIndex: 1, explanation: "Overfitting means memorising training data and failing to generalise." },
  ],
  "Deep Learning": [
    { prompt: "What is the role of an activation function?", options: ["Store data", "Introduce non-linearity", "Split datasets", "Encrypt weights"], answerIndex: 1, explanation: "Non-linear activations let networks learn complex patterns." },
    { prompt: "What does backpropagation compute?", options: ["Gradients of the loss with respect to weights", "Dataset labels", "File hashes", "Network latency"], answerIndex: 0, explanation: "Backpropagation computes gradients used to update weights." },
    { prompt: "Which framework is used for deep learning?", options: ["PyTorch", "Bootstrap", "Redux", "Flask-Login"], answerIndex: 0, explanation: "PyTorch and TensorFlow are common deep learning frameworks." },
  ],
  "Pandas & NumPy": [
    { prompt: "Which pandas structure holds labelled tabular data?", options: ["Series", "DataFrame", "ndarray", "Dict"], answerIndex: 1, explanation: "A DataFrame is a two-dimensional labelled table." },
    { prompt: "What does df.dropna() do?", options: ["Removes missing values", "Drops duplicate rows", "Deletes the file", "Sorts columns"], answerIndex: 0, explanation: "dropna removes rows (by default) that contain missing values." },
    { prompt: "What is the main benefit of NumPy arrays?", options: ["Fast vectorised numerical operations", "Web hosting", "Automatic charts", "Password hashing"], answerIndex: 0, explanation: "NumPy performs fast operations on whole arrays without Python loops." },
  ],
  SQL: [
    { prompt: "Which clause filters rows after grouping?", options: ["WHERE", "HAVING", "ORDER BY", "LIMIT"], answerIndex: 1, explanation: "HAVING filters groups produced by GROUP BY." },
    { prompt: "Which JOIN returns only matching rows from both tables?", options: ["LEFT JOIN", "FULL JOIN", "INNER JOIN", "CROSS JOIN"], answerIndex: 2, explanation: "INNER JOIN keeps rows that match in both tables." },
    { prompt: "Which statement adds new rows?", options: ["INSERT", "SELECT", "UPDATE", "DROP"], answerIndex: 0, explanation: "INSERT adds rows to a table." },
  ],
  "Data Visualization": [
    { prompt: "Which chart best shows change over time?", options: ["Pie chart", "Line chart", "Scatter plot", "Word cloud"], answerIndex: 1, explanation: "Line charts show trends across time periods." },
    { prompt: "What is a common principle of clear dashboards?", options: ["Use as many colours as possible", "Show the key metric first", "Hide axis labels", "Use 3D effects"], answerIndex: 1, explanation: "Lead with the most important insight and keep visuals uncluttered." },
    { prompt: "When is a bar chart most suitable?", options: ["Comparing categories", "Showing a precise equation", "Storing raw logs", "Encrypting data"], answerIndex: 0, explanation: "Bar charts compare values across categories." },
  ],
  "Spreadsheets & Excel": [
    { prompt: "Which function sums values matching a condition?", options: ["SUMIF", "VLOOKUP only", "CONCAT", "TEXT"], answerIndex: 0, explanation: "SUMIF adds up cells that meet a condition." },
    { prompt: "What does a pivot table do?", options: ["Summarises and groups data", "Sends emails", "Compiles code", "Hashes passwords"], answerIndex: 0, explanation: "Pivot tables summarise large datasets by groups." },
    { prompt: "What does an absolute reference like $A$1 do?", options: ["Stays fixed when copied", "Changes when copied", "Links to another file", "Hides the cell"], answerIndex: 0, explanation: "The $ signs lock the reference." },
  ],
  Git: [
    { prompt: "Which command creates a new commit from staged changes?", options: ["git push", "git commit", "git branch", "git clone"], answerIndex: 1, explanation: "git commit records staged changes." },
    { prompt: "What is a branch?", options: ["A deleted commit", "An independent line of development", "A remote server", "A backup zip"], answerIndex: 1, explanation: "Branches let you develop features independently." },
    { prompt: "Which command downloads a remote repository?", options: ["git fetch-all", "git clone", "git merge", "git stash"], answerIndex: 1, explanation: "git clone copies a repository to your machine." },
  ],
  React: [
    { prompt: "What is a React component?", options: ["A reusable UI building block", "A database table", "A CSS file", "A server process"], answerIndex: 0, explanation: "Components are reusable pieces of UI." },
    { prompt: "Which hook manages local state in a function component?", options: ["useEffect", "useState", "useRouter", "useMemo only"], answerIndex: 1, explanation: "useState stores and updates component state." },
    { prompt: "What is JSX?", options: ["A syntax extension that looks like HTML inside JavaScript", "A database query language", "A CSS framework", "A testing tool"], answerIndex: 0, explanation: "JSX lets you describe UI with HTML-like syntax." },
  ],
  "Node.js": [
    { prompt: "Which module is used to create an HTTP server in Node.js core?", options: ["http", "fs-web", "express-core", "net-html"], answerIndex: 0, explanation: "The built-in 'http' module creates HTTP servers." },
    { prompt: "What does npm stand for?", options: ["Node Package Manager", "New Program Module", "Network Process Manager", "Node Project Method"], answerIndex: 0, explanation: "npm is the Node Package Manager." },
    { prompt: "Node.js is built on which JavaScript engine?", options: ["SpiderMonkey", "V8", "Chakra", "JavaScriptCore"], answerIndex: 1, explanation: "Node.js runs on Google's V8 engine." },
  ],
  PostgreSQL: [
    { prompt: "Which keyword makes a column unique?", options: ["UNIQUE", "DISTINCT", "INDEX ONLY", "SINGLE"], answerIndex: 0, explanation: "UNIQUE constraints prevent duplicate values." },
    { prompt: "What is a foreign key?", options: ["A column referencing a primary key in another table", "A password", "A password hash", "A temporary table"], answerIndex: 0, explanation: "Foreign keys enforce relationships between tables." },
    { prompt: "Why use parameterised queries?", options: ["To prevent SQL injection", "To increase disk size", "To change the language", "To disable indexes"], answerIndex: 0, explanation: "Parameters keep user input separate from SQL code." },
  ],
  "REST APIs": [
    { prompt: "Which HTTP status code means a resource was created?", options: ["200", "201", "301", "500"], answerIndex: 1, explanation: "201 Created is returned after successfully creating a resource." },
    { prompt: "Which HTTP method is normally used to read data?", options: ["GET", "DELETE", "POST", "PATCH"], answerIndex: 0, explanation: "GET retrieves resources without changing them." },
    { prompt: "What does 401 Unauthorized usually indicate?", options: ["Missing or invalid authentication", "Server crash", "Resource moved", "Bad request format"], answerIndex: 0, explanation: "401 means the request lacks valid credentials." },
  ],
  Linux: [
    { prompt: "Which command lists files including hidden ones?", options: ["ls -a", "cd -a", "rm -a", "cat -a"], answerIndex: 0, explanation: "ls -a shows hidden files starting with a dot." },
    { prompt: "What does chmod change?", options: ["File permissions", "File contents", "Network routes", "Process IDs"], answerIndex: 0, explanation: "chmod modifies file permissions." },
    { prompt: "Which command shows running processes?", options: ["ps", "mkdir", "touch", "echo"], answerIndex: 0, explanation: "ps lists running processes." },
  ],
  Networking: [
    { prompt: "What does DNS do?", options: ["Translates domain names to IP addresses", "Encrypts disks", "Compiles code", "Stores passwords"], answerIndex: 0, explanation: "DNS maps human-readable names to IP addresses." },
    { prompt: "Which protocol is connection-oriented and reliable?", options: ["UDP", "TCP", "ICMP", "ARP"], answerIndex: 1, explanation: "TCP provides reliable, ordered delivery." },
    { prompt: "What is the default HTTPS port?", options: ["80", "22", "443", "3306"], answerIndex: 2, explanation: "HTTPS uses port 443 by default." },
  ],
  "Cybersecurity Fundamentals": [
    { prompt: "What does the 'C' in the CIA triad stand for?", options: ["Confidentiality", "Compression", "Connectivity", "Compliance"], answerIndex: 0, explanation: "CIA = Confidentiality, Integrity, Availability." },
    { prompt: "What is the best way to store user passwords?", options: ["Plain text", "Encrypted reversible storage", "Salted and hashed with a slow algorithm", "In a cookie"], answerIndex: 2, explanation: "Salted, slow hashes such as scrypt or bcrypt resist cracking." },
    { prompt: "Which attack injects malicious script into a web page?", options: ["SQL injection", "Cross-site scripting (XSS)", "Phishing", "DDoS"], answerIndex: 1, explanation: "XSS injects scripts that run in other users' browsers." },
  ],
  "Threat Detection": [
    { prompt: "What is a SIEM used for?", options: ["Collecting and analysing security logs", "Designing websites", "Editing images", "Managing payroll"], answerIndex: 0, explanation: "SIEM tools centralise and correlate logs to detect threats." },
    { prompt: "Many failed logins from one IP in seconds most likely indicates:", options: ["Brute-force attempt", "Normal browsing", "A system update", "A database backup"], answerIndex: 0, explanation: "Rapid repeated failures suggest password guessing." },
    { prompt: "What is an IOC?", options: ["Indicator of Compromise", "Input Output Controller", "Internet Operation Code", "Infrastructure Overview Chart"], answerIndex: 0, explanation: "Indicators of Compromise are artefacts that suggest intrusion." },
  ],
  "Cloud Computing": [
    { prompt: "What does IaaS provide?", options: ["Virtual machines and storage on demand", "Finished email apps only", "Only desktop software", "Hardware sales"], answerIndex: 0, explanation: "Infrastructure-as-a-Service provides virtualised compute and storage." },
    { prompt: "What is object storage commonly used for?", options: ["Files and backups", "Running CPU-heavy loops", "Routing packets", "Defining DNS records"], answerIndex: 0, explanation: "Object storage holds files, media and backups." },
    { prompt: "Why use IAM roles?", options: ["Grant least-privilege access without shared keys", "Increase storage size", "Speed up the internet", "Create charts"], answerIndex: 0, explanation: "Roles give temporary, scoped permissions." },
  ],
  Docker: [
    { prompt: "What is a Docker image?", options: ["A read-only template for containers", "A running virtual machine OS only", "A web browser", "A database server"], answerIndex: 0, explanation: "Images are templates used to start containers." },
    { prompt: "Which file describes how to build an image?", options: ["Dockerfile", "README.md", "package.json", "index.html"], answerIndex: 0, explanation: "A Dockerfile lists build instructions." },
    { prompt: "Which command starts a container from an image?", options: ["docker run", "docker build only", "docker push", "docker login"], answerIndex: 0, explanation: "docker run creates and starts a container." },
  ],
  Kubernetes: [
    { prompt: "What is the smallest deployable unit in Kubernetes?", options: ["Node", "Pod", "Cluster", "Namespace"], answerIndex: 1, explanation: "A Pod wraps one or more containers." },
    { prompt: "What does a Deployment ensure?", options: ["Desired number of pod replicas run", "DNS records exist", "Images are compressed", "Logs are deleted"], answerIndex: 0, explanation: "Deployments maintain the desired replica count." },
    { prompt: "Which tool is the standard CLI for Kubernetes?", options: ["kubectl", "dockerd", "helmfile-only", "terraform"], answerIndex: 0, explanation: "kubectl talks to the Kubernetes API." },
  ],
  "Infrastructure as Code": [
    { prompt: "What is the main idea of Infrastructure as Code?", options: ["Define infrastructure in versioned files", "Draw infrastructure on paper", "Use only manual clicks", "Avoid automation"], answerIndex: 0, explanation: "IaC makes infrastructure repeatable and reviewable." },
    { prompt: "What does 'terraform plan' do?", options: ["Shows the changes that would be made", "Deletes all resources", "Deploys immediately without review", "Installs Linux"], answerIndex: 0, explanation: "plan previews changes before applying them." },
    { prompt: "Why store state carefully in IaC tools?", options: ["State tracks what resources exist", "State is the website design", "State is a password", "State holds images"], answerIndex: 0, explanation: "The state file maps configuration to real resources." },
  ],
};
