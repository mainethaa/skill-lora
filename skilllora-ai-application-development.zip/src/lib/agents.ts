// SkillLora AI – Adaptive Skill Intelligence Engine.
//
// Four separate agent functions with clearly defined responsibilities. They share one
// data-loading step (loadSnapshot) and exchange structured results:
//
//   1. skillAssessmentAgent   – evaluates the learner's skills and assessment history
//   2. careerMatchingAgent    – compares skills with the target career and finds gaps
//   3. learningPathAgent      – prioritises gaps and builds a weekly roadmap
//   4. (AI Mentor agent lives in src/lib/mentor.ts and consumes the outputs above)
//
// All four agents are deterministic, rule-based functions. They do not train any model.
import { and, asc, count, desc, eq, gte, inArray, sql } from "drizzle-orm";
import { db } from "@/db";
import {
  assessmentResults,
  assessments,
  careerRequiredSkills,
  careerRoles,
  learnerProfiles,
  learnerSkills,
  learningResources,
  learningRoadmaps,
  progressRecords,
  roadmapTasks,
  skills,
  users,
} from "@/db/schema";
import { ensureSeeded } from "@/lib/seed";

export const LEARNING_BOOST = 10; // points added when a learning task is completed
export const LEARNING_CAP = 60; // learning tasks alone cannot push a skill above this; an assessment is needed
export const MAX_ROADMAP_TASKS = 10;

export type RequiredSkill = {
  skillId: number;
  name: string;
  category: string;
  requiredLevel: number;
  threshold: number; // requiredLevel * 20
  weight: number;
};

export type LearnerSkill = {
  skillId: number;
  name: string;
  category: string;
  proficiency: number;
  source: string;
};

export type AssessmentHistoryItem = {
  id: number;
  assessmentId: number;
  skillId: number;
  skillName: string;
  title: string;
  score: number;
  correctCount: number;
  totalQuestions: number;
  previousProficiency: number;
  newProficiency: number;
  createdAt: Date;
};

export type RoadmapTaskRow = typeof roadmapTasks.$inferSelect;

export type LearnerSnapshot = {
  userId: number;
  fullName: string;
  profile: {
    educationLevel: string | null;
    institution: string | null;
    certifications: string[];
    completedProjects: string[];
    weeklyHours: number;
    onboardingCompleted: boolean;
    targetCareerId: number | null;
  };
  career: { id: number; slug: string; title: string; description: string; required: RequiredSkill[] } | null;
  learnerSkills: LearnerSkill[];
  assessments: AssessmentHistoryItem[];
  roadmap: { id: number; careerId: number; generatedBy: string; weeklyHours: number; createdAt: Date } | null;
  tasks: RoadmapTaskRow[];
};

/** Loads everything the agents need for one learner in a few parameterised queries. */
export async function loadSnapshot(userId: number): Promise<LearnerSnapshot> {
  await ensureSeeded();

  const [user] = await db.select({ fullName: users.fullName }).from(users).where(eq(users.id, userId)).limit(1);
  const [profile] = await db.select().from(learnerProfiles).where(eq(learnerProfiles.userId, userId)).limit(1);

  let career: LearnerSnapshot["career"] = null;
  if (profile?.targetCareerId) {
    const [c] = await db.select().from(careerRoles).where(eq(careerRoles.id, profile.targetCareerId)).limit(1);
    if (c) {
      const req = await db
        .select({
          skillId: careerRequiredSkills.skillId,
          name: skills.name,
          category: skills.category,
          requiredLevel: careerRequiredSkills.requiredLevel,
          weight: careerRequiredSkills.weight,
        })
        .from(careerRequiredSkills)
        .innerJoin(skills, eq(careerRequiredSkills.skillId, skills.id))
        .where(eq(careerRequiredSkills.careerId, c.id))
        .orderBy(asc(skills.name));
      career = {
        id: c.id,
        slug: c.slug,
        title: c.title,
        description: c.description,
        required: req.map((r) => ({ ...r, threshold: r.requiredLevel * 20 })),
      };
    }
  }

  const skillRows = await db
    .select({
      skillId: learnerSkills.skillId,
      name: skills.name,
      category: skills.category,
      proficiency: learnerSkills.proficiency,
      source: learnerSkills.source,
    })
    .from(learnerSkills)
    .innerJoin(skills, eq(learnerSkills.skillId, skills.id))
    .where(eq(learnerSkills.userId, userId))
    .orderBy(asc(skills.name));

  const history = await db
    .select({
      id: assessmentResults.id,
      assessmentId: assessmentResults.assessmentId,
      skillId: assessments.skillId,
      skillName: skills.name,
      title: assessments.title,
      score: assessmentResults.score,
      correctCount: assessmentResults.correctCount,
      totalQuestions: assessmentResults.totalQuestions,
      previousProficiency: assessmentResults.previousProficiency,
      newProficiency: assessmentResults.newProficiency,
      createdAt: assessmentResults.createdAt,
    })
    .from(assessmentResults)
    .innerJoin(assessments, eq(assessmentResults.assessmentId, assessments.id))
    .innerJoin(skills, eq(assessments.skillId, skills.id))
    .where(eq(assessmentResults.userId, userId))
    .orderBy(desc(assessmentResults.createdAt))
    .limit(50);

  const [roadmap] = await db
    .select()
    .from(learningRoadmaps)
    .where(eq(learningRoadmaps.userId, userId))
    .limit(1);

  const tasks = roadmap
    ? await db
        .select()
        .from(roadmapTasks)
        .where(eq(roadmapTasks.roadmapId, roadmap.id))
        .orderBy(asc(roadmapTasks.position))
    : [];

  return {
    userId,
    fullName: user?.fullName ?? "Learner",
    profile: {
      educationLevel: profile?.educationLevel ?? null,
      institution: profile?.institution ?? null,
      certifications: profile?.certifications ?? [],
      completedProjects: profile?.completedProjects ?? [],
      weeklyHours: profile?.weeklyHours ?? 5,
      onboardingCompleted: profile?.onboardingCompleted ?? false,
      targetCareerId: profile?.targetCareerId ?? null,
    },
    career,
    learnerSkills: skillRows,
    assessments: history,
    roadmap: roadmap
      ? { id: roadmap.id, careerId: roadmap.careerId, generatedBy: roadmap.generatedBy, weeklyHours: roadmap.weeklyHours, createdAt: roadmap.createdAt }
      : null,
    tasks,
  };
}

// =========================================================================
// AGENT 1 – SKILL ASSESSMENT AGENT
// =========================================================================
export type SkillAssessmentOutput = {
  agent: "Skill Assessment Agent";
  source: "rule-based";
  assessedSkillCount: number;
  averageProficiency: number;
  strengths: { skillId: number; name: string; proficiency: number }[];
  weaknesses: { skillId: number; name: string; proficiency: number; reason: string }[];
  latestScores: { skillName: string; score: number; createdAt: Date }[];
  summary: string;
};

export function skillAssessmentAgent(snap: LearnerSnapshot): SkillAssessmentOutput {
  const skillsList = snap.learnerSkills;
  const average = skillsList.length
    ? Math.round(skillsList.reduce((sum, s) => sum + s.proficiency, 0) / skillsList.length)
    : 0;

  const strengths = [...skillsList]
    .filter((s) => s.proficiency >= 70)
    .sort((a, b) => b.proficiency - a.proficiency)
    .slice(0, 6)
    .map((s) => ({ skillId: s.skillId, name: s.name, proficiency: s.proficiency }));

  const latestByskill = new Map<number, AssessmentHistoryItem>();
  for (const item of snap.assessments) {
    if (!latestByskill.has(item.skillId)) latestByskill.set(item.skillId, item);
  }

  const weaknesses: SkillAssessmentOutput["weaknesses"] = [];
  for (const s of skillsList) {
    const latest = latestByskill.get(s.skillId);
    if (s.proficiency < 50) {
      weaknesses.push({ skillId: s.skillId, name: s.name, proficiency: s.proficiency, reason: "Proficiency is below 50%." });
    } else if (latest && latest.score < 60) {
      weaknesses.push({ skillId: s.skillId, name: s.name, proficiency: s.proficiency, reason: `Latest assessment scored ${latest.score}%.` });
    }
  }

  const latestScores = [...latestByskill.values()].slice(0, 8).map((i) => ({
    skillName: i.skillName,
    score: i.score,
    createdAt: i.createdAt,
  }));

  const summary = skillsList.length === 0
    ? "No skills have been added yet. Add your existing skills to receive an assessment."
    : `${skillsList.length} skill(s) evaluated with an average proficiency of ${average}%. ` +
      `${strengths.length} strength(s) and ${weaknesses.length} area(s) needing attention were identified.`;

  return {
    agent: "Skill Assessment Agent",
    source: "rule-based",
    assessedSkillCount: skillsList.length,
    averageProficiency: average,
    strengths,
    weaknesses,
    latestScores,
    summary,
  };
}

// =========================================================================
// AGENT 2 – CAREER MATCHING AGENT
// =========================================================================
export type SkillStatus = "mastered" | "partial" | "missing";

export type SkillGap = {
  skillId: number;
  name: string;
  category: string;
  requiredLevel: number;
  threshold: number;
  current: number;
  gap: number;
  weight: number;
  priorityScore: number;
  status: SkillStatus;
};

export type CareerMatchOutput = {
  agent: "Career Matching Agent";
  source: "rule-based";
  careerId: number | null;
  careerTitle: string | null;
  matchPercentage: number;
  formula: string;
  totalRequired: number;
  meetingThreshold: number;
  mastered: SkillGap[];
  partial: SkillGap[];
  missing: SkillGap[];
  gaps: SkillGap[]; // partial + missing, ordered by priority
  comparison: { skillName: string; required: number; current: number; status: SkillStatus }[];
  disclaimer: string;
};

export const MATCH_DISCLAIMER =
  "The career match percentage is an indicative skill-alignment measure based on the skill threshold you set. It is not a guaranteed employability or job-readiness score.";

export function careerMatchingAgent(snap: LearnerSnapshot): CareerMatchOutput {
  const empty: CareerMatchOutput = {
    agent: "Career Matching Agent",
    source: "rule-based",
    careerId: null,
    careerTitle: null,
    matchPercentage: 0,
    formula: "Career Match % = (required skills meeting threshold ÷ total required skills) × 100",
    totalRequired: 0,
    meetingThreshold: 0,
    mastered: [],
    partial: [],
    missing: [],
    gaps: [],
    comparison: [],
    disclaimer: MATCH_DISCLAIMER,
  };
  if (!snap.career) return empty;

  const current = new Map(snap.learnerSkills.map((s) => [s.skillId, s.proficiency]));
  const items: SkillGap[] = snap.career.required.map((r) => {
    const cur = current.get(r.skillId) ?? 0;
    const status: SkillStatus = cur >= r.threshold ? "mastered" : cur > 0 ? "partial" : "missing";
    const gap = Math.max(0, r.threshold - cur);
    return {
      skillId: r.skillId,
      name: r.name,
      category: r.category,
      requiredLevel: r.requiredLevel,
      threshold: r.threshold,
      current: cur,
      gap,
      weight: r.weight,
      priorityScore: gap * r.weight + (status === "missing" ? 5 : 0),
      status,
    };
  });

  const mastered = items.filter((i) => i.status === "mastered");
  const partial = items.filter((i) => i.status === "partial").sort((a, b) => b.priorityScore - a.priorityScore);
  const missing = items.filter((i) => i.status === "missing").sort((a, b) => b.priorityScore - a.priorityScore);
  const total = items.length;
  const matchPercentage = total === 0 ? 0 : Math.round((mastered.length / total) * 100);

  return {
    agent: "Career Matching Agent",
    source: "rule-based",
    careerId: snap.career.id,
    careerTitle: snap.career.title,
    matchPercentage,
    formula: `Career Match % = (${mastered.length} required skills meeting threshold ÷ ${total} total required skills) × 100 = ${matchPercentage}%`,
    totalRequired: total,
    meetingThreshold: mastered.length,
    mastered,
    partial,
    missing,
    gaps: [...partial, ...missing],
    comparison: items.map((i) => ({ skillName: i.name, required: i.threshold, current: i.current, status: i.status })),
    disclaimer: MATCH_DISCLAIMER,
  };
}

// =========================================================================
// AGENT 3 – LEARNING PATH AGENT
// =========================================================================
type ResourceRow = { id: number; skillId: number; title: string; provider: string; url: string; resourceType: string; estimatedHours: number };

const CATEGORY_TEMPLATES: Record<string, { exercise: (s: string) => string; project: (s: string) => string }> = {
  Programming: {
    exercise: (s) => `Write 5 small ${s} programs: a calculator, a list filter, a file reader, a unit-tested function and a class.`,
    project: (s) => `Build a command-line tool in ${s} that solves a problem from your daily life and includes tests.`,
  },
  Mathematics: {
    exercise: (s) => `Solve 10 worked ${s} problems by hand, then verify each answer with Python or a calculator.`,
    project: (s) => `Explain one real ${s} concept with a short notebook containing graphs and a written summary.`,
  },
  "AI & Data": {
    exercise: (s) => `Use ${s} on a public dataset: clean it, apply the technique, and record your accuracy or error metric.`,
    project: (s) => `Create a notebook project that applies ${s} to a dataset you find, then publish the results in a README.`,
  },
  Data: {
    exercise: (s) => `Complete 10 practice tasks in ${s} using a sample database or spreadsheet with real-looking data.`,
    project: (s) => `Build a short report or dashboard that uses ${s} to answer three business questions.`,
  },
  Engineering: {
    exercise: (s) => `Practise ${s} daily for a week: make 3 meaningful commits or perform 5 realistic operations.`,
    project: (s) => `Set up a small repository that demonstrates ${s} workflows with documentation.`,
  },
  Web: {
    exercise: (s) => `Rebuild one small feature using ${s} and write a short note on what you learned.`,
    project: (s) => `Ship a small web app that uses ${s} end to end and deploy it to a free host.`,
  },
  Systems: {
    exercise: (s) => `Complete 8 hands-on ${s} labs in a local virtual machine or sandbox and document each command used.`,
    project: (s) => `Create an automated checklist or script that uses ${s} to audit or configure a machine.`,
  },
  Security: {
    exercise: (s) => `Analyse 3 sample scenarios that involve ${s} and write a short incident note for each.`,
    project: (s) => `Build a small lab that demonstrates ${s} with logs or a vulnerable practice app, and document defences.`,
  },
  Cloud: {
    exercise: (s) => `Use a free-tier or local emulator to practise ${s}: create, change and remove one resource.`,
    project: (s) => `Deploy a small service that demonstrates ${s} and write a one-page architecture diagram.`,
  },
};

const DEFAULT_TEMPLATE = {
  exercise: (s: string) => `Practise ${s} with 5 short hands-on tasks and note what was difficult.`,
  project: (s: string) => `Create a small mini-project that applies ${s} to a problem you care about.`,
};

const TYPE_PREFERENCE = ["course", "interactive", "tutorial", "documentation"];

export type PlannedTask = {
  skillId: number;
  resourceId: number | null;
  title: string;
  priority: number;
  weekNumber: number;
  estimatedHours: number;
  practicalExercise: string;
  miniProject: string;
  status: SkillStatus;
  reason: string;
};

export type LearningPathOutput = {
  agent: "Learning Path Agent";
  source: "rule-based";
  tasks: PlannedTask[];
  totalHours: number;
  weeks: number;
  weeklyHours: number;
  rationale: string;
};

export function learningPathAgent(
  match: CareerMatchOutput,
  categoryBySkill: Map<number, string>,
  nameBySkill: Map<number, string>,
  resources: ResourceRow[],
  weeklyHours: number,
): LearningPathOutput {
  const capacity = Math.max(1, weeklyHours);
  const bestResource = new Map<number, ResourceRow>();
  for (const r of resources) {
    const current = bestResource.get(r.skillId);
    const rank = (x: ResourceRow) => TYPE_PREFERENCE.indexOf(x.resourceType);
    if (!current || rank(r) < rank(current)) bestResource.set(r.skillId, r);
  }

  // Priority order comes from the Career Matching Agent (highest priorityScore first).
  const selected = match.gaps.slice(0, MAX_ROADMAP_TASKS);
  let cumulative = 0;
  const tasks: PlannedTask[] = selected.map((gap, index) => {
    const resource = bestResource.get(gap.skillId) ?? null;
    const base = resource?.estimatedHours ?? 6;
    const hours = Math.max(2, Math.min(16, gap.status === "missing" ? base : Math.round(base * 0.6)));
    const category = categoryBySkill.get(gap.skillId) ?? "Custom";
    const template = CATEGORY_TEMPLATES[category] ?? DEFAULT_TEMPLATE;
    const name = nameBySkill.get(gap.skillId) ?? gap.name;
    const weekNumber = Math.floor(cumulative / capacity) + 1;
    cumulative += hours;
    return {
      skillId: gap.skillId,
      resourceId: resource?.id ?? null,
      title: gap.status === "missing" ? `Learn ${name}` : `Strengthen ${name}`,
      priority: index + 1,
      weekNumber,
      estimatedHours: hours,
      practicalExercise: template.exercise(name),
      miniProject: template.project(name),
      status: gap.status,
      reason:
        gap.status === "missing"
          ? `${name} is required for ${match.careerTitle} but you have not added it yet.`
          : `Your ${name} level (${gap.current}%) is below the target of ${gap.threshold}%.`,
    };
  });

  const totalHours = tasks.reduce((sum, t) => sum + t.estimatedHours, 0);
  const weeks = tasks.length ? tasks[tasks.length - 1].weekNumber : 0;

  return {
    agent: "Learning Path Agent",
    source: "rule-based",
    tasks,
    totalHours,
    weeks,
    weeklyHours: capacity,
    rationale: tasks.length
      ? `Skills are ordered by priority (missing skills and largest gaps first) and scheduled into weeks of ${capacity} hour(s).`
      : "No skill gaps were found for the selected career. Choose a different career or raise your target levels.",
  };
}

// =========================================================================
// ORCHESTRATION – collaboration workflow across the agents
// =========================================================================

export type NextAction = { title: string; description: string; href: string };

export function recommendNextAction(snap: LearnerSnapshot, match: CareerMatchOutput): NextAction {
  if (!snap.profile.onboardingCompleted) {
    return { title: "Finish onboarding", description: "Complete your profile so the agents can understand your background.", href: "/onboarding" };
  }
  if (!snap.career) {
    return { title: "Choose a target career", description: "Pick a career so SkillLora can measure your skill alignment.", href: "/careers" };
  }
  if (snap.learnerSkills.length === 0) {
    return { title: "Add your existing skills", description: "Tell SkillLora what you already know to calculate your match.", href: "/assessments" };
  }
  const nextTask = snap.tasks.find((t) => t.status === "pending");
  if (nextTask) {
    return { title: `Work on: ${nextTask.title}`, description: nextTask.practicalExercise, href: "/roadmap" };
  }
  if (!snap.roadmap) {
    return { title: "Generate your roadmap", description: "The Learning Path Agent will build a weekly plan from your gaps.", href: "/roadmap" };
  }
  const weakest = match.partial[0] ?? match.missing[0];
  if (weakest) {
    return { title: `Take the ${weakest.name} assessment`, description: "Passing an assessment is the way to raise a skill above the learning cap.", href: "/assessments" };
  }
  return { title: "Ask the AI Mentor", description: "Your target skills are on track. Ask the mentor how to go further.", href: "/mentor" };
}

/** Runs the four-step workflow: assess → match → plan (sync roadmap) → mentor-ready summary. */
export async function runAgentWorkflow(
  userId: number,
  options: { syncRoadmap?: boolean; createIfMissing?: boolean } = {},
) {
  let snap = await loadSnapshot(userId);
  const assessment = skillAssessmentAgent(snap);
  const matching = careerMatchingAgent(snap);

  let roadmapChanges: { created: number; removedPending: number } | null = null;
  // Existing roadmaps adapt automatically; a new roadmap is only created when explicitly requested.
  if (options.syncRoadmap && snap.career && (snap.roadmap || options.createIfMissing)) {
    roadmapChanges = await syncRoadmap(userId, snap, matching);
    snap = await loadSnapshot(userId);
  }
  const nextAction = recommendNextAction(snap, matching);
  return { snap, assessment, matching, roadmapChanges, nextAction };
}

/**
 * Learning Path Agent execution + persistence. Keeps completed tasks, replaces pending tasks
 * with a fresh plan based on the latest gaps (this is how the roadmap adapts).
 */
export async function syncRoadmap(
  userId: number,
  snap: LearnerSnapshot,
  match: CareerMatchOutput,
): Promise<{ created: number; removedPending: number }> {
  if (!snap.career) throw new Error("NO_TARGET_CAREER");

  const careerChanged = snap.roadmap ? snap.roadmap.careerId !== snap.career.id : false;
  const completedCount = snap.tasks.filter((t) => t.status === "completed").length;

  const skillRows = await db.select({ id: skills.id, name: skills.name, category: skills.category }).from(skills);
  const categoryBySkill = new Map(skillRows.map((s) => [s.id, s.category]));
  const nameBySkill = new Map(skillRows.map((s) => [s.id, s.name]));

  // Skills with a completed learning task are not re-planned: further progress on them is
  // verified by an assessment (learning tasks alone stop at LEARNING_CAP). This prevents duplicate tasks.
  const doneSkillIds = new Set(careerChanged ? [] : snap.tasks.filter((t) => t.status === "completed").map((t) => t.skillId));
  match = { ...match, gaps: match.gaps.filter((g) => !doneSkillIds.has(g.skillId)) };
  const gapIds = match.gaps.map((g) => g.skillId);
  const resources: ResourceRow[] = gapIds.length
    ? await db
        .select({
          id: learningResources.id,
          skillId: learningResources.skillId,
          title: learningResources.title,
          provider: learningResources.provider,
          url: learningResources.url,
          resourceType: learningResources.resourceType,
          estimatedHours: learningResources.estimatedHours,
        })
        .from(learningResources)
        .where(inArray(learningResources.skillId, gapIds))
    : [];

  const plan = learningPathAgent(match, categoryBySkill, nameBySkill, resources, snap.profile.weeklyHours);

  // Upsert the roadmap row (one active roadmap per learner).
  const [roadmap] = await db
    .insert(learningRoadmaps)
    .values({ userId, careerId: snap.career.id, generatedBy: "rule-based", weeklyHours: snap.profile.weeklyHours })
    .onConflictDoUpdate({
      target: learningRoadmaps.userId,
      set: {
        careerId: snap.career.id,
        generatedBy: "rule-based",
        weeklyHours: snap.profile.weeklyHours,
        updatedAt: new Date(),
      },
    })
    .returning({ id: learningRoadmaps.id });

  if (careerChanged) {
    // A different career invalidates the old plan, including completed tasks.
    await db.delete(roadmapTasks).where(eq(roadmapTasks.roadmapId, roadmap.id));
  }

  // Update pending tasks in place (same id) when the skill is still a gap; insert new ones;
  // delete only pending tasks whose skill is no longer a gap. Stable ids keep the UI reliable.
  const existingPending = careerChanged ? [] : snap.tasks.filter((t) => t.status === "pending");
  const pendingBySkill = new Map(existingPending.map((t) => [t.skillId, t]));
  const keptIds = new Set<number>();
  const startPosition = (careerChanged ? 0 : completedCount) + 1;

  let inserted = 0;
  for (const [i, t] of plan.tasks.entries()) {
    const values = {
      skillId: t.skillId,
      resourceId: t.resourceId,
      position: startPosition + i,
      priority: t.priority,
      weekNumber: t.weekNumber,
      estimatedHours: t.estimatedHours,
      title: t.title,
      practicalExercise: t.practicalExercise,
      miniProject: t.miniProject,
    };
    const current = pendingBySkill.get(t.skillId);
    if (current && !keptIds.has(current.id)) {
      await db.update(roadmapTasks).set(values).where(eq(roadmapTasks.id, current.id));
      keptIds.add(current.id);
    } else {
      await db.insert(roadmapTasks).values({ ...values, roadmapId: roadmap.id, userId, status: "pending" });
      inserted++;
    }
  }

  const staleIds = existingPending.filter((t) => !keptIds.has(t.id)).map((t) => t.id);
  if (staleIds.length) {
    await db.delete(roadmapTasks).where(inArray(roadmapTasks.id, staleIds));
  }

  await db
    .update(learnerProfiles)
    .set({ lastMatchPercentage: match.matchPercentage, updatedAt: new Date() })
    .where(eq(learnerProfiles.userId, userId));

  return { created: inserted, removedPending: careerChanged ? snap.tasks.length - completedCount : staleIds.length };
}

/** Sets a skill's proficiency for this learner (insert or update). */
export async function setProficiency(userId: number, skillId: number, proficiency: number, source: string) {
  const value = Math.max(0, Math.min(100, Math.round(proficiency)));
  await db
    .insert(learnerSkills)
    .values({ userId, skillId, proficiency: value, source })
    .onConflictDoUpdate({
      target: [learnerSkills.userId, learnerSkills.skillId],
      set: { proficiency: value, source, updatedAt: new Date() },
    });
  return value;
}

export async function recordProgress(
  userId: number,
  activityType: string,
  description: string,
  matchPercentage: number | null,
  metadata: Record<string, unknown> = {},
) {
  await db.insert(progressRecords).values({ userId, activityType, description, matchPercentage, metadata });
}

// =========================================================================
// PROGRESS ANALYTICS
// =========================================================================
export async function buildAnalytics(userId: number) {
  const snap = await loadSnapshot(userId);
  const skillAssessment = skillAssessmentAgent(snap);
  const matching = careerMatchingAgent(snap);
  const nextAction = recommendNextAction(snap, matching);

  const tasks = snap.tasks;
  const completed = tasks.filter((t) => t.status === "completed").length;
  const pending = tasks.filter((t) => t.status === "pending").length;
  const total = tasks.length;

  const since = new Date(Date.now() - 6 * 24 * 60 * 60 * 1000);
  since.setHours(0, 0, 0, 0);
  const recentRows = await db
    .select({ createdAt: progressRecords.createdAt, activityType: progressRecords.activityType })
    .from(progressRecords)
    .where(and(eq(progressRecords.userId, userId), gte(progressRecords.createdAt, since)));

  const weeklyActivity = Array.from({ length: 7 }, (_, i) => {
    const day = new Date(since.getTime() + i * 24 * 60 * 60 * 1000);
    const key = day.toDateString();
    const dayCount = recentRows.filter((r) => new Date(r.createdAt).toDateString() === key).length;
    return { day: day.toLocaleDateString("en-US", { weekday: "short" }), count: dayCount };
  });

  const recentActivities = await db
    .select({
      id: progressRecords.id,
      activityType: progressRecords.activityType,
      description: progressRecords.description,
      matchPercentage: progressRecords.matchPercentage,
      createdAt: progressRecords.createdAt,
    })
    .from(progressRecords)
    .where(eq(progressRecords.userId, userId))
    .orderBy(desc(progressRecords.createdAt))
    .limit(10);

  const [{ value: totalActivities }] = await db
    .select({ value: count() })
    .from(progressRecords)
    .where(eq(progressRecords.userId, userId));

  const passed = snap.assessments.some((a) => a.score >= 70);
  const achievements = [
    { id: "profile", title: "Profile Ready", description: "Completed onboarding.", unlocked: snap.profile.onboardingCompleted },
    { id: "inventory", title: "Skill Inventory", description: "Added 3 or more skills.", unlocked: snap.learnerSkills.length >= 3 },
    { id: "career", title: "Career Locked In", description: "Selected a target career.", unlocked: !!snap.career },
    { id: "roadmap", title: "Roadmap Launched", description: "Generated a personalised roadmap.", unlocked: !!snap.roadmap },
    { id: "milestone", title: "First Milestone", description: "Completed a roadmap task.", unlocked: completed >= 1 },
    { id: "assessed", title: "Assessment Passed", description: "Scored 70% or more on a skill check.", unlocked: passed },
    { id: "halfway", title: "Halfway There", description: "Career match reached 50%.", unlocked: matching.matchPercentage >= 50 },
    { id: "aligned", title: "Strong Alignment", description: "Career match reached 80%.", unlocked: matching.matchPercentage >= 80 },
  ];

  return {
    profile: {
      fullName: snap.fullName,
      educationLevel: snap.profile.educationLevel,
      institution: snap.profile.institution,
      weeklyHours: snap.profile.weeklyHours,
      onboardingCompleted: snap.profile.onboardingCompleted,
    },
    career: snap.career ? { id: snap.career.id, title: snap.career.title } : null,
    matchPercentage: matching.matchPercentage,
    matchFormula: matching.formula,
    disclaimer: MATCH_DISCLAIMER,
    roadmap: {
      exists: !!snap.roadmap,
      total,
      completed,
      pending,
      completionPercentage: total ? Math.round((completed / total) * 100) : 0,
    },
    skills: {
      total: snap.learnerSkills.length,
      mastered: matching.mastered.length,
      partial: matching.partial.length,
      missing: matching.missing.length,
      averageProficiency: skillAssessment.averageProficiency,
      needsImprovement: skillAssessment.weaknesses.length,
    },
    skillComparison: matching.comparison,
    weeklyActivity,
    recentActivities,
    totalActivities: Number(totalActivities),
    assessmentHistory: snap.assessments.slice(0, 10),
    achievements,
    nextAction,
    strengths: skillAssessment.strengths,
    weaknesses: skillAssessment.weaknesses,
  };
}

/** Helper for SQL-level aggregation of assessment averages (used by reports). */
export async function assessmentAverage(userId: number): Promise<number | null> {
  const [row] = await db
    .select({ avg: sql<string | null>`avg(${assessmentResults.score})` })
    .from(assessmentResults)
    .where(eq(assessmentResults.userId, userId));
  return row?.avg == null ? null : Math.round(Number(row.avg));
}

export { assessments };
