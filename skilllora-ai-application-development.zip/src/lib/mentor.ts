// AI Mentor (Agent 4). Uses an OpenAI-compatible chat API when LLM_API_KEY is configured
// on the server. Otherwise, or if the API call fails, a deterministic rule-based reply is used.
// Every reply is labelled with its source ("llm" or "rule-based") so the learner always knows.
import type { CareerMatchOutput } from "@/lib/agents";
import type { LearnerSnapshot, NextAction, SkillAssessmentOutput } from "@/lib/agents";
import { ASSESSMENT_SEEDS, SKILL_SEEDS, RESOURCE_SEEDS } from "@/lib/career-data";

export type MentorReply = {
  reply: string;
  source: "llm" | "rule-based";
  label: string;
  note?: string;
};

export function llmConfigured(): boolean {
  return !!process.env.LLM_API_KEY;
}

type MentorInput = {
  snap: LearnerSnapshot;
  match: CareerMatchOutput;
  assessment: SkillAssessmentOutput;
  nextAction: NextAction;
  history: { role: "user" | "assistant"; content: string }[];
  message: string;
};

function contextSummary({ snap, match, assessment, nextAction }: MentorInput): string {
  const pending = snap.tasks.filter((t) => t.status === "pending").slice(0, 4).map((t) => `- ${t.title} (week ${t.weekNumber}, ~${t.estimatedHours}h)`);
  return [
    `Learner: ${snap.fullName}`,
    `Education: ${snap.profile.educationLevel ?? "not provided"}${snap.profile.institution ? ` at ${snap.profile.institution}` : ""}`,
    `Weekly learning hours: ${snap.profile.weeklyHours}`,
    `Target career: ${match.careerTitle ?? "not selected"}`,
    `Career match: ${match.matchPercentage}% (${match.meetingThreshold} of ${match.totalRequired} required skills meet threshold)`,
    `Existing skills: ${snap.learnerSkills.map((s) => `${s.name} ${s.proficiency}%`).join(", ") || "none"}`,
    `Mastered: ${match.mastered.map((m) => m.name).join(", ") || "none"}`,
    `Partially developed: ${match.partial.map((m) => `${m.name} ${m.current}%`).join(", ") || "none"}`,
    `Missing: ${match.missing.map((m) => m.name).join(", ") || "none"}`,
    `Strengths: ${assessment.strengths.map((s) => s.name).join(", ") || "none yet"}`,
    `Weaknesses: ${assessment.weaknesses.map((w) => w.name).join(", ") || "none identified"}`,
    `Recent assessment scores: ${snap.assessments.slice(0, 5).map((a) => `${a.skillName} ${a.score}%`).join(", ") || "none"}`,
    `Roadmap tasks pending: ${pending.join("\n") || "none"}`,
    `Recommended next action: ${nextAction.title}`,
  ].join("\n");
}

const SYSTEM_PROMPT = `You are the SkillLora AI Mentor, a friendly career and learning guide for beginner students.
Rules:
- Explain concepts in simple, beginner-friendly English with short sentences.
- Use the learner context provided. Do not invent statistics, salaries, job openings or company names.
- Recommend concrete next steps, learning resources (named, not invented links) and small practical projects.
- Keep answers under 220 words. Use short bullet points when listing steps.
- Remind the learner that the career match % is an indicative skill-alignment measure, not a job guarantee, when relevant.`;

export async function generateMentorReply(input: MentorInput): Promise<MentorReply> {
  if (!llmConfigured()) {
    return ruleBasedReply(input, "No LLM API key is configured, so the rule-based mentor answered.");
  }
  try {
    const baseUrl = (process.env.LLM_BASE_URL || "https://api.openai.com/v1").replace(/\/$/, "");
    const model = process.env.LLM_MODEL || "gpt-4o-mini";
    const response = await fetch(`${baseUrl}/chat/completions`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${process.env.LLM_API_KEY}`,
      },
      body: JSON.stringify({
        model,
        temperature: 0.4,
        max_tokens: 500,
        messages: [
          { role: "system", content: `${SYSTEM_PROMPT}\n\nLEARNER CONTEXT:\n${contextSummary(input)}` },
          ...input.history.slice(-8),
          { role: "user", content: input.message },
        ],
      }),
      signal: AbortSignal.timeout(20000),
    });
    if (!response.ok) {
      throw new Error(`LLM responded with HTTP ${response.status}`);
    }
    const data = (await response.json()) as { choices?: { message?: { content?: string } }[] };
    const content = data.choices?.[0]?.message?.content?.trim();
    if (!content) throw new Error("LLM returned an empty reply");
    return { reply: content, source: "llm", label: `AI-generated (${model})` };
  } catch (error) {
    console.error("[mentor] LLM call failed, using fallback:", error instanceof Error ? error.message : error);
    return ruleBasedReply(input, "The AI service could not answer right now, so the rule-based mentor replied.");
  }
}

// ---- Rule-based fallback --------------------------------------------------

function findSkillInMessage(message: string, snap: LearnerSnapshot, match: CareerMatchOutput) {
  const lower = message.toLowerCase();
  const candidates = [...match.comparison.map((c) => c.skillName), ...SKILL_SEEDS.map((s) => s.name)];
  return candidates.find((name) => lower.includes(name.toLowerCase())) ?? null;
}

function ruleBasedReply(input: MentorInput, note: string): MentorReply {
  const { snap, match, assessment, nextAction, message } = input;
  const lower = message.toLowerCase();
  const pendingTasks = snap.tasks.filter((t) => t.status === "pending");
  const topGap = match.gaps[0];
  const parts: string[] = [];

  if (!snap.career) {
    parts.push("You have not chosen a target career yet. Open **Career Galaxy**, pick the role that interests you, and I can measure your skill alignment.");
  } else if (/match|score|percent|formula/.test(lower)) {
    parts.push(`Your match for **${match.careerTitle}** is **${match.matchPercentage}%**.`);
    parts.push(`It is calculated as ${match.formula.replace("Career Match % = ", "")}.`);
    parts.push("A skill counts as meeting the target when your proficiency reaches its threshold (level × 20). This is an indicative skill-alignment measure, not a job guarantee.");
  } else if (/roadmap|next|plan|step|what should|start/.test(lower)) {
    if (pendingTasks.length) {
      parts.push("Here is what I recommend next:");
      pendingTasks.slice(0, 3).forEach((t, i) => parts.push(`${i + 1}. ${t.title} (week ${t.weekNumber}, about ${t.estimatedHours} hours). Exercise: ${t.practicalExercise}`));
    } else {
      parts.push(`Recommended next action: **${nextAction.title}**. ${nextAction.description}`);
    }
  } else if (/project/.test(lower)) {
    const task = pendingTasks[0];
    parts.push(task
      ? `A good mini-project for your next step: ${task.miniProject}`
      : "Once you generate a roadmap, I can suggest mini-projects for each skill gap.");
  } else if (/resource|course|tutorial|learn|video|book/.test(lower) || (topGap && /how|where/.test(lower))) {
    const skillName = findSkillInMessage(message, snap, match) ?? topGap?.name;
    const resources = RESOURCE_SEEDS.filter((r) => r.skill === skillName);
    if (resources.length) {
      parts.push(`For **${skillName}**, start with:`);
      resources.slice(0, 2).forEach((r) => parts.push(`- ${r.title} by ${r.provider} (${r.estimatedHours} h): ${r.url}`));
    } else {
      parts.push("Tell me which skill you want resources for, for example 'resources for SQL'.");
    }
  } else if (/what is|explain|meaning|beginner/.test(lower) || findSkillInMessage(message, snap, match)) {
    const skillName = findSkillInMessage(message, snap, match);
    const seed = SKILL_SEEDS.find((s) => s.name === skillName);
    if (seed) {
      parts.push(`**${seed.name}** (${seed.category}): ${seed.description}`);
      const quiz = ASSESSMENT_SEEDS[seed.name]?.[0];
      if (quiz) parts.push(`Try this quick question: "${quiz.prompt}" Take the ${seed.name} assessment to check your level.`);
    } else {
      parts.push("Ask about a specific skill, such as 'What is Docker?', and I will explain it in simple terms.");
    }
  } else if (/strength|weak|improve|gap|missing/.test(lower)) {
    parts.push(`Strengths: ${assessment.strengths.map((s) => s.name).join(", ") || "none yet – take an assessment to discover them"}.`);
    parts.push(`Needs attention: ${match.gaps.slice(0, 4).map((g) => g.name).join(", ") || "no gaps for this career"}.`);
  } else {
    parts.push(`Hi ${snap.fullName.split(" ")[0]}! You are aiming for **${match.careerTitle}** with a **${match.matchPercentage}%** match.`);
    parts.push(`Recommended next action: **${nextAction.title}** – ${nextAction.description}`);
    parts.push("You can ask me about your match score, your next steps, a specific skill, or the best resources.");
  }

  return {
    reply: parts.join("\n\n"),
    source: "rule-based",
    label: "Rule-based mentor",
    note,
  };
}
