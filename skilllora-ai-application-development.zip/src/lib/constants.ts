// Shared, client-safe constants for the learner-facing pages.

export const PROFICIENCY_LEVELS = [
  { value: 25, label: "Beginner", hint: "Know the basics; need guidance" },
  { value: 50, label: "Intermediate", hint: "Can build small things independently" },
  { value: 75, label: "Advanced", hint: "Handle complex problems confidently" },
  { value: 90, label: "Expert", hint: "Teach others and design solutions" },
];

export const EDUCATION_LEVELS = [
  "High school",
  "Diploma",
  "Undergraduate (1st–2nd year)",
  "Undergraduate (3rd–4th year)",
  "Postgraduate",
  "Recent graduate",
  "Working professional",
  "Other",
];

export function levelLabel(value: number): string {
  if (value >= 90) return "Expert";
  if (value >= 75) return "Advanced";
  if (value >= 50) return "Intermediate";
  if (value > 0) return "Beginner";
  return "Not started";
}
