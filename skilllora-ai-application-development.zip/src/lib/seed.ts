import { count, eq, sql } from "drizzle-orm";
import { db } from "@/db";
import {
  assessments,
  careerRequiredSkills,
  careerRoles,
  learningResources,
  skills,
} from "@/db/schema";
import {
  ASSESSMENT_SEEDS,
  CAREER_SEEDS,
  RESOURCE_SEEDS,
  SKILL_SEEDS,
} from "@/lib/career-data";

let seeding: Promise<void> | null = null;

/**
 * Loads the SAMPLE demonstration dataset (skills, 8 careers, requirements,
 * learning resources and quizzes) into PostgreSQL. Idempotent: safe to call many times.
 * Only inserts rows that do not exist yet, so user data is never touched.
 */
export function ensureSeeded(): Promise<void> {
  if (!seeding) {
    seeding = runSeed().catch((error) => {
      seeding = null; // allow retry on next request
      throw error;
    });
  }
  return seeding;
}

async function runSeed(): Promise<void> {
  const [{ value: careerCount }] = await db.select({ value: count() }).from(careerRoles);
  if (Number(careerCount) >= CAREER_SEEDS.length) {
    // Dataset already present; still make sure every table is populated (cheap checks).
    const [{ value: assessmentCount }] = await db.select({ value: count() }).from(assessments);
    if (Number(assessmentCount) >= SKILL_SEEDS.length) return;
  }

  await db
    .insert(skills)
    .values(SKILL_SEEDS.map((s) => ({ ...s, isSample: true })))
    .onConflictDoNothing({ target: skills.name });

  const skillRows = await db.select({ id: skills.id, name: skills.name }).from(skills);
  const skillId = new Map(skillRows.map((s) => [s.name, s.id]));

  for (const career of CAREER_SEEDS) {
    await db
      .insert(careerRoles)
      .values({ slug: career.slug, title: career.title, description: career.description, isSample: true })
      .onConflictDoNothing({ target: careerRoles.slug });
  }

  const careerRows = await db.select({ id: careerRoles.id, slug: careerRoles.slug }).from(careerRoles);
  const careerId = new Map(careerRows.map((c) => [c.slug, c.id]));

  for (const career of CAREER_SEEDS) {
    const cid = careerId.get(career.slug);
    if (!cid) continue;
    for (const req of career.required) {
      const sid = skillId.get(req.skill);
      if (!sid) continue;
      await db
        .insert(careerRequiredSkills)
        .values({ careerId: cid, skillId: sid, requiredLevel: req.level, weight: req.weight ?? 1 })
        .onConflictDoNothing();
    }
  }

  const [{ value: resourceCount }] = await db.select({ value: count() }).from(learningResources);
  if (Number(resourceCount) === 0) {
    const rows = RESOURCE_SEEDS.flatMap((r) => {
      const sid = skillId.get(r.skill);
      return sid
        ? [{ skillId: sid, title: r.title, provider: r.provider, url: r.url, resourceType: r.resourceType, estimatedHours: r.estimatedHours, isSample: true }]
        : [];
    });
    if (rows.length) await db.insert(learningResources).values(rows);
  }

  for (const [skillName, questions] of Object.entries(ASSESSMENT_SEEDS)) {
    const sid = skillId.get(skillName);
    if (!sid) continue;
    await db
      .insert(assessments)
      .values({
        skillId: sid,
        title: `${skillName} Skill Check`,
        questions: questions.map((q, i) => ({ id: `${sid}-${i + 1}`, ...q })),
      })
      .onConflictDoNothing({ target: assessments.skillId });
  }
}

/** Returns the existing skill with this name, or creates a custom one (category "Custom"). */
export async function findOrCreateSkill(name: string): Promise<{ id: number; name: string; category: string }> {
  const existing = await db
    .select({ id: skills.id, name: skills.name, category: skills.category })
    .from(skills)
    .where(sql`lower(${skills.name}) = lower(${name})`)
    .limit(1);
  if (existing[0]) return existing[0];

  const inserted = await db
    .insert(skills)
    .values({ name, category: "Custom", description: "Learner-added skill.", isSample: false })
    .onConflictDoNothing({ target: skills.name })
    .returning({ id: skills.id, name: skills.name, category: skills.category });
  if (inserted[0]) return inserted[0];

  const again = await db
    .select({ id: skills.id, name: skills.name, category: skills.category })
    .from(skills)
    .where(eq(skills.name, name))
    .limit(1);
  return again[0];
}
