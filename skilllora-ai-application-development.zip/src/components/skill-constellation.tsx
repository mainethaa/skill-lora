"use client";

import Link from "next/link";
import { useState } from "react";
import { cn } from "@/components/ui";

export type ConstellationNode = {
  key: string;
  name: string;
  current: number;
  threshold: number;
  category: "mastered" | "learning" | "missing" | "recommended";
};

const ZONES: { key: ConstellationNode["category"]; label: string; color: string; cx: number; cy: number }[] = [
  { key: "mastered", label: "Mastered", color: "#61E6B5", cx: 150, cy: 115 },
  { key: "learning", label: "Being learned", color: "#36D9F5", cx: 450, cy: 115 },
  { key: "missing", label: "Missing", color: "#F87171", cx: 150, cy: 325 },
  { key: "recommended", label: "AI recommended", color: "#9B8CFF", cx: 450, cy: 325 },
];

/** Interactive SVG constellation: skill nodes grouped into four visual states. */
export function SkillConstellation({ nodes }: { nodes: ConstellationNode[] }) {
  const [selected, setSelected] = useState<string | null>(null);
  const active = nodes.find((n) => n.key === selected) ?? null;

  return (
    <div className="grid gap-5 lg:grid-cols-[1fr_260px]">
      <div className="relative overflow-hidden rounded-2xl border border-white/[0.06] bg-aurora-bg/50">
        <svg viewBox="0 0 600 440" className="h-auto w-full" role="group" aria-label="Skill constellation. Select a skill node to see details.">
          <defs>
            <radialGradient id="hub" cx="50%" cy="50%" r="50%">
              <stop offset="0%" stopColor="#36D9F5" stopOpacity="0.35" />
              <stop offset="100%" stopColor="#36D9F5" stopOpacity="0" />
            </radialGradient>
          </defs>
          <circle cx="300" cy="220" r="120" fill="url(#hub)" />
          {ZONES.map((z) => (
            <line key={`l-${z.key}`} x1="300" y1="220" x2={z.cx} y2={z.cy} stroke={z.color} strokeOpacity="0.18" strokeDasharray="4 6" />
          ))}
          <circle cx="300" cy="220" r="34" fill="#101A2E" stroke="#36D9F5" strokeWidth="1.5" />
          <text x="300" y="216" textAnchor="middle" fill="#F4F7FF" fontSize="12" fontWeight="600">YOU</text>
          <text x="300" y="232" textAnchor="middle" fill="#A5B1C8" fontSize="9">skill map</text>

          {ZONES.map((zone) => {
            const items = nodes.filter((n) => n.category === zone.key);
            const radius = items.length > 4 ? 72 : 58;
            return (
              <g key={zone.key}>
                <text x={zone.cx} y={zone.cy - 62} textAnchor="middle" fill={zone.color} fontSize="12" fontWeight="600">
                  {zone.label} ({items.length})
                </text>
                {items.length === 0 && (
                  <text x={zone.cx} y={zone.cy + 4} textAnchor="middle" fill="#A5B1C8" fontSize="11">None right now</text>
                )}
                {items.map((node, i) => {
                  const angle = (i / items.length) * Math.PI * 2 - Math.PI / 2;
                  const x = zone.cx + radius * Math.cos(angle) * (items.length === 1 ? 0 : 1);
                  const y = zone.cy + radius * Math.sin(angle) * (items.length === 1 ? 0 : 1) + (items.length === 1 ? 0 : 0);
                  const isSel = selected === node.key;
                  return (
                    <g
                      key={`${zone.key}-${node.key}`}
                      role="button"
                      tabIndex={0}
                      aria-label={`${node.name}, ${zone.label}`}
                      aria-pressed={isSel}
                      onClick={() => setSelected(node.key)}
                      onKeyDown={(e) => {
                        if (e.key === "Enter" || e.key === " ") {
                          e.preventDefault();
                          setSelected(node.key);
                        }
                      }}
                      className="cursor-pointer outline-none"
                    >
                      <line x1={zone.cx} y1={zone.cy} x2={x} y2={y} stroke={zone.color} strokeOpacity={isSel ? 0.7 : 0.25} />
                      <circle cx={x} cy={y} r={isSel ? 22 : 18} fill="#101A2E" stroke={zone.color} strokeWidth={isSel ? 3 : 1.5} className="transition-all duration-200" />
                      <circle cx={x} cy={y} r="4" fill={zone.color} />
                      <text x={x} y={y + 34} textAnchor="middle" fill="#F4F7FF" fontSize="10">
                        {node.name.length > 14 ? `${node.name.slice(0, 13)}…` : node.name}
                      </text>
                    </g>
                  );
                })}
              </g>
            );
          })}
        </svg>
      </div>

      <aside className="rounded-2xl border border-white/[0.07] bg-aurora-bg/40 p-5" aria-live="polite">
        {active ? (
          <div className="space-y-4">
            <div>
              <p className="text-xs uppercase tracking-wider text-aurora-muted">
                {ZONES.find((z) => z.key === active.category)?.label}
              </p>
              <h3 className="mt-1 text-lg font-semibold">{active.name}</h3>
            </div>
            <p className="text-sm text-aurora-muted">
              Your level: <span className="text-aurora-text">{active.current}%</span> · Target: <span className="text-aurora-text">{active.threshold}%</span>
            </p>
            <p className="text-sm leading-relaxed text-aurora-muted">
              {active.category === "mastered" && "You meet the target for this skill. Keep it sharp with a practice task."}
              {active.category === "learning" && "You have started this skill but have not reached the target. Complete its roadmap tasks and take the assessment."}
              {active.category === "missing" && "This skill is required for your career but you have not added it yet."}
              {active.category === "recommended" && "The Learning Path Agent ranks this as a high-priority next step."}
            </p>
            <Link href={active.category === "mastered" ? "/assessments" : "/roadmap"} className={cn("inline-flex text-sm font-medium text-aurora-cyan hover:underline")}>
              {active.category === "mastered" ? "Verify with an assessment →" : "Open in Learning Orbit →"}
            </Link>
          </div>
        ) : (
          <div className="space-y-3 text-sm text-aurora-muted">
            <p className="font-semibold text-aurora-text">How to read the map</p>
            <p>Each node is a skill. Nodes are grouped by status:</p>
            <ul className="space-y-2">
              <li><span className="text-aurora-mint">●</span> Mastered – meets the career target</li>
              <li><span className="text-aurora-cyan">●</span> Being learned – started, below target</li>
              <li><span className="text-rose-300">●</span> Missing – required, not yet added</li>
              <li><span className="text-aurora-violet">●</span> AI recommended – top next priorities</li>
            </ul>
            <p>Select a node to see its details.</p>
          </div>
        )}
      </aside>
    </div>
  );
}
