"use client";

import Link from "next/link";
import { usePathname, useRouter } from "next/navigation";
import { useEffect, useState, type ReactNode } from "react";
import {
  Bell,
  Bot,
  ChevronLeft,
  ClipboardCheck,
  Compass,
  LayoutDashboard,
  LogOut,
  Menu,
  Network,
  Route,
  TrendingUp,
  UserRound,
  X,
} from "lucide-react";
import { BrandMark, cn, useToast } from "@/components/ui";
import { api, errorMessage } from "@/lib/client-api";

const NAV = [
  { href: "/dashboard", label: "Dashboard", icon: LayoutDashboard },
  { href: "/assessments", label: "Skill Assessment", icon: ClipboardCheck },
  { href: "/careers", label: "Career Galaxy", icon: Compass },
  { href: "/gap-analysis", label: "Skill Gap Analysis", icon: Network },
  { href: "/roadmap", label: "Learning Orbit", icon: Route },
  { href: "/mentor", label: "AI Mentor", icon: Bot },
  { href: "/progress", label: "Progress", icon: TrendingUp },
  { href: "/profile", label: "Profile", icon: UserRound },
];

type Notice = { id: number; activityType: string; description: string; createdAt: string };

export function AppShell({ user, children }: { user: { fullName: string; email: string }; children: ReactNode }) {
  const pathname = usePathname();
  const router = useRouter();
  const toast = useToast();
  const [collapsed, setCollapsed] = useState(false);
  const [mobileOpen, setMobileOpen] = useState(false);
  const [notifOpen, setNotifOpen] = useState(false);
  const [notices, setNotices] = useState<Notice[] | null>(null);
  const [loggingOut, setLoggingOut] = useState(false);

  useEffect(() => {
    setCollapsed(localStorage.getItem("sl-sidebar") === "collapsed");
  }, []);

  useEffect(() => {
    setMobileOpen(false);
  }, [pathname]);

  useEffect(() => {
    if (!notifOpen || notices !== null) return;
    api<{ records: Notice[] }>("/api/progress")
      .then((d) => setNotices(d.records.slice(0, 6)))
      .catch(() => setNotices([]));
  }, [notifOpen, notices]);

  function toggleCollapsed() {
    setCollapsed((prev) => {
      localStorage.setItem("sl-sidebar", prev ? "expanded" : "collapsed");
      return !prev;
    });
  }

  async function logout() {
    setLoggingOut(true);
    try {
      await api("/api/auth/logout", { method: "POST" });
      router.replace("/login");
      router.refresh();
    } catch (error) {
      toast.show("error", errorMessage(error));
      setLoggingOut(false);
    }
  }

  const initials = user.fullName
    .split(" ")
    .map((p) => p[0])
    .slice(0, 2)
    .join("")
    .toUpperCase();

  const navList = (compact: boolean) => (
    <nav aria-label="Main navigation" className="flex flex-col gap-1">
      {NAV.map((item) => {
        const active = pathname === item.href || pathname.startsWith(`${item.href}/`);
        const Icon = item.icon;
        return (
          <Link
            key={item.href}
            href={item.href}
            title={compact ? item.label : undefined}
            aria-current={active ? "page" : undefined}
            className={cn(
              "group flex items-center gap-3 rounded-xl px-3 py-2.5 text-sm font-medium transition duration-200",
              active
                ? "bg-gradient-to-r from-aurora-cyan/15 to-aurora-mint/5 text-aurora-text ring-1 ring-aurora-cyan/25"
                : "text-aurora-muted hover:bg-white/5 hover:text-aurora-text",
              compact && "justify-center px-2",
            )}
          >
            <Icon className={cn("h-[18px] w-[18px] shrink-0", active ? "text-aurora-cyan" : "text-aurora-muted group-hover:text-aurora-cyan")} aria-hidden />
            {!compact && <span className="truncate">{item.label}</span>}
          </Link>
        );
      })}
    </nav>
  );

  return (
    <div className="min-h-screen">
      {/* Desktop sidebar */}
      <aside
        className={cn(
          "fixed inset-y-0 left-0 z-40 hidden flex-col border-r border-white/[0.06] bg-aurora-bg/90 backdrop-blur-xl transition-[width] duration-300 md:flex",
          collapsed ? "w-20" : "w-64",
        )}
      >
        <div className={cn("flex h-16 items-center border-b border-white/[0.06] px-4", collapsed && "justify-center px-2")}>
          {collapsed ? <BrandMark className="justify-center" /> : <BrandMark />}
        </div>
        <div className="flex-1 overflow-y-auto p-3">{navList(collapsed)}</div>
        <div className="border-t border-white/[0.06] p-3">
          <button
            type="button"
            onClick={toggleCollapsed}
            aria-label={collapsed ? "Expand sidebar" : "Collapse sidebar"}
            className="flex w-full items-center justify-center gap-2 rounded-xl px-3 py-2 text-xs text-aurora-muted hover:bg-white/5 hover:text-aurora-text"
          >
            <ChevronLeft className={cn("h-4 w-4 transition-transform duration-300", collapsed && "rotate-180")} aria-hidden />
            {!collapsed && "Collapse"}
          </button>
        </div>
      </aside>

      {/* Mobile drawer */}
      {mobileOpen && (
        <div className="fixed inset-0 z-50 md:hidden" role="dialog" aria-modal="true" aria-label="Navigation menu">
          <button type="button" aria-label="Close menu" className="absolute inset-0 bg-black/60" onClick={() => setMobileOpen(false)} />
          <div className="animate-fade-in absolute inset-y-0 left-0 flex w-72 flex-col border-r border-white/10 bg-aurora-bg p-4 shadow-2xl">
            <div className="mb-4 flex items-center justify-between">
              <BrandMark />
              <button type="button" aria-label="Close menu" onClick={() => setMobileOpen(false)} className="rounded-lg p-2 text-aurora-muted hover:bg-white/5">
                <X className="h-5 w-5" />
              </button>
            </div>
            {navList(false)}
          </div>
        </div>
      )}

      <div className={cn("transition-[padding] duration-300", collapsed ? "md:pl-20" : "md:pl-64")}>
        {/* Top bar */}
        <header className="sticky top-0 z-30 flex h-16 items-center justify-between border-b border-white/[0.06] bg-aurora-bg/80 px-4 backdrop-blur-xl sm:px-6">
          <div className="flex items-center gap-3 md:hidden">
            <button type="button" aria-label="Open menu" onClick={() => setMobileOpen(true)} className="rounded-lg p-2 text-aurora-muted hover:bg-white/5">
              <Menu className="h-5 w-5" />
            </button>
            <BrandMark />
          </div>
          <div className="hidden text-sm text-aurora-muted md:block">
            Signed in as <span className="text-aurora-text">{user.email}</span>
          </div>

          <div className="flex items-center gap-2">
            <div className="relative">
              <button
                type="button"
                aria-label="Notifications"
                aria-expanded={notifOpen}
                onClick={() => setNotifOpen((v) => !v)}
                className="relative rounded-xl p-2.5 text-aurora-muted transition hover:bg-white/5 hover:text-aurora-text"
              >
                <Bell className="h-5 w-5" />
              </button>
              {notifOpen && (
                <div className="animate-fade-in absolute right-0 mt-2 w-80 max-w-[90vw] rounded-2xl border border-white/10 bg-aurora-surface p-3 shadow-2xl">
                  <p className="px-2 pb-2 text-sm font-semibold">Recent activity</p>
                  {notices === null ? (
                    <div className="space-y-2 p-2">
                      <div className="skeleton h-10 rounded-lg" />
                      <div className="skeleton h-10 rounded-lg" />
                    </div>
                  ) : notices.length === 0 ? (
                    <p className="p-2 text-sm text-aurora-muted">No activity yet. Start with your profile or a roadmap task.</p>
                  ) : (
                    <ul className="max-h-72 space-y-1 overflow-y-auto">
                      {notices.map((n) => (
                        <li key={n.id} className="rounded-lg p-2 text-xs leading-relaxed text-aurora-muted hover:bg-white/5">
                          <span className="text-aurora-text">{n.description}</span>
                          <span className="mt-1 block text-[11px] text-aurora-muted/70">{new Date(n.createdAt).toLocaleString()}</span>
                        </li>
                      ))}
                    </ul>
                  )}
                </div>
              )}
            </div>

            <div className="hidden items-center gap-2.5 rounded-xl border border-white/10 bg-aurora-surface/60 py-1.5 pl-1.5 pr-3 sm:flex">
              <div className="grid h-8 w-8 place-items-center rounded-lg bg-gradient-to-br from-aurora-violet to-aurora-cyan text-xs font-bold text-aurora-bg">
                {initials || "SL"}
              </div>
              <div className="leading-tight">
                <p className="max-w-[140px] truncate text-sm font-medium">{user.fullName}</p>
                <p className="text-[11px] text-aurora-muted">Learner</p>
              </div>
            </div>

            <button
              type="button"
              onClick={logout}
              disabled={loggingOut}
              className="inline-flex items-center gap-2 rounded-xl border border-white/10 px-3 py-2 text-sm text-aurora-muted transition hover:border-rose-400/40 hover:text-rose-200 disabled:opacity-50"
            >
              <LogOut className="h-4 w-4" aria-hidden />
              <span className="hidden sm:inline">{loggingOut ? "Logging out…" : "Log out"}</span>
            </button>
          </div>
        </header>

        <main key={pathname} className="animate-fade-in mx-auto w-full max-w-7xl px-4 py-6 sm:px-6 lg:px-8">
          {children}
        </main>
      </div>
    </div>
  );
}
