"use client";

import Link from "next/link";
import { useRouter } from "next/navigation";
import { useState, type FormEvent } from "react";
import { Eye, EyeOff, LoaderCircle, Lock, Mail, ShieldCheck, Sparkles, UserRound } from "lucide-react";
import { BrandMark, Button, Field, Input, cn, useToast } from "@/components/ui";
import { ApiError, api, errorMessage } from "@/lib/client-api";

type Mode = "login" | "register";

export function AuthForm({ mode }: { mode: Mode }) {
  const router = useRouter();
  const toast = useToast();
  const isRegister = mode === "register";
  const [submitting, setSubmitting] = useState(false);
  const [showPassword, setShowPassword] = useState(false);
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [formError, setFormError] = useState("");

  async function onSubmit(e: FormEvent<HTMLFormElement>) {
    e.preventDefault();
    setErrors({});
    setFormError("");
    const form = new FormData(e.currentTarget);
    const payload = {
      fullName: String(form.get("fullName") ?? ""),
      email: String(form.get("email") ?? ""),
      password: String(form.get("password") ?? ""),
    };

    // Quick client-side checks; the server repeats them for security.
    const local: Record<string, string> = {};
    if (isRegister && payload.fullName.trim().length < 2) local.fullName = "Enter your full name.";
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(payload.email.trim())) local.email = "Enter a valid email address.";
    if (!payload.password) local.password = "Enter your password.";
    if (isRegister && payload.password && payload.password.length < 8) local.password = "Use at least 8 characters.";
    if (Object.keys(local).length) {
      setErrors(local);
      return;
    }

    setSubmitting(true);
    try {
      await api(isRegister ? "/api/auth/register" : "/api/auth/login", {
        method: "POST",
        body: isRegister ? payload : { email: payload.email, password: payload.password },
      });
      toast.show("success", isRegister ? "Account created. Let's set up your profile." : "Welcome back!");
      router.replace(isRegister ? "/onboarding" : "/dashboard");
      router.refresh();
    } catch (error) {
      if (error instanceof ApiError && error.details) setErrors(error.details);
      setFormError(errorMessage(error));
      setSubmitting(false);
    }
  }

  return (
    <div className="grid min-h-screen lg:grid-cols-2">
      <div className="relative hidden flex-col justify-between overflow-hidden border-r border-white/[0.06] p-12 lg:flex">
        <div className="absolute inset-0 -z-10 bg-[radial-gradient(600px_400px_at_20%_20%,rgba(54,217,245,0.12),transparent)]" />
        <Link href="/" aria-label="SkillLora AI home"><BrandMark /></Link>
        <div className="max-w-md">
          <p className="inline-flex items-center gap-2 rounded-full border border-aurora-cyan/25 bg-aurora-cyan/10 px-3 py-1 text-xs text-aurora-cyan">
            <Sparkles className="h-3.5 w-3.5" aria-hidden /> Adaptive Skill Intelligence Engine
          </p>
          <h2 className="mt-5 text-3xl font-semibold leading-tight tracking-tight">Discover your skills. Design your future.</h2>
          <p className="mt-4 text-sm leading-relaxed text-aurora-muted">
            Every score, gap and roadmap task is calculated from your own data and saved securely in PostgreSQL.
          </p>
          <ul className="mt-8 space-y-3 text-sm text-aurora-muted">
            <li className="flex items-center gap-3"><ShieldCheck className="h-4 w-4 text-aurora-mint" aria-hidden /> Passwords are hashed with scrypt and never stored in plain text.</li>
            <li className="flex items-center gap-3"><ShieldCheck className="h-4 w-4 text-aurora-mint" aria-hidden /> Sessions use secure, httpOnly cookies.</li>
          </ul>
        </div>
        <p className="text-xs text-aurora-muted/70">© SkillLora AI · Hackathon build</p>
      </div>

      <div className="flex items-center justify-center p-6 sm:p-10">
        <div className="animate-fade-in w-full max-w-md">
          <div className="mb-8 lg:hidden"><Link href="/" aria-label="SkillLora AI home"><BrandMark /></Link></div>
          <h1 className="text-2xl font-semibold tracking-tight">{isRegister ? "Create your account" : "Welcome back"}</h1>
          <p className="mt-2 text-sm text-aurora-muted">
            {isRegister ? "Start your personalised career intelligence journey." : "Log in to continue your learning roadmap."}
          </p>

          <form onSubmit={onSubmit} noValidate className="mt-8 space-y-5">
            {formError && (
              <div role="alert" className="rounded-xl border border-rose-400/30 bg-rose-500/10 px-4 py-3 text-sm text-rose-100">
                {formError}
              </div>
            )}

            {isRegister && (
              <Field label="Full name" htmlFor="fullName" error={errors.fullName}>
                <div className="relative">
                  <UserRound className="pointer-events-none absolute left-3.5 top-1/2 h-4 w-4 -translate-y-1/2 text-aurora-muted" aria-hidden />
                  <Input id="fullName" name="fullName" autoComplete="name" placeholder="Ada Lovelace" className="pl-10" aria-invalid={!!errors.fullName} />
                </div>
              </Field>
            )}

            <Field label="Email" htmlFor="email" error={errors.email}>
              <div className="relative">
                <Mail className="pointer-events-none absolute left-3.5 top-1/2 h-4 w-4 -translate-y-1/2 text-aurora-muted" aria-hidden />
                <Input id="email" name="email" type="email" autoComplete="email" placeholder="you@college.edu" className="pl-10" aria-invalid={!!errors.email} />
              </div>
            </Field>

            <Field label="Password" htmlFor="password" error={errors.password} hint={isRegister ? "At least 8 characters with a letter and a number." : undefined}>
              <div className="relative">
                <Lock className="pointer-events-none absolute left-3.5 top-1/2 h-4 w-4 -translate-y-1/2 text-aurora-muted" aria-hidden />
                <Input
                  id="password"
                  name="password"
                  type={showPassword ? "text" : "password"}
                  autoComplete={isRegister ? "new-password" : "current-password"}
                  placeholder="••••••••"
                  className="pl-10 pr-11"
                  aria-invalid={!!errors.password}
                />
                <button
                  type="button"
                  onClick={() => setShowPassword((v) => !v)}
                  aria-label={showPassword ? "Hide password" : "Show password"}
                  className="absolute right-3 top-1/2 -translate-y-1/2 rounded-md p-1 text-aurora-muted hover:text-aurora-text"
                >
                  {showPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                </button>
              </div>
            </Field>

            <Button type="submit" size="lg" className={cn("w-full")} loading={submitting}>
              {submitting && <LoaderCircle className="sr-only" aria-hidden />}
              {isRegister ? "Create account" : "Log in"}
            </Button>
          </form>

          <p className="mt-6 text-center text-sm text-aurora-muted">
            {isRegister ? "Already have an account?" : "New to SkillLora?"}{" "}
            <Link href={isRegister ? "/login" : "/register"} className="font-medium text-aurora-cyan hover:underline">
              {isRegister ? "Log in" : "Create an account"}
            </Link>
          </p>
        </div>
      </div>
    </div>
  );
}
