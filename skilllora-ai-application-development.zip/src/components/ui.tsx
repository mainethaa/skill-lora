"use client";

import Link from "next/link";
import {
  createContext,
  useCallback,
  useContext,
  useMemo,
  useState,
  type ButtonHTMLAttributes,
  type InputHTMLAttributes,
  type ReactNode,
  type SelectHTMLAttributes,
  type TextareaHTMLAttributes,
} from "react";
import { CheckCircle2, CircleAlert, Info, LoaderCircle, X } from "lucide-react";

export function cn(...parts: (string | false | null | undefined)[]) {
  return parts.filter(Boolean).join(" ");
}

// ---- Buttons --------------------------------------------------------------
type Variant = "primary" | "secondary" | "ghost" | "danger";
const VARIANTS: Record<Variant, string> = {
  primary:
    "btn-glow bg-gradient-to-r from-aurora-cyan to-aurora-mint text-aurora-bg font-semibold hover:brightness-110",
  secondary: "border border-white/10 bg-aurora-raised text-aurora-text hover:border-aurora-cyan/40 hover:bg-aurora-raised/80",
  ghost: "text-aurora-muted hover:bg-white/5 hover:text-aurora-text",
  danger: "border border-rose-400/30 bg-rose-500/10 text-rose-200 hover:bg-rose-500/20",
};

export function buttonClass(variant: Variant = "primary", size: "sm" | "md" | "lg" = "md", extra?: string) {
  return cn(
    "inline-flex items-center justify-center gap-2 rounded-xl transition duration-200 focus-visible:outline-none disabled:cursor-not-allowed disabled:opacity-50",
    size === "sm" && "px-3 py-1.5 text-sm",
    size === "md" && "px-4 py-2.5 text-sm",
    size === "lg" && "px-6 py-3.5 text-base",
    VARIANTS[variant],
    extra,
  );
}

export function Button({
  variant = "primary",
  size = "md",
  loading,
  className,
  children,
  disabled,
  ...rest
}: ButtonHTMLAttributes<HTMLButtonElement> & { variant?: Variant; size?: "sm" | "md" | "lg"; loading?: boolean }) {
  return (
    <button {...rest} disabled={disabled || loading} className={buttonClass(variant, size, className)}>
      {loading && <LoaderCircle className="h-4 w-4 animate-spin" aria-hidden />}
      {children}
    </button>
  );
}

export function ButtonLink({
  href,
  variant = "primary",
  size = "md",
  className,
  children,
}: {
  href: string;
  variant?: Variant;
  size?: "sm" | "md" | "lg";
  className?: string;
  children: ReactNode;
}) {
  return (
    <Link href={href} className={buttonClass(variant, size, className)}>
      {children}
    </Link>
  );
}

// ---- Surfaces -------------------------------------------------------------
export function Card({ className, children, id }: { className?: string; children: ReactNode; id?: string }) {
  return (
    <section
      id={id}
      className={cn(
        "rounded-2xl border border-white/[0.07] bg-gradient-to-b from-aurora-surface to-aurora-surface/70 p-5 shadow-[0_10px_30px_-18px_rgba(0,0,0,0.8)] sm:p-6",
        className,
      )}
    >
      {children}
    </section>
  );
}

export function PageHeader({
  eyebrow,
  title,
  description,
  actions,
}: {
  eyebrow?: string;
  title: string;
  description?: string;
  actions?: ReactNode;
}) {
  return (
    <div className="mb-6 flex flex-col gap-4 sm:flex-row sm:items-end sm:justify-between">
      <div className="min-w-0">
        {eyebrow && <p className="text-xs font-semibold uppercase tracking-[0.18em] text-aurora-cyan">{eyebrow}</p>}
        <h1 className="mt-1 text-2xl font-semibold tracking-tight text-aurora-text sm:text-3xl">{title}</h1>
        {description && <p className="mt-2 max-w-3xl text-sm leading-relaxed text-aurora-muted">{description}</p>}
      </div>
      {actions && <div className="flex flex-wrap gap-2">{actions}</div>}
    </div>
  );
}

export function Badge({
  tone = "neutral",
  children,
}: {
  tone?: "neutral" | "cyan" | "mint" | "violet" | "amber" | "rose";
  children: ReactNode;
}) {
  const tones = {
    neutral: "border-white/10 bg-white/5 text-aurora-muted",
    cyan: "border-aurora-cyan/30 bg-aurora-cyan/10 text-aurora-cyan",
    mint: "border-aurora-mint/30 bg-aurora-mint/10 text-aurora-mint",
    violet: "border-aurora-violet/30 bg-aurora-violet/10 text-aurora-violet",
    amber: "border-amber-300/30 bg-amber-300/10 text-amber-200",
    rose: "border-rose-400/30 bg-rose-400/10 text-rose-200",
  };
  return (
    <span className={cn("inline-flex items-center gap-1 rounded-full border px-2.5 py-0.5 text-xs font-medium", tones[tone])}>
      {children}
    </span>
  );
}

// ---- Form controls --------------------------------------------------------
const CONTROL =
  "w-full rounded-xl border border-white/10 bg-aurora-bg/60 px-3.5 py-2.5 text-sm text-aurora-text placeholder:text-aurora-muted/60 transition focus:border-aurora-cyan/60 focus:outline-none focus:ring-2 focus:ring-aurora-cyan/20 disabled:opacity-60";

export function Field({
  label,
  htmlFor,
  error,
  hint,
  children,
}: {
  label: string;
  htmlFor: string;
  error?: string;
  hint?: string;
  children: ReactNode;
}) {
  return (
    <div className="space-y-1.5">
      <label htmlFor={htmlFor} className="block text-sm font-medium text-aurora-text">
        {label}
      </label>
      {children}
      {hint && !error && <p className="text-xs text-aurora-muted">{hint}</p>}
      {error && (
        <p role="alert" className="text-xs text-rose-300">
          {error}
        </p>
      )}
    </div>
  );
}

export function Input(props: InputHTMLAttributes<HTMLInputElement>) {
  return <input {...props} className={cn(CONTROL, props.className)} />;
}

export function Select(props: SelectHTMLAttributes<HTMLSelectElement>) {
  return <select {...props} className={cn(CONTROL, "appearance-none pr-9", props.className)} />;
}

export function Textarea(props: TextareaHTMLAttributes<HTMLTextAreaElement>) {
  return <textarea {...props} className={cn(CONTROL, props.className)} />;
}

// ---- Progress visuals -----------------------------------------------------
export function ProgressRing({
  value,
  size = 120,
  stroke = 10,
  label,
  sublabel,
}: {
  value: number;
  size?: number;
  stroke?: number;
  label?: string;
  sublabel?: string;
}) {
  const clamped = Math.max(0, Math.min(100, Math.round(value)));
  const r = (size - stroke) / 2;
  const c = 2 * Math.PI * r;
  return (
    <div className="relative inline-flex items-center justify-center" style={{ width: size, height: size }}>
      <svg width={size} height={size} className="-rotate-90" aria-hidden>
        <circle cx={size / 2} cy={size / 2} r={r} fill="none" stroke="rgba(255,255,255,0.08)" strokeWidth={stroke} />
        <circle
          cx={size / 2}
          cy={size / 2}
          r={r}
          fill="none"
          stroke="url(#ring-grad)"
          strokeWidth={stroke}
          strokeLinecap="round"
          strokeDasharray={c}
          strokeDashoffset={c - (clamped / 100) * c}
          className="progress-ring-arc"
        />
        <defs>
          <linearGradient id="ring-grad" x1="0" y1="0" x2="1" y2="1">
            <stop offset="0%" stopColor="#36D9F5" />
            <stop offset="100%" stopColor="#61E6B5" />
          </linearGradient>
        </defs>
      </svg>
      <div className="absolute inset-0 flex flex-col items-center justify-center text-center">
        <span className="text-2xl font-semibold text-aurora-text">{label ?? `${clamped}%`}</span>
        {sublabel && <span className="text-xs text-aurora-muted">{sublabel}</span>}
      </div>
    </div>
  );
}

export function ProgressBar({ value, tone = "cyan" }: { value: number; tone?: "cyan" | "mint" | "violet" | "amber" }) {
  const clamped = Math.max(0, Math.min(100, Math.round(value)));
  const grads = {
    cyan: "from-aurora-cyan to-aurora-mint",
    mint: "from-aurora-mint to-aurora-cyan",
    violet: "from-aurora-violet to-aurora-cyan",
    amber: "from-amber-300 to-aurora-mint",
  };
  return (
    <div className="h-2 w-full overflow-hidden rounded-full bg-white/[0.06]" role="progressbar" aria-valuenow={clamped} aria-valuemin={0} aria-valuemax={100}>
      <div className={cn("h-full rounded-full bg-gradient-to-r transition-all duration-700", grads[tone])} style={{ width: `${clamped}%` }} />
    </div>
  );
}

// ---- States ---------------------------------------------------------------
export function Skeleton({ className }: { className?: string }) {
  return <div className={cn("skeleton rounded-xl", className)} aria-hidden />;
}

export function EmptyState({
  icon,
  title,
  description,
  action,
}: {
  icon: ReactNode;
  title: string;
  description: string;
  action?: ReactNode;
}) {
  return (
    <div className="flex flex-col items-center justify-center rounded-2xl border border-dashed border-white/10 bg-aurora-bg/30 px-6 py-10 text-center">
      <div className="mb-3 grid h-12 w-12 place-items-center rounded-2xl bg-aurora-cyan/10 text-aurora-cyan">{icon}</div>
      <h3 className="text-base font-semibold text-aurora-text">{title}</h3>
      <p className="mt-1 max-w-md text-sm text-aurora-muted">{description}</p>
      {action && <div className="mt-4">{action}</div>}
    </div>
  );
}

export function ErrorBanner({ message, onRetry }: { message: string; onRetry?: () => void }) {
  return (
    <div role="alert" className="flex flex-col gap-3 rounded-2xl border border-rose-400/30 bg-rose-500/10 p-4 text-sm text-rose-100 sm:flex-row sm:items-center sm:justify-between">
      <span className="flex items-center gap-2">
        <CircleAlert className="h-4 w-4 shrink-0" aria-hidden /> {message}
      </span>
      {onRetry && (
        <Button variant="secondary" size="sm" onClick={onRetry}>
          Try again
        </Button>
      )}
    </div>
  );
}

// ---- Toasts (success / error notifications) -------------------------------
type ToastTone = "success" | "error" | "info";
type ToastItem = { id: number; tone: ToastTone; message: string };
type ToastApi = { show: (tone: ToastTone, message: string) => void };

const ToastContext = createContext<ToastApi>({ show: () => {} });

export function useToast() {
  return useContext(ToastContext);
}

export function ToastProvider({ children }: { children: ReactNode }) {
  const [items, setItems] = useState<ToastItem[]>([]);

  const show = useCallback((tone: ToastTone, message: string) => {
    const id = Date.now() + Math.random();
    setItems((prev) => [...prev.slice(-3), { id, tone, message }]);
    setTimeout(() => setItems((prev) => prev.filter((t) => t.id !== id)), 4200);
  }, []);

  const api = useMemo(() => ({ show }), [show]);

  return (
    <ToastContext.Provider value={api}>
      {children}
      <div className="pointer-events-none fixed bottom-4 right-4 z-[100] flex w-[min(92vw,380px)] flex-col gap-2" aria-live="polite">
        {items.map((t) => (
          <div
            key={t.id}
            className={cn(
              "animate-fade-in pointer-events-auto flex items-start gap-3 rounded-xl border bg-aurora-surface/95 p-3.5 text-sm shadow-xl backdrop-blur",
              t.tone === "success" && "border-aurora-mint/30 text-aurora-text",
              t.tone === "error" && "border-rose-400/40 text-rose-100",
              t.tone === "info" && "border-aurora-cyan/30 text-aurora-text",
            )}
          >
            {t.tone === "success" ? (
              <CheckCircle2 className="mt-0.5 h-4 w-4 shrink-0 text-aurora-mint" aria-hidden />
            ) : t.tone === "error" ? (
              <CircleAlert className="mt-0.5 h-4 w-4 shrink-0 text-rose-300" aria-hidden />
            ) : (
              <Info className="mt-0.5 h-4 w-4 shrink-0 text-aurora-cyan" aria-hidden />
            )}
            <span className="flex-1">{t.message}</span>
            <button
              type="button"
              aria-label="Dismiss notification"
              className="text-aurora-muted hover:text-aurora-text"
              onClick={() => setItems((prev) => prev.filter((x) => x.id !== t.id))}
            >
              <X className="h-4 w-4" />
            </button>
          </div>
        ))}
      </div>
    </ToastContext.Provider>
  );
}

// ---- Brand ----------------------------------------------------------------
export function BrandMark({ className }: { className?: string }) {
  return (
    <div className={cn("flex items-center gap-2.5", className)}>
      <div className="grid h-9 w-9 place-items-center rounded-xl bg-gradient-to-br from-aurora-cyan via-aurora-violet to-aurora-mint p-[1.5px]">
        <div className="grid h-full w-full place-items-center rounded-[10px] bg-aurora-bg">
          <svg viewBox="0 0 24 24" className="h-5 w-5" fill="none" aria-hidden>
            <path d="M12 3l1.9 5.1L19 10l-5.1 1.9L12 17l-1.9-5.1L5 10l5.1-1.9L12 3z" stroke="#36D9F5" strokeWidth="1.6" strokeLinejoin="round" />
            <circle cx="18.5" cy="18.5" r="1.6" fill="#61E6B5" />
          </svg>
        </div>
      </div>
      <div className="leading-tight">
        <p className="text-base font-semibold tracking-tight text-aurora-text">SkillLora AI</p>
        <p className="text-[10px] uppercase tracking-[0.2em] text-aurora-muted">Career Intelligence OS</p>
      </div>
    </div>
  );
}
