"use client";

import {
  Bar,
  BarChart,
  CartesianGrid,
  Legend,
  PolarAngleAxis,
  PolarGrid,
  PolarRadiusAxis,
  Radar,
  RadarChart,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from "recharts";

const AXIS = "#A5B1C8";
const GRID = "rgba(255,255,255,0.06)";
const TOOLTIP_STYLE = {
  background: "#101A2E",
  border: "1px solid rgba(255,255,255,0.1)",
  borderRadius: 12,
  color: "#F4F7FF",
  fontSize: 12,
};

/** Target threshold vs current proficiency for each required skill. */
export function SkillComparisonChart({
  data,
}: {
  data: { skillName: string; required: number; current: number }[];
}) {
  const rows = data.map((d) => ({ name: d.skillName.length > 14 ? `${d.skillName.slice(0, 13)}…` : d.skillName, Target: d.required, Current: d.current }));
  return (
    <div className="h-72 w-full" role="img" aria-label="Bar chart comparing your current skill levels with career targets">
      <ResponsiveContainer width="100%" height="100%">
        <BarChart data={rows} margin={{ top: 8, right: 8, left: -12, bottom: 40 }}>
          <CartesianGrid stroke={GRID} vertical={false} />
          <XAxis dataKey="name" tick={{ fill: AXIS, fontSize: 11 }} angle={-30} textAnchor="end" interval={0} height={60} axisLine={false} tickLine={false} />
          <YAxis domain={[0, 100]} tick={{ fill: AXIS, fontSize: 11 }} axisLine={false} tickLine={false} />
          <Tooltip contentStyle={TOOLTIP_STYLE} cursor={{ fill: "rgba(255,255,255,0.03)" }} formatter={(v) => `${v}%`} />
          <Legend wrapperStyle={{ fontSize: 12, color: AXIS }} />
          <Bar dataKey="Target" fill="#9B8CFF" radius={[6, 6, 0, 0]} opacity={0.55} />
          <Bar dataKey="Current" fill="#36D9F5" radius={[6, 6, 0, 0]} />
        </BarChart>
      </ResponsiveContainer>
    </div>
  );
}

export function SkillRadarChart({ data }: { data: { skillName: string; required: number; current: number }[] }) {
  const rows = data.map((d) => ({ subject: d.skillName.length > 16 ? `${d.skillName.slice(0, 15)}…` : d.skillName, Target: d.required, Current: d.current }));
  return (
    <div className="h-80 w-full" role="img" aria-label="Radar chart of skill proficiency against target">
      <ResponsiveContainer width="100%" height="100%">
        <RadarChart data={rows} outerRadius="72%">
          <PolarGrid stroke={GRID} />
          <PolarAngleAxis dataKey="subject" tick={{ fill: AXIS, fontSize: 11 }} />
          <PolarRadiusAxis domain={[0, 100]} tick={false} axisLine={false} />
          <Tooltip contentStyle={TOOLTIP_STYLE} formatter={(v) => `${v}%`} />
          <Radar name="Target" dataKey="Target" stroke="#9B8CFF" fill="#9B8CFF" fillOpacity={0.15} />
          <Radar name="Current" dataKey="Current" stroke="#61E6B5" fill="#61E6B5" fillOpacity={0.3} />
          <Legend wrapperStyle={{ fontSize: 12, color: AXIS }} />
        </RadarChart>
      </ResponsiveContainer>
    </div>
  );
}

export function WeeklyActivityChart({ data }: { data: { day: string; count: number }[] }) {
  return (
    <div className="h-56 w-full" role="img" aria-label="Bar chart of learning activity over the last seven days">
      <ResponsiveContainer width="100%" height="100%">
        <BarChart data={data} margin={{ top: 8, right: 8, left: -20, bottom: 0 }}>
          <CartesianGrid stroke={GRID} vertical={false} />
          <XAxis dataKey="day" tick={{ fill: AXIS, fontSize: 11 }} axisLine={false} tickLine={false} />
          <YAxis allowDecimals={false} tick={{ fill: AXIS, fontSize: 11 }} axisLine={false} tickLine={false} />
          <Tooltip contentStyle={TOOLTIP_STYLE} cursor={{ fill: "rgba(255,255,255,0.03)" }} />
          <Bar dataKey="count" name="Activities" fill="#61E6B5" radius={[6, 6, 0, 0]} />
        </BarChart>
      </ResponsiveContainer>
    </div>
  );
}
