import {
  boolean,
  index,
  integer,
  jsonb,
  pgTable,
  serial,
  text,
  timestamp,
  uniqueIndex,
  varchar,
} from "drizzle-orm/pg-core";

// 1. users ---------------------------------------------------------------
export const users = pgTable(
  "users",
  {
    id: serial("id").primaryKey(),
    fullName: varchar("full_name", { length: 120 }).notNull(),
    email: varchar("email", { length: 254 }).notNull(),
    passwordHash: text("password_hash").notNull(),
    createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
    updatedAt: timestamp("updated_at", { withTimezone: true }).defaultNow().notNull(),
  },
  (t) => [uniqueIndex("users_email_unique").on(t.email)],
);

// Sessions (secure, server-side session store; only a SHA-256 hash of the token is stored)
export const sessions = pgTable(
  "sessions",
  {
    tokenHash: varchar("token_hash", { length: 64 }).primaryKey(),
    userId: integer("user_id")
      .notNull()
      .references(() => users.id, { onDelete: "cascade" }),
    expiresAt: timestamp("expires_at", { withTimezone: true }).notNull(),
    createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
  },
  (t) => [index("sessions_user_idx").on(t.userId)],
);

// 2. learner_profiles ----------------------------------------------------
export const learnerProfiles = pgTable(
  "learner_profiles",
  {
    id: serial("id").primaryKey(),
    userId: integer("user_id")
      .notNull()
      .references(() => users.id, { onDelete: "cascade" }),
    educationLevel: varchar("education_level", { length: 60 }),
    institution: varchar("institution", { length: 160 }),
    certifications: jsonb("certifications").$type<string[]>().notNull().default([]),
    completedProjects: jsonb("completed_projects").$type<string[]>().notNull().default([]),
    targetCareerId: integer("target_career_id").references(() => careerRoles.id, {
      onDelete: "set null",
    }),
    weeklyHours: integer("weekly_hours").notNull().default(5),
    onboardingCompleted: boolean("onboarding_completed").notNull().default(false),
    lastMatchPercentage: integer("last_match_percentage"),
    createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
    updatedAt: timestamp("updated_at", { withTimezone: true }).defaultNow().notNull(),
  },
  (t) => [uniqueIndex("learner_profiles_user_unique").on(t.userId)],
);

// 3. skills (catalogue) --------------------------------------------------
export const skills = pgTable(
  "skills",
  {
    id: serial("id").primaryKey(),
    name: varchar("name", { length: 100 }).notNull(),
    category: varchar("category", { length: 60 }).notNull().default("General"),
    description: text("description").notNull().default(""),
    isSample: boolean("is_sample").notNull().default(true),
    createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
  },
  (t) => [uniqueIndex("skills_name_unique").on(t.name)],
);

// 4. career_roles --------------------------------------------------------
export const careerRoles = pgTable(
  "career_roles",
  {
    id: serial("id").primaryKey(),
    slug: varchar("slug", { length: 80 }).notNull(),
    title: varchar("title", { length: 120 }).notNull(),
    description: text("description").notNull(),
    isSample: boolean("is_sample").notNull().default(true),
    createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
  },
  (t) => [uniqueIndex("career_roles_slug_unique").on(t.slug)],
);

// 5. career_required_skills ---------------------------------------------
export const careerRequiredSkills = pgTable(
  "career_required_skills",
  {
    id: serial("id").primaryKey(),
    careerId: integer("career_id")
      .notNull()
      .references(() => careerRoles.id, { onDelete: "cascade" }),
    skillId: integer("skill_id")
      .notNull()
      .references(() => skills.id, { onDelete: "cascade" }),
    // Required level 1-5. Threshold proficiency = requiredLevel * 20 (0-100 scale).
    requiredLevel: integer("required_level").notNull(),
    weight: integer("weight").notNull().default(1),
  },
  (t) => [
    uniqueIndex("career_required_skills_unique").on(t.careerId, t.skillId),
    index("career_required_skills_career_idx").on(t.careerId),
  ],
);

// 6. learner_skills ------------------------------------------------------
export const learnerSkills = pgTable(
  "learner_skills",
  {
    id: serial("id").primaryKey(),
    userId: integer("user_id")
      .notNull()
      .references(() => users.id, { onDelete: "cascade" }),
    skillId: integer("skill_id")
      .notNull()
      .references(() => skills.id, { onDelete: "cascade" }),
    // Proficiency 0-100. Set by self-report, updated by assessments and learning tasks.
    proficiency: integer("proficiency").notNull().default(0),
    source: varchar("source", { length: 20 }).notNull().default("self"),
    createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
    updatedAt: timestamp("updated_at", { withTimezone: true }).defaultNow().notNull(),
  },
  (t) => [
    uniqueIndex("learner_skills_user_skill_unique").on(t.userId, t.skillId),
    index("learner_skills_user_idx").on(t.userId),
  ],
);

// 7. assessments (one skill-based quiz per skill; questions stored as JSON) ----
export type AssessmentQuestion = {
  id: string;
  prompt: string;
  options: string[];
  answerIndex: number;
  explanation: string;
};

export const assessments = pgTable(
  "assessments",
  {
    id: serial("id").primaryKey(),
    skillId: integer("skill_id")
      .notNull()
      .references(() => skills.id, { onDelete: "cascade" }),
    title: varchar("title", { length: 160 }).notNull(),
    questions: jsonb("questions").$type<AssessmentQuestion[]>().notNull(),
    createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
  },
  (t) => [uniqueIndex("assessments_skill_unique").on(t.skillId)],
);

// 8. assessment_results --------------------------------------------------
export const assessmentResults = pgTable(
  "assessment_results",
  {
    id: serial("id").primaryKey(),
    userId: integer("user_id")
      .notNull()
      .references(() => users.id, { onDelete: "cascade" }),
    assessmentId: integer("assessment_id")
      .notNull()
      .references(() => assessments.id, { onDelete: "cascade" }),
    score: integer("score").notNull(),
    correctCount: integer("correct_count").notNull(),
    totalQuestions: integer("total_questions").notNull(),
    answers: jsonb("answers").$type<number[]>().notNull(),
    previousProficiency: integer("previous_proficiency").notNull(),
    newProficiency: integer("new_proficiency").notNull(),
    createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
  },
  (t) => [index("assessment_results_user_idx").on(t.userId, t.createdAt)],
);

// 9. learning_resources --------------------------------------------------
export const learningResources = pgTable(
  "learning_resources",
  {
    id: serial("id").primaryKey(),
    skillId: integer("skill_id")
      .notNull()
      .references(() => skills.id, { onDelete: "cascade" }),
    title: varchar("title", { length: 200 }).notNull(),
    provider: varchar("provider", { length: 120 }).notNull(),
    url: text("url").notNull(),
    resourceType: varchar("resource_type", { length: 40 }).notNull(),
    estimatedHours: integer("estimated_hours").notNull(),
    isSample: boolean("is_sample").notNull().default(true),
  },
  (t) => [index("learning_resources_skill_idx").on(t.skillId)],
);

// 10. learning_roadmaps (one active roadmap per learner) -----------------
export const learningRoadmaps = pgTable(
  "learning_roadmaps",
  {
    id: serial("id").primaryKey(),
    userId: integer("user_id")
      .notNull()
      .references(() => users.id, { onDelete: "cascade" }),
    careerId: integer("career_id")
      .notNull()
      .references(() => careerRoles.id, { onDelete: "cascade" }),
    generatedBy: varchar("generated_by", { length: 40 }).notNull().default("rule-based"),
    weeklyHours: integer("weekly_hours").notNull(),
    createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
    updatedAt: timestamp("updated_at", { withTimezone: true }).defaultNow().notNull(),
  },
  (t) => [uniqueIndex("learning_roadmaps_user_unique").on(t.userId)],
);

// 11. roadmap_tasks ------------------------------------------------------
export const roadmapTasks = pgTable(
  "roadmap_tasks",
  {
    id: serial("id").primaryKey(),
    roadmapId: integer("roadmap_id")
      .notNull()
      .references(() => learningRoadmaps.id, { onDelete: "cascade" }),
    userId: integer("user_id")
      .notNull()
      .references(() => users.id, { onDelete: "cascade" }),
    skillId: integer("skill_id")
      .notNull()
      .references(() => skills.id, { onDelete: "cascade" }),
    resourceId: integer("resource_id").references(() => learningResources.id, {
      onDelete: "set null",
    }),
    position: integer("position").notNull(),
    priority: integer("priority").notNull(),
    weekNumber: integer("week_number").notNull(),
    estimatedHours: integer("estimated_hours").notNull(),
    title: varchar("title", { length: 200 }).notNull(),
    practicalExercise: text("practical_exercise").notNull(),
    miniProject: text("mini_project").notNull(),
    status: varchar("status", { length: 20 }).notNull().default("pending"), // pending | completed | skipped
    completedAt: timestamp("completed_at", { withTimezone: true }),
    createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
  },
  (t) => [
    index("roadmap_tasks_user_idx").on(t.userId, t.status),
    index("roadmap_tasks_roadmap_idx").on(t.roadmapId),
  ],
);

// 12. progress_records (activity log used for analytics & achievements) --
export const progressRecords = pgTable(
  "progress_records",
  {
    id: serial("id").primaryKey(),
    userId: integer("user_id")
      .notNull()
      .references(() => users.id, { onDelete: "cascade" }),
    activityType: varchar("activity_type", { length: 40 }).notNull(),
    description: text("description").notNull(),
    matchPercentage: integer("match_percentage"),
    metadata: jsonb("metadata").$type<Record<string, unknown>>().notNull().default({}),
    createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
  },
  (t) => [index("progress_records_user_idx").on(t.userId, t.createdAt)],
);

// 13. mentor_conversations ----------------------------------------------
export const mentorConversations = pgTable(
  "mentor_conversations",
  {
    id: serial("id").primaryKey(),
    userId: integer("user_id")
      .notNull()
      .references(() => users.id, { onDelete: "cascade" }),
    role: varchar("role", { length: 12 }).notNull(), // user | assistant
    content: text("content").notNull(),
    source: varchar("source", { length: 30 }), // llm | rule-based (assistant only)
    createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
  },
  (t) => [index("mentor_conversations_user_idx").on(t.userId, t.createdAt)],
);
